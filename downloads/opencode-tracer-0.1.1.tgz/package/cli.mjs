#!/usr/bin/env node
import { access, cp, mkdir, readFile, realpath, writeFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const [command, project = '.', portValue = '3218'] = process.argv.slice(2);
if (Number(process.versions.node.split('.')[0]) < 22) throw new Error('Use Node.js 22 or newer.');

if (command === 'install') {
  const root = await realpath(project);
  const manifest = JSON.parse(await readFile(path.join(here, 'package.json'), 'utf8'));
  const destination = path.join(root, '.opencode', `opencode-tracer-${manifest.version}`);
  const plugin = path.join(root, '.opencode', 'plugins', 'course-trace.js');
  const content = `// OpenCode course tracer ${manifest.version}\nexport { default } from '../opencode-tracer-${manifest.version}/plugin.mjs';\n`;
  try {
    if (await readFile(plugin, 'utf8') !== content) throw new Error(`Refusing to overwrite ${plugin}`);
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
  const files = ['cli.mjs', 'plugin.mjs', 'viewer.mjs', 'package.json', 'npm-shrinkwrap.json', 'LICENSE', 'README.md', 'public'];
  for (const file of files) await access(path.join(here, file));
  await mkdir(path.dirname(destination), { recursive: true });
  try {
    await mkdir(destination);
    for (const file of files) await cp(path.join(here, file), path.join(destination, file), { recursive: true, errorOnExist: true, force: false });
  } catch (error) {
    if (error.code === 'EEXIST') {
      for (const file of ['cli.mjs', 'plugin.mjs', 'viewer.mjs', 'package.json', 'npm-shrinkwrap.json']) {
        const hash = buffer => createHash('sha256').update(buffer).digest('hex');
        if (hash(await readFile(path.join(here, file))) !== hash(await readFile(path.join(destination, file)))) {
          throw new Error(`Existing installation differs: ${destination}. It has been left unchanged.`);
        }
      }
    } else throw error;
  }
  // Dependencies live with the project, never in the temporary npx cache.
  const npm = process.env.npm_execpath;
  const installed = spawnSync(npm ? process.execPath : (process.platform === 'win32' ? 'npm.cmd' : 'npm'),
    [...(npm ? [npm] : []), 'ci', '--ignore-scripts', '--omit=dev', '--no-audit', '--no-fund'],
    { cwd: destination, stdio: 'inherit', shell: !npm && process.platform === 'win32' });
  if (installed.error) throw installed.error;
  if (installed.status !== 0) throw new Error('Dependency installation failed; the plugin has not been activated.');
  await mkdir(path.dirname(plugin), { recursive: true });
  try { await writeFile(plugin, content, { flag: 'wx' }); }
  catch (error) {
    if (error.code !== 'EEXIST' || await readFile(plugin, 'utf8') !== content) throw error;
  }
  console.log(`Installed for OpenCode 2.2.0 in ${root}\nRestart OpenCode in this project.\nView traces: node .opencode/opencode-tracer-${manifest.version}/cli.mjs view . 3218\nTraces contain prompts and file contents. Review them before sharing.`);
} else if (command === 'view') {
  const traceDir = path.resolve(project, '.opencode-trace');
  await access(traceDir);
  const port = Number(portValue);
  if (!Number.isInteger(port) || port < 0 || port > 65535) throw new Error('Invalid port');
  process.env.OPENTRACE_LOG ??= 'console';
  const { createViewer } = await import('./viewer.mjs');
  const viewer = await createViewer({ traceDir, noListen: true, open: false, corsOrigin: false });
  viewer.app.addHook('onRequest', async (req, reply) => {
    if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return reply.code(403).send({ error: 'Read-only course viewer' });
  });
  console.log(await viewer.app.listen({ port, host: '127.0.0.1' }));
  const close = async () => { await viewer.close(); };
  process.once('SIGTERM', close);
  process.once('SIGINT', close);
} else {
  console.log('Usage: opencode-tracer install PROJECT | view PROJECT [PORT]');
  if (command) process.exitCode = 1;
}
