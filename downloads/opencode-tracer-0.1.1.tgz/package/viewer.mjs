var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// packages/viewer/dist/server.js
import { readFileSync as readFileSync5, readdirSync as readdirSync4, existsSync as existsSync6, writeFileSync as writeFileSync4, promises as fs3 } from "node:fs";
import { join as join7, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import Fastify from "fastify";
import cors from "@fastify/cors";
import rateLimit from "@fastify/rate-limit";
import multipart from "@fastify/multipart";
import fastifyStatic from "@fastify/static";
import chokidar from "chokidar";

// packages/core/dist/store/index.js
var store_exports = {};
__export(store_exports, {
  deleteSession: () => deleteSession,
  deleteSessions: () => deleteSessions,
  exportSessionZip: () => exportSessionZip,
  getCachedParsed: () => getCachedParsed,
  getRecord: () => getRecord,
  getSSEStream: () => getSSEStream,
  getSessionRecords: () => getSessionRecords,
  getSessionRecordsAsync: () => getSessionRecordsAsync,
  getTraceDir: () => getTraceDir2,
  importSessionZip: () => importSessionZip,
  initStore: () => initStore,
  invalidateAllReadCache: () => invalidateAllReadCache,
  invalidateReadCacheForSeq: () => invalidateReadCacheForSeq,
  invalidateReadCacheForSession: () => invalidateReadCacheForSession,
  listSessions: () => listSessions,
  listSessionsAsync: () => listSessionsAsync,
  listSessionsFromBothDirs: () => listSessionsFromBothDirs,
  listSessionsFromBothDirsAsync: () => listSessionsFromBothDirsAsync,
  listSessionsTree: () => listSessionsTree,
  listSessionsTreeFromBothDirs: () => listSessionsTreeFromBothDirs,
  listSessionsTreeFromBothDirsAsync: () => listSessionsTreeFromBothDirsAsync,
  readCacheStats: () => readCacheStats,
  readSessionMetadata: () => readSessionMetadata,
  readTimelineIndex: () => readTimelineIndex,
  safeReaddir: () => safeReaddir,
  writeParsedCache: () => writeParsedCache,
  writeRecord: () => writeRecord,
  writeSessionMetadata: () => writeSessionMetadata
});

// packages/core/dist/store/read.js
import { readdirSync as readdirSync2, readFileSync as readFileSync2, statSync, existsSync as existsSync2 } from "node:fs";
import { readdir, readFile } from "node:fs/promises";
import { join as join3 } from "node:path";

// packages/core/dist/paths.js
import path from "node:path";
import { homedir } from "node:os";
function getTraceDir() {
  const pathApi = process.platform === "win32" ? path.win32 : path.posix;
  return pathApi.join(homedir(), ".opencode-trace");
}

// packages/core/dist/state/index.js
import { randomUUID } from "node:crypto";
import { join as join2 } from "node:path";
import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import { promises as fs2 } from "node:fs";

// packages/core/dist/logger.js
import winston from "winston";
import { join } from "node:path";
var logFormat = winston.format.combine(winston.format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }), winston.format.printf(({ timestamp, level, message, ...meta }) => {
  const metaStr = Object.keys(meta).length ? ` ${JSON.stringify(meta)}` : "";
  return `${timestamp} [${level.toUpperCase()}] ${message}${metaStr}`;
}));
function resolveMode() {
  const raw = (process.env.OPENTRACE_LOG ?? "file").toLowerCase();
  if (raw === "off" || raw === "silent" || raw === "none")
    return "off";
  if (raw === "console" || raw === "stderr")
    return "console";
  return "file";
}
function resolveTransports(mode2) {
  if (mode2 === "off")
    return [];
  if (mode2 === "console") {
    return [
      new winston.transports.Console({
        stderrLevels: ["error", "warn", "info", "debug"]
      })
    ];
  }
  const file = process.env.OPENTRACE_LOG_FILE ?? join(getTraceDir(), "plugin.log");
  return [
    new winston.transports.File({
      filename: file,
      maxsize: 5 * 1024 * 1024,
      maxFiles: 2
    })
  ];
}
var mode = resolveMode();
var logger = winston.createLogger({
  level: process.env.OPENTRACE_LOG_LEVEL || "info",
  format: logFormat,
  transports: resolveTransports(mode)
});

// packages/core/dist/platform.js
import { renameSync, promises as fs } from "node:fs";
function safeRenameSync(src, dest, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      renameSync(src, dest);
      return;
    } catch (err) {
      const code = err?.code;
      if ((code === "EACCES" || code === "EPERM") && i < retries - 1) {
        continue;
      }
      throw err;
    }
  }
}

// packages/core/dist/state/index.js
var CONFIG_FILENAME = "config.json";
var CURRENT_SCHEMA_VERSION = 2;
var DEFAULT_CONFIG = {
  global_trace_enabled: true,
  storage_preference: "global",
  plugin_enabled: true,
  current_session: null,
  schema_version: CURRENT_SCHEMA_VERSION
};
var ConfigManager = class {
  traceDir;
  configPath;
  configCache = null;
  constructor(traceDir) {
    this.traceDir = traceDir;
    this.configPath = join2(traceDir, CONFIG_FILENAME);
    if (!existsSync(traceDir)) {
      mkdirSync(traceDir, { recursive: true });
    }
  }
  async init() {
    mkdirSync(this.traceDir, { recursive: true });
    if (!existsSync(this.configPath)) {
      this.writeConfig({ ...DEFAULT_CONFIG });
    }
    this.configCache = this.readConfig();
  }
  readConfig() {
    try {
      if (!existsSync(this.configPath)) {
        return { ...DEFAULT_CONFIG };
      }
      const raw = readFileSync(this.configPath, "utf-8");
      const parsed = JSON.parse(raw);
      return {
        global_trace_enabled: normalizeBoolean(parsed.global_trace_enabled, DEFAULT_CONFIG.global_trace_enabled),
        storage_preference: normalizeStoragePreference(parsed.storage_preference),
        plugin_enabled: normalizeBoolean(parsed.plugin_enabled, DEFAULT_CONFIG.plugin_enabled),
        current_session: typeof parsed.current_session === "string" ? parsed.current_session : null,
        schema_version: typeof parsed.schema_version === "number" ? parsed.schema_version : CURRENT_SCHEMA_VERSION
      };
    } catch (err) {
      logger.error("Failed to read config.json, using defaults", {
        configPath: this.configPath,
        error: String(err)
      });
      return { ...DEFAULT_CONFIG };
    }
  }
  writeConfig(config) {
    try {
      const tmpPath = this.configPath + ".tmp";
      writeFileSync(tmpPath, JSON.stringify(config, null, 2), "utf-8");
      safeRenameSync(tmpPath, this.configPath);
      this.configCache = config;
    } catch (err) {
      logger.error("Failed to write config.json", {
        configPath: this.configPath,
        error: String(err)
      });
    }
  }
  reloadConfig() {
    this.configCache = this.readConfig();
  }
  getGlobalState(key) {
    if (!this.configCache) {
      this.configCache = this.readConfig();
    }
    const v = this.configCache[key];
    if (v === void 0 || v === null)
      return null;
    if (typeof v === "boolean")
      return v ? "true" : "false";
    return String(v);
  }
  setGlobalState(key, value) {
    const config = this.readConfig();
    if (key === "global_trace_enabled") {
      config.global_trace_enabled = value === "true";
    } else if (key === "storage_preference") {
      config.storage_preference = normalizeStoragePreference(value);
    } else if (key === "plugin_enabled") {
      config.plugin_enabled = value !== "false";
    } else if (key === "current_session") {
      config.current_session = value;
    } else {
      config[key] = value;
    }
    this.writeConfig(config);
  }
  startSession(sessionId) {
    const id = sessionId ?? this.generateSessionId();
    mkdirSync(join2(this.traceDir, id), { recursive: true });
    this.setGlobalState("current_session", id);
    this.updateSessionMetadata(id, { startedAt: (/* @__PURE__ */ new Date()).toISOString() });
    return id;
  }
  stopSession(sessionId) {
    const current = this.getGlobalState("current_session");
    if (current === sessionId) {
      this.setGlobalState("current_session", null);
    }
  }
  getSession(sessionId) {
    return this.getSessionFromFs(sessionId);
  }
  getActiveSession() {
    const sessionId = this.getGlobalState("current_session");
    if (!sessionId)
      return null;
    const sessionDir = join2(this.traceDir, sessionId);
    if (!existsSync(sessionDir)) {
      this.setGlobalState("current_session", null);
      return null;
    }
    return sessionId;
  }
  async writeRecord(sessionId, seq, record) {
    const sessionDir = join2(this.traceDir, sessionId);
    await fs2.mkdir(sessionDir, { recursive: true });
    const filePath = join2(sessionDir, `${seq}.json`);
    const tmpPath = filePath + ".tmp";
    await fs2.writeFile(tmpPath, JSON.stringify(record, null, 2));
    await fs2.rename(tmpPath, filePath);
  }
  listSessions() {
    return this.listSessionsFromFs();
  }
  generateSessionId() {
    return randomUUID();
  }
  scanFsSessions() {
    try {
      const entries = readdirSync(this.traceDir, { withFileTypes: true });
      return entries.filter((e) => e.isDirectory()).map((e) => e.name);
    } catch (err) {
      logger.error("Failed to scan filesystem sessions", {
        traceDir: this.traceDir,
        error: String(err)
      });
      return [];
    }
  }
  getSessionFromFs(sessionId) {
    const sessionDir = join2(this.traceDir, sessionId);
    if (!existsSync(sessionDir))
      return null;
    const metadata = this.readMetadataFile(sessionId);
    const isCurrentSession = this.configCache?.current_session === sessionId;
    const ndjsonData = this.readNdjsonTiming(sessionDir);
    if (ndjsonData) {
      return {
        id: sessionId,
        status: isCurrentSession ? "active" : "stopped",
        startedAt: metadata.startedAt ?? ndjsonData.startedAt,
        endedAt: ndjsonData.endedAt,
        requestCount: ndjsonData.count,
        ...metadata
      };
    }
    const files = readdirSync(sessionDir).filter((f) => /^\d+\.json$/.test(f));
    if (files.length === 0) {
      return {
        id: sessionId,
        status: isCurrentSession ? "active" : "stopped",
        startedAt: metadata.startedAt ?? null,
        endedAt: null,
        requestCount: 0,
        ...metadata
      };
    }
    let startedAt = null;
    let endedAt = null;
    let count = 0;
    for (const f of files) {
      try {
        const raw = readFileSync(join2(sessionDir, f), "utf-8");
        const rec = JSON.parse(raw);
        count++;
        if (!startedAt || rec.requestAt < startedAt)
          startedAt = rec.requestAt;
        if (!endedAt || rec.responseAt > endedAt)
          endedAt = rec.responseAt;
      } catch (err) {
        logger.error("Failed to read session record file", {
          sessionId,
          file: f,
          traceDir: this.traceDir,
          error: String(err)
        });
      }
    }
    return {
      id: sessionId,
      status: isCurrentSession ? "active" : "stopped",
      startedAt: metadata.startedAt ?? startedAt,
      endedAt,
      requestCount: count,
      ...metadata
    };
  }
  listSessionsFromFs() {
    const ids = this.scanFsSessions();
    const sessions = [];
    for (const id of ids) {
      const session = this.getSessionFromFs(id);
      if (session)
        sessions.push(session);
    }
    return sessions.sort((a, b) => (b.startedAt ?? "").localeCompare(a.startedAt ?? ""));
  }
  /** Try to read timing data from timeline.ndjson for O(S+logR) session listing. */
  readNdjsonTiming(sessionDir) {
    const indexPath = join2(sessionDir, "timeline.ndjson");
    if (!existsSync(indexPath))
      return null;
    try {
      const raw = readFileSync(indexPath, "utf-8");
      const lines = raw.split("\n").filter((l) => l.trim());
      if (lines.length === 0)
        return { startedAt: null, endedAt: null, count: 0 };
      let startedAt = null;
      let endedAt = null;
      let count = 0;
      for (const line of lines) {
        try {
          const entry = JSON.parse(line);
          count++;
          if (entry.requestAt && (!startedAt || entry.requestAt < startedAt)) {
            startedAt = entry.requestAt;
          }
          if (entry.responseAt && (!endedAt || entry.responseAt > endedAt)) {
            endedAt = entry.responseAt;
          }
        } catch {
        }
      }
      return { startedAt, endedAt, count };
    } catch {
      return null;
    }
  }
  getMetadataPath(sessionId) {
    return join2(this.traceDir, sessionId, "metadata.json");
  }
  readMetadataFile(sessionId) {
    const metaPath = this.getMetadataPath(sessionId);
    if (!existsSync(metaPath)) {
      return {};
    }
    try {
      const raw = readFileSync(metaPath, "utf-8");
      return JSON.parse(raw);
    } catch (err) {
      logger.error("Failed to read session metadata file", {
        sessionId,
        metaPath,
        traceDir: this.traceDir,
        error: String(err)
      });
      return {};
    }
  }
  writeMetadataFile(sessionId, metadata) {
    const sessionDir = join2(this.traceDir, sessionId);
    if (!existsSync(sessionDir)) {
      mkdirSync(sessionDir, { recursive: true });
    }
    const metaPath = this.getMetadataPath(sessionId);
    const tmpPath = metaPath + ".tmp";
    writeFileSync(tmpPath, JSON.stringify(metadata, null, 2), "utf-8");
    safeRenameSync(tmpPath, metaPath);
  }
  updateSessionMetadata(sessionId, metadata) {
    const existing = this.readMetadataFile(sessionId);
    const updated = { ...existing };
    if (metadata.title !== void 0) {
      updated.title = metadata.title;
    }
    if (metadata.parentID !== void 0) {
      updated.parentID = metadata.parentID;
    }
    if (metadata.folderPath !== void 0) {
      updated.folderPath = metadata.folderPath;
    }
    if (metadata.startedAt !== void 0) {
      updated.startedAt = metadata.startedAt;
    }
    if (metadata.trace_enabled !== void 0) {
      updated.trace_enabled = metadata.trace_enabled;
    }
    if (metadata.storage_preference !== void 0) {
      updated.storage_preference = metadata.storage_preference;
    }
    this.writeMetadataFile(sessionId, updated);
  }
  setSessionEnabled(sessionId, enabled) {
    const existing = this.readMetadataFile(sessionId);
    const updated = { ...existing };
    if (enabled === null) {
      delete updated.trace_enabled;
    } else {
      updated.trace_enabled = enabled;
    }
    this.writeMetadataFile(sessionId, updated);
  }
  getSessionEnabled(sessionId) {
    const metadata = this.readMetadataFile(sessionId);
    return metadata.trace_enabled ?? null;
  }
  setSessionStoragePreference(sessionId, preference) {
    const existing = this.readMetadataFile(sessionId);
    this.writeMetadataFile(sessionId, { ...existing, storage_preference: preference });
  }
  getSessionStoragePreference(sessionId) {
    const metadata = this.readMetadataFile(sessionId);
    return metadata.storage_preference ?? null;
  }
  getStoragePreference() {
    if (!this.configCache) {
      this.configCache = this.readConfig();
    }
    return this.configCache.storage_preference;
  }
  setStoragePreference(preference) {
    this.setGlobalState("storage_preference", preference);
  }
  isTraceEnabled(sessionId) {
    const globalEnabled = this.getGlobalState("global_trace_enabled") === "true";
    if (globalEnabled)
      return true;
    if (!sessionId)
      return false;
    return this.getSessionEnabled(sessionId) ?? false;
  }
  addSubSession(parentSessionId, subSessionId) {
    const existing = this.readMetadataFile(parentSessionId);
    const subSessions = existing.subSessions ?? [];
    if (!subSessions.includes(subSessionId)) {
      subSessions.push(subSessionId);
      this.writeMetadataFile(parentSessionId, { ...existing, subSessions });
    }
  }
};
function normalizeBoolean(value, defaultValue) {
  if (typeof value === "boolean")
    return value;
  if (value === "true")
    return true;
  if (value === "false")
    return false;
  return defaultValue;
}
function normalizeStoragePreference(value) {
  if (value === "local")
    return "local";
  return "global";
}
var registry = /* @__PURE__ */ new Map();
var registryInitPromises = /* @__PURE__ */ new Map();
function hasConfigManager(traceDir) {
  return registry.has(traceDir);
}
function getConfigManager(traceDir) {
  if (!registry.has(traceDir)) {
    const manager = new ConfigManager(traceDir);
    registry.set(traceDir, manager);
    registryInitPromises.set(traceDir, manager.init());
  }
  return registry.get(traceDir);
}
async function initConfigManager(traceDir) {
  const manager = getConfigManager(traceDir);
  await registryInitPromises.get(traceDir);
  return manager;
}

// packages/core/dist/schemas/types.js
import { z } from "zod";
var TraceRequestSchema = z.object({
  method: z.string(),
  url: z.string(),
  headers: z.record(z.string(), z.string()),
  body: z.unknown()
});
var TraceResponseSchema = z.object({
  status: z.number().int(),
  statusText: z.string(),
  headers: z.record(z.string(), z.string()),
  body: z.unknown()
});
var TraceErrorSchema = z.object({
  message: z.string(),
  stack: z.string().optional()
});
var TraceRecordSchema = z.object({
  id: z.number().int().positive(),
  purpose: z.string(),
  requestAt: z.string(),
  responseAt: z.string(),
  request: TraceRequestSchema,
  response: TraceResponseSchema.nullable(),
  error: TraceErrorSchema.nullable(),
  requestSentAt: z.number().optional(),
  firstTokenAt: z.number().optional(),
  lastTokenAt: z.number().optional()
});

// packages/core/dist/schemas/store-types.js
import { z as z2 } from "zod";
var SessionMetaSchema = z2.object({
  id: z2.string(),
  requestCount: z2.number().int().nonnegative(),
  createdAt: z2.string().nullable(),
  updatedAt: z2.string().nullable(),
  title: z2.string().optional(),
  parentID: z2.string().optional(),
  subSessions: z2.array(z2.string()).optional(),
  folderPath: z2.string().optional()
});
var SessionTreeNodeSchema = SessionMetaSchema.extend({
  children: z2.array(SessionMetaSchema)
});
var SessionMetadataFileSchema = z2.object({
  sessionId: z2.string(),
  title: z2.string().optional(),
  enabled: z2.boolean().optional(),
  parentID: z2.string().optional(),
  subSessions: z2.array(z2.string()).optional(),
  createdAt: z2.string().optional(),
  updatedAt: z2.string().optional()
});
var ExportManifestSchema = z2.object({
  exportedAt: z2.string(),
  mainSession: z2.string(),
  sessions: z2.array(z2.string()),
  version: z2.string()
});
var ConflictInfoSchema = z2.object({
  sessionId: z2.string(),
  existing: z2.object({
    requestCount: z2.number().int().nonnegative(),
    createdAt: z2.string()
  }),
  importing: z2.object({
    requestCount: z2.number().int().nonnegative(),
    createdAt: z2.string()
  })
});
var ImportedSessionInfoSchema = z2.object({
  sessionId: z2.string(),
  requestCount: z2.number().int().nonnegative(),
  strategy: z2.enum(["none", "rename", "skip", "overwrite"]),
  newId: z2.string().optional()
});
var ImportResultSchema = z2.object({
  status: z2.enum(["success", "conflict"]),
  conflicts: z2.array(ConflictInfoSchema).optional(),
  importedSessions: z2.array(ImportedSessionInfoSchema).optional()
});

// packages/core/dist/parse/index.js
var parse_exports = {};
__export(parse_exports, {
  PARSED_CACHE_VERSION: () => PARSED_CACHE_VERSION,
  anthropicParser: () => anthropicParser,
  clearRegistrations: () => clearRegistrations,
  createImageBlock: () => createImageBlock,
  createMsgEntry: () => createMsgEntry,
  createOtherBlock: () => createOtherBlock,
  createSysEntry: () => createSysEntry,
  createTextBlock: () => createTextBlock,
  createThinkingBlock: () => createThinkingBlock,
  createToolCallBlock: () => createToolCallBlock,
  createToolDefinitionBlock: () => createToolDefinitionBlock,
  createToolEntry: () => createToolEntry,
  createToolResultBlock: () => createToolResultBlock,
  detectAndParse: () => detectAndParse,
  detectProvider: () => detectProvider,
  extractLatency: () => extractLatency,
  extractUsage: () => extractUsage2,
  findParser: () => findParser,
  generateId: () => generateId,
  getRegistrations: () => getRegistrations,
  openaiChatParser: () => openaiChatParser,
  openaiResponsesParser: () => openaiResponsesParser,
  registerParser: () => registerParser
});

// packages/core/dist/model/utils.js
function hashString(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36).slice(0, 9);
}
function generateId() {
  return Math.random().toString(36).slice(2, 11);
}
function generateStableId(role, blocks) {
  const contentKey = blocks.map((b) => {
    switch (b.type) {
      case "text":
        return `t:${b.text.slice(0, 100)}`;
      case "thinking":
        return `k:${b.thinking.slice(0, 100)}`;
      case "tc":
        return `c:${b.id}:${b.name}`;
      case "tr":
        return `r:${b.toolCallId}`;
      default:
        return b.type;
    }
  }).join("|");
  return hashString(`${role}:${contentKey}`);
}
function createSysEntry(blocks) {
  return { id: "sys", blocks };
}
function createToolEntry(blocks) {
  return { id: "tool", blocks };
}
function createMsgEntry(role, blocks) {
  return { id: generateStableId(role, blocks), role, blocks };
}
function createTextBlock(text) {
  return { type: "text", text };
}
function createThinkingBlock(thinking) {
  return { type: "thinking", thinking };
}
function createToolDefinitionBlock(name, description, inputSchema) {
  return { type: "td", name, description, inputSchema };
}
function createToolCallBlock(id, name, args) {
  return { type: "tc", id, name, arguments: args };
}
function createToolResultBlock(toolCallId, content) {
  return { type: "tr", toolCallId, content };
}
function createImageBlock(source) {
  return { type: "image", source };
}
function createOtherBlock(raw) {
  return { type: "other", raw };
}

// packages/core/dist/parse/registry.js
var registrations = [];
function registerParser(parser, pathPattern, hostPattern) {
  if (registrations.some((r) => r.parser.provider === parser.provider)) {
    throw new Error(`Parser already registered for provider: ${parser.provider}`);
  }
  registrations.push({ parser, pathPattern, hostPattern });
}
function findParser(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return null;
  }
  const pathname = parsed.pathname;
  const hostname = parsed.hostname;
  const candidates = registrations.filter((r) => pathname.endsWith(r.pathPattern));
  if (candidates.length === 0)
    return null;
  const exact = candidates.find((r) => r.hostPattern && hostname === r.hostPattern);
  if (exact)
    return exact.parser;
  const fallback = candidates.find((r) => !r.hostPattern);
  if (fallback)
    return fallback.parser;
  return candidates[0].parser;
}
function getRegistrations() {
  return [...registrations];
}
function clearRegistrations() {
  registrations.length = 0;
}

// packages/core/dist/parse/openai-chat.js
function isRecord(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}
function extractMessages(body) {
  const raw = body.messages;
  if (!Array.isArray(raw))
    return [];
  return raw.filter((msg) => !(isRecord(msg) && (msg.role === "system" || msg.role === "developer"))).map((msg) => {
    if (!isRecord(msg))
      return createMsgEntry("user", [createTextBlock(String(msg))]);
    const role = String(msg.role ?? "user");
    const blocks = [];
    if (typeof msg.content === "string" && msg.content) {
      blocks.push(createTextBlock(msg.content));
    } else if (Array.isArray(msg.content)) {
      for (const part of msg.content) {
        if (typeof part === "string") {
          blocks.push(createTextBlock(part));
        } else if (isRecord(part)) {
          if (typeof part.text === "string" && part.text) {
            blocks.push(createTextBlock(part.text));
          } else if (part.type === "image_url" && isRecord(part.image_url) && typeof part.image_url.url === "string") {
            blocks.push(createImageBlock(part.image_url.url));
          } else if (part.type === "input_audio") {
            blocks.push(createOtherBlock({ type: "audio", data: part }));
          } else {
            blocks.push(createOtherBlock(part));
          }
        }
      }
    }
    if (Array.isArray(msg.tool_calls)) {
      for (const tc of msg.tool_calls) {
        if (!isRecord(tc))
          continue;
        const fn = isRecord(tc.function) ? tc.function : {};
        blocks.push(createToolCallBlock(String(tc.id ?? ""), String(fn.name ?? ""), typeof fn.arguments === "string" ? fn.arguments : JSON.stringify(fn.arguments ?? {})));
      }
    }
    if (msg.tool_call_id != null) {
      const content = blocks.length > 0 ? blocks.filter((b) => b.type === "text").map((b) => b.text).join("") : "";
      return createMsgEntry(role, [
        createToolResultBlock(String(msg.tool_call_id), content || JSON.stringify(msg.content ?? ""))
      ]);
    }
    if (typeof msg.reasoning_content === "string") {
      blocks.unshift(createThinkingBlock(msg.reasoning_content));
    }
    if (blocks.length === 0) {
      blocks.push(createTextBlock(""));
    }
    return createMsgEntry(role, blocks);
  });
}
function extractTools(body) {
  const raw = body.tools;
  if (!Array.isArray(raw))
    return void 0;
  const blocks = raw.map((tool) => {
    if (!isRecord(tool))
      return createToolDefinitionBlock(String(tool), null, null);
    const fn = isRecord(tool.function) ? tool.function : {};
    return createToolDefinitionBlock(String(fn.name ?? tool.name ?? ""), typeof fn.description === "string" ? fn.description : null, fn.parameters ?? null);
  });
  if (blocks.length === 0)
    return void 0;
  return createToolEntry(blocks);
}
function extractSystem(body) {
  const systemParts = [];
  if (typeof body.system === "string")
    systemParts.push(body.system);
  if (typeof body.developer === "string")
    systemParts.push(body.developer);
  if (typeof body.instructions === "string")
    systemParts.push(body.instructions);
  const systemFromMessages = (Array.isArray(body.messages) ? body.messages : []).filter((m) => isRecord(m) && (m.role === "system" || m.role === "developer")).map((m) => typeof m.content === "string" ? m.content : "");
  systemParts.push(...systemFromMessages);
  const text = systemParts.join("\n");
  if (!text)
    return void 0;
  return createSysEntry([createTextBlock(text)]);
}
function extractUsage(body) {
  const usage = body.usage;
  if (!isRecord(usage))
    return null;
  const inputTokens = typeof usage.prompt_tokens === "number" ? usage.prompt_tokens : 0;
  const outputTokens = typeof usage.completion_tokens === "number" ? usage.completion_tokens : 0;
  const promptDetails = isRecord(usage.prompt_tokens_details) ? usage.prompt_tokens_details : {};
  const cachedTokens = typeof promptDetails.cached_tokens === "number" ? promptDetails.cached_tokens : 0;
  const inputMiss = inputTokens - cachedTokens;
  return {
    inputMissTokens: inputMiss > 0 ? inputMiss : null,
    inputHitTokens: cachedTokens > 0 ? cachedTokens : null,
    outputTokens: outputTokens > 0 ? outputTokens : null
  };
}
var openaiChatParser = {
  provider: "openai-chat",
  parseRequest(body) {
    if (!isRecord(body)) {
      return {
        provider: this.provider,
        model: null,
        msgs: [],
        usage: null,
        stream: false
      };
    }
    return {
      provider: this.provider,
      model: typeof body.model === "string" ? body.model : null,
      sys: extractSystem(body),
      tool: extractTools(body),
      msgs: extractMessages(body),
      usage: null,
      stream: body.stream === true
    };
  },
  parseResponse(body) {
    if (!isRecord(body))
      return {};
    const choices = body.choices;
    const msgs = [];
    if (Array.isArray(choices) && choices.length > 0) {
      const choice = choices[0];
      if (isRecord(choice)) {
        const msg = choice.message;
        if (isRecord(msg)) {
          const blocks = [];
          if (typeof msg.reasoning_content === "string") {
            blocks.push(createThinkingBlock(msg.reasoning_content));
          }
          if (typeof msg.content === "string" && msg.content) {
            blocks.push(createTextBlock(msg.content));
          }
          if (Array.isArray(msg.tool_calls)) {
            for (const tc of msg.tool_calls) {
              if (!isRecord(tc))
                continue;
              const fn = isRecord(tc.function) ? tc.function : {};
              blocks.push(createToolCallBlock(String(tc.id ?? ""), String(fn.name ?? ""), typeof fn.arguments === "string" ? fn.arguments : JSON.stringify(fn.arguments ?? {})));
            }
          }
          if (blocks.length === 0) {
            blocks.push(createTextBlock(""));
          }
          msgs.push(createMsgEntry("assistant", blocks));
        }
      }
    }
    return {
      model: typeof body.model === "string" ? body.model : void 0,
      msgs,
      usage: extractUsage(body)
    };
  }
};
registerParser(openaiChatParser, "/chat/completions");

// packages/core/dist/parse/openai-responses.js
function isRecord2(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}
function extractInputMessages(input) {
  const msgs = [];
  if (typeof input === "string") {
    msgs.push(createMsgEntry("user", [createTextBlock(input)]));
  } else if (Array.isArray(input)) {
    for (const item of input) {
      if (typeof item === "string") {
        msgs.push(createMsgEntry("user", [createTextBlock(item)]));
        continue;
      }
      if (!isRecord2(item))
        continue;
      const type = item.type;
      if (type === "message" || item.role) {
        const role = String(item.role ?? "user");
        const contentParts = item.content;
        const blocks = [];
        if (typeof contentParts === "string") {
          blocks.push(createTextBlock(contentParts));
        } else if (Array.isArray(contentParts)) {
          for (const part of contentParts) {
            if (typeof part === "string") {
              blocks.push(createTextBlock(part));
            } else if (isRecord2(part)) {
              if (part.type === "input_text" && typeof part.text === "string") {
                blocks.push(createTextBlock(part.text));
              } else if (part.type === "text" && typeof part.text === "string") {
                blocks.push(createTextBlock(part.text));
              } else if (part.type === "output_text" && typeof part.text === "string") {
                blocks.push(createTextBlock(part.text));
              } else if (part.type === "input_image") {
                blocks.push(createOtherBlock({ type: "image", source: part }));
              } else if (part.type === "input_file") {
                blocks.push(createOtherBlock({ type: "file", source: part }));
              } else if (typeof part.text === "string") {
                blocks.push(createTextBlock(part.text));
              } else {
                blocks.push(createOtherBlock(part));
              }
            }
          }
        }
        if (role === "tool" && item.tool_call_id != null) {
          const content = blocks.length > 0 ? blocks.filter((b) => b.type === "text").map((b) => b.text).join("") : "";
          msgs.push(createMsgEntry("tool", [
            createToolResultBlock(String(item.tool_call_id), content || JSON.stringify(item.content ?? ""))
          ]));
        } else {
          if (blocks.length === 0) {
            blocks.push(createTextBlock(""));
          }
          msgs.push(createMsgEntry(role, blocks));
        }
      } else if (type === "function_call") {
        msgs.push(createMsgEntry("assistant", [
          createToolCallBlock(String(item.id ?? item.call_id ?? ""), String(item.name ?? ""), typeof item.arguments === "string" ? item.arguments : JSON.stringify(item.arguments ?? {}))
        ]));
      } else if (type === "function_call_output") {
        msgs.push(createMsgEntry("tool", [
          createToolResultBlock(String(item.call_id ?? ""), typeof item.output === "string" ? item.output : JSON.stringify(item.output ?? ""))
        ]));
      }
    }
  }
  return msgs;
}
var openaiResponsesParser = {
  provider: "openai-responses",
  parseRequest(body) {
    if (!isRecord2(body)) {
      return {
        provider: this.provider,
        model: null,
        msgs: [],
        usage: null,
        stream: false
      };
    }
    const msgs = extractInputMessages(body.input);
    const toolBlocks = [];
    if (Array.isArray(body.tools)) {
      for (const tool of body.tools) {
        if (!isRecord2(tool))
          continue;
        if (tool.type === "function" && isRecord2(tool.function)) {
          toolBlocks.push(createToolDefinitionBlock(String(tool.function.name ?? ""), typeof tool.function.description === "string" ? tool.function.description : null, tool.function.parameters ?? null));
        } else if (tool.type === "web_search_preview" || tool.type === "web_search_preview_2025_03_11") {
          toolBlocks.push(createToolDefinitionBlock("web_search_preview", "Web search tool", null));
        } else if (tool.type === "file_search") {
          toolBlocks.push(createToolDefinitionBlock("file_search", typeof tool.vector_store_ids === "string" ? "File search: " + tool.vector_store_ids : "File search tool", null));
        } else if (tool.type === "computer_use_preview") {
          toolBlocks.push(createToolDefinitionBlock("computer_use_preview", "Computer use tool", null));
        } else if (tool.type === "code_interpreter") {
          toolBlocks.push(createToolDefinitionBlock("code_interpreter", "Code interpreter tool", null));
        } else {
          toolBlocks.push(createToolDefinitionBlock(String(tool.name ?? tool.type ?? ""), typeof tool.description === "string" ? tool.description : null, null));
        }
      }
    }
    const sysBlocks = [];
    if (typeof body.instructions === "string") {
      sysBlocks.push(createTextBlock(body.instructions));
    }
    return {
      provider: this.provider,
      model: typeof body.model === "string" ? body.model : null,
      sys: sysBlocks.length > 0 ? createSysEntry(sysBlocks) : void 0,
      tool: toolBlocks.length > 0 ? createToolEntry(toolBlocks) : void 0,
      msgs,
      usage: null,
      stream: body.stream === true
    };
  },
  parseResponse(body) {
    if (!isRecord2(body))
      return {};
    const msgs = [];
    if (Array.isArray(body.output)) {
      for (const item of body.output) {
        if (!isRecord2(item))
          continue;
        if (item.type === "message") {
          const contentParts = item.content;
          const blocks = [];
          if (Array.isArray(contentParts)) {
            for (const p of contentParts) {
              if (!isRecord2(p))
                continue;
              if (p.type === "output_text" && typeof p.text === "string") {
                blocks.push(createTextBlock(p.text));
              } else if (p.type === "refusal" && typeof p.refusal === "string") {
                blocks.push(createTextBlock("[refused: " + p.refusal + "]"));
              } else {
                blocks.push(createOtherBlock(p));
              }
            }
          }
          if (blocks.length === 0) {
            blocks.push(createTextBlock(""));
          }
          msgs.push(createMsgEntry("assistant", blocks));
        } else if (item.type === "function_call") {
          msgs.push(createMsgEntry("assistant", [
            createToolCallBlock(String(item.id ?? item.call_id ?? ""), String(item.name ?? ""), typeof item.arguments === "string" ? item.arguments : JSON.stringify(item.arguments ?? {}))
          ]));
        } else if (item.type === "function_call_output") {
          msgs.push(createMsgEntry("tool", [
            createToolResultBlock(String(item.call_id ?? ""), typeof item.output === "string" ? item.output : JSON.stringify(item.output ?? ""))
          ]));
        } else if (item.type === "reasoning") {
          let thinkingText = "";
          if (Array.isArray(item.summary)) {
            thinkingText = item.summary.map((s) => {
              if (isRecord2(s) && s.type === "summary_text" && typeof s.text === "string")
                return s.text;
              return "";
            }).join("");
          }
          msgs.push(createMsgEntry("assistant", thinkingText ? [createThinkingBlock(thinkingText)] : [createTextBlock("")]));
        } else if (item.type === "web_search_call") {
          msgs.push(createMsgEntry("assistant", [
            createOtherBlock({ type: "web_search", status: item.status })
          ]));
        } else if (item.type === "file_search_call") {
          msgs.push(createMsgEntry("assistant", [
            createOtherBlock({ type: "file_search", status: item.status })
          ]));
        } else if (item.type === "computer_call") {
          msgs.push(createMsgEntry("assistant", [
            createOtherBlock({ type: "computer_use" })
          ]));
        } else {
          msgs.push(createMsgEntry("assistant", [createOtherBlock(item)]));
        }
      }
    }
    const usage = body.usage;
    let parsedUsage = null;
    if (isRecord2(usage)) {
      const inputTokens = typeof usage.input_tokens === "number" ? usage.input_tokens : 0;
      const outputTokens = typeof usage.output_tokens === "number" ? usage.output_tokens : 0;
      const cachedTokens = isRecord2(usage.input_tokens_details) && typeof usage.input_tokens_details.cached_tokens === "number" ? usage.input_tokens_details.cached_tokens : 0;
      const inputMiss = inputTokens - cachedTokens;
      parsedUsage = {
        inputMissTokens: inputMiss > 0 ? inputMiss : null,
        inputHitTokens: cachedTokens > 0 ? cachedTokens : null,
        outputTokens: outputTokens > 0 ? outputTokens : null
      };
    }
    return {
      model: typeof body.model === "string" ? body.model : void 0,
      msgs,
      usage: parsedUsage
    };
  }
};
registerParser(openaiResponsesParser, "/responses");

// packages/core/dist/parse/anthropic.js
function isRecord3(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}
var anthropicParser = {
  provider: "anthropic",
  parseRequest(body) {
    if (!isRecord3(body)) {
      return {
        provider: this.provider,
        model: null,
        msgs: [],
        usage: null,
        stream: false
      };
    }
    const sysBlocks = [];
    if (typeof body.system === "string") {
      sysBlocks.push(createTextBlock(body.system));
    } else if (Array.isArray(body.system)) {
      for (const b of body.system) {
        if (typeof b === "string") {
          sysBlocks.push(createTextBlock(b));
        } else if (isRecord3(b) && b.type === "text" && typeof b.text === "string") {
          sysBlocks.push(createTextBlock(b.text));
        }
      }
    }
    const toolBlocks = [];
    if (Array.isArray(body.tools)) {
      for (const tool of body.tools) {
        if (!isRecord3(tool))
          continue;
        toolBlocks.push(createToolDefinitionBlock(String(tool.name ?? ""), typeof tool.description === "string" ? tool.description : null, tool.input_schema ?? null));
      }
    }
    const msgs = [];
    if (Array.isArray(body.messages)) {
      for (const msg of body.messages) {
        if (!isRecord3(msg))
          continue;
        const role = String(msg.role ?? "user");
        const blocks = [];
        if (typeof msg.content === "string") {
          blocks.push(createTextBlock(msg.content));
        } else if (Array.isArray(msg.content)) {
          for (const block of msg.content) {
            if (typeof block === "string") {
              blocks.push(createTextBlock(block));
            } else if (isRecord3(block)) {
              if (block.type === "text" && typeof block.text === "string") {
                blocks.push(createTextBlock(block.text));
              } else if (block.type === "thinking" && typeof block.thinking === "string") {
                blocks.push(createThinkingBlock(block.thinking));
              } else if (block.type === "image" && isRecord3(block.source)) {
                blocks.push(createImageBlock(block.source));
              } else if (block.type === "tool_use") {
                const input = typeof block.input === "string" ? block.input : JSON.stringify(block.input ?? {});
                blocks.push(createToolCallBlock(String(block.id ?? ""), String(block.name ?? ""), input));
              } else if (block.type === "tool_result") {
                let contentStr = "";
                if (typeof block.content === "string") {
                  contentStr = block.content;
                } else if (Array.isArray(block.content)) {
                  contentStr = block.content.map((c) => {
                    if (typeof c === "string")
                      return c;
                    if (isRecord3(c) && c.type === "text" && typeof c.text === "string")
                      return c.text;
                    return "";
                  }).join("");
                }
                blocks.push(createToolResultBlock(String(block.tool_use_id ?? ""), contentStr));
              } else {
                blocks.push(createOtherBlock(block));
              }
            }
          }
        }
        if (blocks.length === 0) {
          blocks.push(createTextBlock(""));
        }
        msgs.push(createMsgEntry(role, blocks));
      }
    }
    return {
      provider: this.provider,
      model: typeof body.model === "string" ? body.model : null,
      sys: sysBlocks.length > 0 ? createSysEntry(sysBlocks) : void 0,
      tool: toolBlocks.length > 0 ? createToolEntry(toolBlocks) : void 0,
      msgs,
      usage: null,
      stream: body.stream === true
    };
  },
  parseResponse(body) {
    if (!isRecord3(body))
      return {};
    const msgs = [];
    if (Array.isArray(body.content)) {
      const blocks = [];
      for (const block of body.content) {
        if (!isRecord3(block))
          continue;
        if (block.type === "text" && typeof block.text === "string") {
          blocks.push(createTextBlock(block.text));
        } else if (block.type === "thinking" && typeof block.thinking === "string") {
          blocks.push(createThinkingBlock(block.thinking));
        } else if (block.type === "tool_use") {
          const input = typeof block.input === "string" ? block.input : JSON.stringify(block.input ?? {});
          blocks.push(createToolCallBlock(String(block.id ?? ""), String(block.name ?? ""), input));
        } else {
          blocks.push(createOtherBlock(block));
        }
      }
      if (blocks.length > 0) {
        msgs.push(createMsgEntry("assistant", blocks));
      }
    }
    const usage = body.usage;
    let parsedUsage = null;
    if (isRecord3(usage)) {
      const inputTokens = typeof usage.input_tokens === "number" ? usage.input_tokens : 0;
      const outputTokens = typeof usage.output_tokens === "number" ? usage.output_tokens : 0;
      const cachedTokens = typeof usage.cache_read_input_tokens === "number" ? usage.cache_read_input_tokens : 0;
      const inputMiss = inputTokens - cachedTokens;
      parsedUsage = {
        inputMissTokens: inputMiss > 0 ? inputMiss : null,
        inputHitTokens: cachedTokens > 0 ? cachedTokens : null,
        outputTokens: outputTokens > 0 ? outputTokens : null
      };
    }
    return {
      model: typeof body.model === "string" ? body.model : void 0,
      msgs,
      usage: parsedUsage
    };
  }
};
registerParser(anthropicParser, "/v1/messages");

// packages/core/dist/transform/index.js
var transform_exports = {};
__export(transform_exports, {
  isSSEData: () => isSSEData,
  parseSSE: () => parseSSE,
  sseAnthropicParse: () => sseAnthropicParse,
  sseAnthropicToMessages: () => sseAnthropicToMessages,
  sseOpenaiChatParse: () => sseOpenaiChatParse,
  sseOpenaiChatToMessages: () => sseOpenaiChatToMessages,
  sseOpenaiResponsesParse: () => sseOpenaiResponsesParse,
  sseOpenaiResponsesToMessages: () => sseOpenaiResponsesToMessages
});

// packages/core/dist/transform/sse.js
function parseSSE(raw) {
  const events = [];
  const lines = raw.split("\n");
  let current = {};
  for (const line of lines) {
    if (line === "") {
      if (current.data !== void 0) {
        events.push({
          id: current.id,
          event: current.event,
          data: current.data
        });
      }
      current = {};
      continue;
    }
    if (line.startsWith(":"))
      continue;
    const colonIdx = line.indexOf(":");
    if (colonIdx === -1) {
      const field2 = line.trim();
      if (field2 === "data" && current.data === void 0) {
        current.data = "";
      }
      continue;
    }
    const field = line.slice(0, colonIdx).trim();
    const value = line.slice(colonIdx + 1).trimStart();
    switch (field) {
      case "event":
        current.event = value;
        break;
      case "id":
        current.id = value;
        break;
      case "data":
        current.data = (current.data ?? "") + (current.data !== void 0 ? "\n" : "") + value;
        break;
    }
  }
  if (current.data !== void 0) {
    events.push({
      id: current.id,
      event: current.event,
      data: current.data
    });
  }
  return events;
}
function isSSEData(data) {
  return data.startsWith("data:");
}

// packages/core/dist/transform/index.js
function isRecord4(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}
function sseOpenaiChatToMessages(raw) {
  const result = sseOpenaiChatParse(raw);
  return result.messages;
}
function sseOpenaiChatParse(raw) {
  const events = parseSSE(raw);
  let content = "";
  let reasoningContent = "";
  const toolCalls = [];
  let usage = null;
  for (const event of events) {
    if (!event.data || event.data === "[DONE]")
      continue;
    try {
      const parsed = JSON.parse(event.data);
      if (!isRecord4(parsed))
        continue;
      if (isRecord4(parsed.usage)) {
        const promptDetails = isRecord4(parsed.usage.prompt_tokens_details) ? parsed.usage.prompt_tokens_details : {};
        const completionDetails = isRecord4(parsed.usage.completion_tokens_details) ? parsed.usage.completion_tokens_details : {};
        const inputTokens = typeof parsed.usage.prompt_tokens === "number" ? parsed.usage.prompt_tokens : 0;
        const outputTokens = typeof parsed.usage.completion_tokens === "number" ? parsed.usage.completion_tokens : 0;
        const cachedTokens = typeof promptDetails.cached_tokens === "number" ? promptDetails.cached_tokens : 0;
        const inputMiss = inputTokens - cachedTokens;
        usage = {
          inputMissTokens: inputMiss > 0 ? inputMiss : null,
          inputHitTokens: cachedTokens > 0 ? cachedTokens : null,
          outputTokens: outputTokens > 0 ? outputTokens : null
        };
      }
      const choices = parsed.choices;
      if (!Array.isArray(choices) || choices.length === 0)
        continue;
      const delta = choices[0]?.delta;
      if (!isRecord4(delta))
        continue;
      if (typeof delta.content === "string") {
        content += delta.content;
      }
      if (typeof delta.reasoning_content === "string") {
        reasoningContent += delta.reasoning_content;
      }
      if (Array.isArray(delta.tool_calls)) {
        for (const tc of delta.tool_calls) {
          if (!isRecord4(tc))
            continue;
          const idx = typeof tc.index === "number" ? tc.index : toolCalls.length;
          const fn = isRecord4(tc.function) ? tc.function : {};
          if (!toolCalls[idx]) {
            toolCalls[idx] = {
              id: String(tc.id ?? ""),
              name: String(fn.name ?? ""),
              arguments: ""
            };
          }
          if (typeof fn.arguments === "string") {
            toolCalls[idx].arguments += fn.arguments;
          }
        }
      }
    } catch (err) {
      logger.debug("Failed to parse SSE event in OpenAI Chat stream", {
        error: String(err)
      });
    }
  }
  if (content === "" && toolCalls.length === 0 && reasoningContent === "") {
    return { messages: [], usage };
  }
  const blocks = [];
  if (reasoningContent) {
    blocks.push(createThinkingBlock(reasoningContent));
  }
  if (content) {
    blocks.push(createTextBlock(content));
  }
  for (const tc of toolCalls) {
    blocks.push(createToolCallBlock(tc.id, tc.name, tc.arguments));
  }
  if (blocks.length === 0) {
    blocks.push(createTextBlock(""));
  }
  return { messages: [createMsgEntry("assistant", blocks)], usage };
}
function sseOpenaiResponsesToMessages(raw) {
  const result = sseOpenaiResponsesParse(raw);
  return result.messages;
}
function sseOpenaiResponsesParse(raw) {
  const events = parseSSE(raw);
  const msgs = [];
  let currentText = "";
  let currentThinking = "";
  const toolCalls = [];
  const toolCallArgs = /* @__PURE__ */ new Map();
  let usage = null;
  for (const event of events) {
    if (!event.data)
      continue;
    try {
      const parsed = JSON.parse(event.data);
      if (!isRecord4(parsed))
        continue;
      const type = parsed.type;
      if (isRecord4(parsed.usage)) {
        const inputDetails = isRecord4(parsed.usage.input_tokens_details) ? parsed.usage.input_tokens_details : {};
        const inputTokens = typeof parsed.usage.input_tokens === "number" ? parsed.usage.input_tokens : 0;
        const outputTokens = typeof parsed.usage.output_tokens === "number" ? parsed.usage.output_tokens : 0;
        const cachedTokens = typeof inputDetails.cached_tokens === "number" ? inputDetails.cached_tokens : 0;
        const inputMiss = inputTokens - cachedTokens;
        usage = {
          inputMissTokens: inputMiss > 0 ? inputMiss : null,
          inputHitTokens: cachedTokens > 0 ? cachedTokens : null,
          outputTokens: outputTokens > 0 ? outputTokens : null
        };
      } else if (isRecord4(parsed.response) && isRecord4(parsed.response.usage)) {
        const respUsage = parsed.response.usage;
        const inputDetails = isRecord4(respUsage.input_tokens_details) ? respUsage.input_tokens_details : {};
        const inputTokens = typeof respUsage.input_tokens === "number" ? respUsage.input_tokens : 0;
        const outputTokens = typeof respUsage.output_tokens === "number" ? respUsage.output_tokens : 0;
        const cachedTokens = typeof inputDetails.cached_tokens === "number" ? inputDetails.cached_tokens : 0;
        const inputMiss = inputTokens - cachedTokens;
        usage = {
          inputMissTokens: inputMiss > 0 ? inputMiss : null,
          inputHitTokens: cachedTokens > 0 ? cachedTokens : null,
          outputTokens: outputTokens > 0 ? outputTokens : null
        };
      }
      if (type === "response.output_text.delta") {
        if (typeof parsed.delta === "string") {
          currentText += parsed.delta;
        }
      } else if (type === "response.reasoning_summary_text.delta") {
        if (typeof parsed.delta === "string") {
          currentThinking += parsed.delta;
        }
      } else if (type === "response.function_call_arguments.delta") {
        const outputIdx = typeof parsed.output_index === "number" ? parsed.output_index : -1;
        if (typeof parsed.delta === "string") {
          const existing = toolCallArgs.get(outputIdx);
          if (existing) {
            existing.args += parsed.delta;
          }
        }
      } else if (type === "response.output_item.added") {
        const item = parsed.item;
        if (isRecord4(item)) {
          if (item.type === "function_call") {
            const outputIdx = typeof parsed.output_index === "number" ? parsed.output_index : toolCallArgs.size;
            toolCallArgs.set(outputIdx, {
              id: String(item.id ?? item.call_id ?? ""),
              name: String(item.name ?? ""),
              args: ""
            });
          }
        }
      } else if (type === "response.output_item.done") {
        const item = parsed.item;
        if (isRecord4(item) && item.type === "function_call") {
          const outputIdx = typeof parsed.output_index === "number" ? parsed.output_index : -1;
          const entry = toolCallArgs.get(outputIdx);
          const finalArgs = typeof item.arguments === "string" ? item.arguments : entry?.args ?? "";
          toolCalls.push({
            id: String(item.id ?? item.call_id ?? entry?.id ?? ""),
            name: String(item.name ?? entry?.name ?? ""),
            arguments: finalArgs
          });
        }
      } else if (type === "response.completed") {
        if (currentText || currentThinking || toolCalls.length > 0) {
          const blocks = [];
          if (currentThinking) {
            blocks.push(createThinkingBlock(currentThinking));
          }
          if (currentText) {
            blocks.push(createTextBlock(currentText));
          }
          for (const tc of toolCalls) {
            blocks.push(createToolCallBlock(tc.id, tc.name, tc.arguments));
          }
          if (blocks.length === 0) {
            blocks.push(createTextBlock(""));
          }
          msgs.push(createMsgEntry("assistant", blocks));
        }
      }
    } catch (err) {
      logger.debug("Failed to parse SSE event in OpenAI Responses stream", {
        error: String(err)
      });
    }
  }
  if (msgs.length === 0 && (currentText || currentThinking || toolCalls.length > 0)) {
    const blocks = [];
    if (currentThinking) {
      blocks.push(createThinkingBlock(currentThinking));
    }
    if (currentText) {
      blocks.push(createTextBlock(currentText));
    }
    for (const tc of toolCalls) {
      blocks.push(createToolCallBlock(tc.id, tc.name, tc.arguments));
    }
    if (blocks.length === 0) {
      blocks.push(createTextBlock(""));
    }
    msgs.push(createMsgEntry("assistant", blocks));
  }
  return { messages: msgs, usage };
}
function sseAnthropicToMessages(raw) {
  const result = sseAnthropicParse(raw);
  return result.messages;
}
function sseAnthropicParse(raw) {
  const events = parseSSE(raw);
  let content = "";
  let thinking = "";
  const toolCalls = [];
  let usage = null;
  for (const event of events) {
    if (!event.data)
      continue;
    try {
      const parsed = JSON.parse(event.data);
      if (!isRecord4(parsed))
        continue;
      const type = parsed.type;
      const usageData = isRecord4(parsed.usage) ? parsed.usage : isRecord4(parsed.message) && isRecord4(parsed.message.usage) ? parsed.message.usage : null;
      if (usageData) {
        const inputTokens = typeof usageData.input_tokens === "number" ? usageData.input_tokens : 0;
        const outputTokens = typeof usageData.output_tokens === "number" ? usageData.output_tokens : 0;
        const cachedTokens = typeof usageData.cache_read_input_tokens === "number" ? usageData.cache_read_input_tokens : 0;
        const inputMiss = inputTokens - cachedTokens;
        usage = {
          inputMissTokens: inputMiss > 0 ? inputMiss : null,
          inputHitTokens: cachedTokens > 0 ? cachedTokens : null,
          outputTokens: outputTokens > 0 ? outputTokens : null
        };
      }
      if (type === "content_block_delta") {
        const delta = parsed.delta;
        if (isRecord4(delta)) {
          if (delta.type === "text_delta" && typeof delta.text === "string") {
            content += delta.text;
          } else if (delta.type === "thinking_delta" && typeof delta.thinking === "string") {
            thinking += delta.thinking;
          } else if (delta.type === "input_json_delta" && typeof delta.partial_json === "string") {
            if (toolCalls.length > 0) {
              toolCalls[toolCalls.length - 1].arguments += delta.partial_json;
            }
          }
        }
      } else if (type === "content_block_start") {
        const contentBlock = parsed.content_block;
        if (isRecord4(contentBlock)) {
          if (contentBlock.type === "tool_use") {
            toolCalls.push({
              id: String(contentBlock.id ?? ""),
              name: String(contentBlock.name ?? ""),
              arguments: ""
            });
          } else if (contentBlock.type === "thinking" && typeof contentBlock.thinking === "string") {
            thinking += contentBlock.thinking;
          }
        }
      }
    } catch (err) {
      logger.debug("Failed to parse SSE event in Anthropic stream", {
        error: String(err)
      });
    }
  }
  if (content === "" && toolCalls.length === 0 && thinking === "") {
    return { messages: [], usage };
  }
  const blocks = [];
  if (thinking) {
    blocks.push(createThinkingBlock(thinking));
  }
  if (content) {
    blocks.push(createTextBlock(content));
  }
  for (const tc of toolCalls) {
    blocks.push(createToolCallBlock(tc.id, tc.name, tc.arguments));
  }
  if (blocks.length === 0) {
    blocks.push(createTextBlock(""));
  }
  return { messages: [createMsgEntry("assistant", blocks)], usage };
}

// packages/core/dist/parse/detect.js
function isRecord5(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}
function fallbackParse(reqBody, resBody) {
  const msgs = [];
  if (isRecord5(reqBody) && Array.isArray(reqBody.messages)) {
    for (const msg of reqBody.messages) {
      if (isRecord5(msg)) {
        const blocks = [];
        if (typeof msg.content === "string") {
          blocks.push({ type: "text", text: msg.content });
        } else if (msg.content != null) {
          blocks.push({ type: "text", text: JSON.stringify(msg.content) });
        }
        if (blocks.length === 0) {
          blocks.push({ type: "text", text: "" });
        }
        const role = typeof msg.role === "string" ? msg.role : "user";
        msgs.push(createMsgEntry(role, blocks));
      }
    }
  }
  return {
    provider: "unknown",
    model: isRecord5(reqBody) && typeof reqBody.model === "string" ? reqBody.model : null,
    msgs,
    usage: null,
    stream: false
  };
}
function parseSSEMessagesWithUsage(provider, raw) {
  if (provider === "anthropic")
    return sseAnthropicParse(raw);
  if (provider === "openai-responses")
    return sseOpenaiResponsesParse(raw);
  return sseOpenaiChatParse(raw);
}
function isSSEBody(body) {
  return typeof body === "string" && body.includes("data:");
}
function detectAndParse(record) {
  const url = record.request.url;
  const reqBody = record.request.body;
  const resBody = record.response?.body;
  const parser = findParser(url);
  if (!parser)
    return fallbackParse(reqBody, resBody);
  const reqParsed = parser.parseRequest(reqBody);
  let responseMsgs = [];
  let responseModel;
  let responseUsage = reqParsed.usage;
  if (reqParsed.stream && isSSEBody(resBody)) {
    const sseResult = parseSSEMessagesWithUsage(parser.provider, resBody);
    responseMsgs = sseResult.messages;
    if (sseResult.usage)
      responseUsage = sseResult.usage;
  } else {
    const resParsed = parser.parseResponse(resBody);
    responseMsgs = resParsed.msgs ?? [];
    responseModel = resParsed.model;
    if (resParsed.usage)
      responseUsage = resParsed.usage;
  }
  const msgs = [...reqParsed.msgs, ...responseMsgs];
  return {
    provider: parser.provider,
    model: responseModel ?? reqParsed.model,
    sys: reqParsed.sys,
    tool: reqParsed.tool,
    msgs,
    usage: responseUsage,
    stream: reqParsed.stream
  };
}
function detectProvider(url, _body) {
  const parser = findParser(url);
  return parser?.provider ?? null;
}
function extractUsage2(record) {
  const url = record.request.url;
  const reqBody = record.request.body;
  const resBody = record.response?.body;
  const parser = findParser(url);
  if (!parser)
    return null;
  const reqParsed = parser.parseRequest(reqBody);
  let responseUsage = reqParsed.usage;
  if (reqParsed.stream && isSSEBody(resBody)) {
    const sseResult = parseSSEMessagesWithUsage(parser.provider, resBody);
    if (sseResult.usage)
      responseUsage = sseResult.usage;
  } else {
    const resParsed = parser.parseResponse(resBody);
    if (resParsed.usage)
      responseUsage = resParsed.usage;
  }
  return responseUsage;
}
function extractLatency(record) {
  if (record.requestSentAt === void 0 || record.firstTokenAt === void 0 || record.lastTokenAt === void 0) {
    return null;
  }
  const ttft = record.firstTokenAt - record.requestSentAt;
  const totalDuration = record.lastTokenAt - record.requestSentAt;
  const parsed = detectAndParse(record);
  const outputTokens = parsed?.usage?.outputTokens ?? null;
  let tpot = null;
  if (typeof outputTokens === "number" && outputTokens > 0) {
    tpot = (record.lastTokenAt - record.firstTokenAt) / outputTokens;
  }
  return {
    requestSentAt: record.requestSentAt,
    firstTokenAt: record.firstTokenAt,
    lastTokenAt: record.lastTokenAt,
    ttft,
    tpot,
    totalDuration
  };
}

// packages/core/dist/parse/index.js
var PARSED_CACHE_VERSION = "1";

// packages/core/dist/cache/read-cache.js
var ReadCache = class {
  maxSize;
  ttlMs;
  store = /* @__PURE__ */ new Map();
  constructor(options = {}) {
    this.maxSize = options.maxSize ?? 500;
    this.ttlMs = options.ttlMs ?? 5e3;
  }
  get(key, loader) {
    const now = Date.now();
    const hit = this.store.get(key);
    if (hit && hit.expiresAt > now) {
      this.store.delete(key);
      this.store.set(key, hit);
      return hit.value;
    }
    if (hit) {
      this.store.delete(key);
    }
    const value = loader();
    this.store.set(key, { value, expiresAt: now + this.ttlMs });
    this.enforceLimit();
    return value;
  }
  invalidate(key) {
    this.store.delete(key);
  }
  invalidateMatching(predicate) {
    let removed = 0;
    for (const key of this.store.keys()) {
      if (predicate(key)) {
        this.store.delete(key);
        removed++;
      }
    }
    return removed;
  }
  invalidateAll() {
    this.store.clear();
  }
  size() {
    return this.store.size;
  }
  enforceLimit() {
    while (this.store.size > this.maxSize) {
      const oldest = this.store.keys().next().value;
      if (oldest === void 0)
        break;
      this.store.delete(oldest);
    }
  }
};

// packages/core/dist/store/read.js
function resolveDir(options) {
  return options?.traceDir ?? getTraceDir();
}
var readCache = new ReadCache({ maxSize: 2e3, ttlMs: 5e3 });
function recordCacheKey(traceDir, sessionId, seq) {
  return `r:${traceDir}:${sessionId}:${seq}`;
}
function parsedCacheKey(traceDir, sessionId, seq) {
  return `p:${traceDir}:${sessionId}:${seq}`;
}
function sseCacheKey(traceDir, sessionId, seq) {
  return `s:${traceDir}:${sessionId}:${seq}`;
}
function timelineCacheKey(traceDir, sessionId) {
  return `t:${traceDir}:${sessionId}`;
}
function sessionPrefix(traceDir, sessionId) {
  return `:${traceDir}:${sessionId}`;
}
function invalidateReadCacheForSeq(traceDir, sessionId, seq) {
  readCache.invalidate(recordCacheKey(traceDir, sessionId, seq));
  readCache.invalidate(parsedCacheKey(traceDir, sessionId, seq));
  readCache.invalidate(sseCacheKey(traceDir, sessionId, seq));
  readCache.invalidate(timelineCacheKey(traceDir, sessionId));
}
function invalidateReadCacheForSession(traceDir, sessionId) {
  const prefix = sessionPrefix(traceDir, sessionId);
  readCache.invalidateMatching((k) => k.includes(prefix));
}
function invalidateAllReadCache() {
  readCache.invalidateAll();
}
function readCacheStats() {
  return { size: readCache.size() };
}
function safeReaddir(dir) {
  try {
    return readdirSync2(dir);
  } catch (err) {
    const errCode = err.code;
    if (errCode === "ENOENT") {
      logger.warn("Trace directory does not exist", { dir });
    } else {
      logger.error("Failed to read directory", { dir, error: String(err) });
    }
    return [];
  }
}
function safeReaddirWithTypes(dir) {
  try {
    return readdirSync2(dir, { withFileTypes: true });
  } catch (err) {
    const errCode = err.code;
    if (errCode === "ENOENT") {
      logger.warn("Trace directory does not exist", { dir });
    } else {
      logger.error("Failed to read directory", { dir, error: String(err) });
    }
    return [];
  }
}
function getManagerSync(traceDir) {
  return hasConfigManager(traceDir) ? getConfigManager(traceDir) : null;
}
function sessionStateToMeta(session) {
  return {
    id: session.id,
    requestCount: session.requestCount,
    createdAt: session.startedAt,
    updatedAt: session.endedAt,
    title: session.title,
    parentID: session.parentID,
    subSessions: session.subSessions,
    folderPath: session.folderPath
  };
}
function listSessions(options) {
  const base = resolveDir(options);
  const manager = getManagerSync(base);
  if (manager) {
    return manager.listSessions().map(sessionStateToMeta);
  }
  const entries = safeReaddirWithTypes(base);
  const sessions = [];
  for (const entry of entries) {
    if (!entry.isDirectory())
      continue;
    const full = join3(base, entry.name);
    try {
      let title;
      let parentID;
      let folderPath;
      try {
        const metaPath = join3(full, "metadata.json");
        const metaRaw = readFileSync2(metaPath, "utf-8");
        const meta = JSON.parse(metaRaw);
        title = meta.title;
        parentID = meta.parentID;
        folderPath = meta.folderPath;
      } catch {
      }
      let createdAt = null;
      let updatedAt = null;
      let requestCount = 0;
      let usedNdjson = false;
      const ndjsonPath = join3(full, "timeline.ndjson");
      if (existsSync2(ndjsonPath)) {
        try {
          const raw = readFileSync2(ndjsonPath, "utf-8");
          const lines = raw.split("\n").filter((l) => l.trim());
          if (lines.length > 0) {
            requestCount = lines.length;
            usedNdjson = true;
            let lastResponseAt = null;
            for (const line of lines) {
              try {
                const entry2 = JSON.parse(line);
                if (entry2.requestAt && (!createdAt || entry2.requestAt < createdAt)) {
                  createdAt = entry2.requestAt;
                }
                if (entry2.responseAt && (!lastResponseAt || entry2.responseAt > lastResponseAt)) {
                  lastResponseAt = entry2.responseAt;
                }
              } catch {
              }
            }
            updatedAt = lastResponseAt;
          }
        } catch {
        }
      }
      if (!usedNdjson) {
        const files = safeReaddir(full).filter((f) => /^\d+\.json$/.test(f));
        if (files.length === 0 && !title)
          continue;
        requestCount = files.length;
        for (const f of files) {
          try {
            const raw = readFileSync2(join3(full, f), "utf-8");
            const rec = JSON.parse(raw);
            if (!createdAt || rec.requestAt < createdAt)
              createdAt = rec.requestAt;
            if (!updatedAt || rec.responseAt > updatedAt)
              updatedAt = rec.responseAt;
          } catch (err) {
            logger.error("Failed to read record file for session listing", {
              sessionDir: full,
              file: f,
              error: String(err)
            });
          }
        }
      }
      sessions.push({
        id: entry.name,
        requestCount,
        createdAt,
        updatedAt,
        title,
        parentID,
        folderPath
      });
    } catch (err) {
      logger.error("Failed to process session entry for listing", {
        entry: entry.name,
        traceDir: base,
        error: String(err)
      });
    }
  }
  return sessions.sort((a, b) => (b.updatedAt ?? "").localeCompare(a.updatedAt ?? ""));
}
async function listSessionsAsync(options) {
  const base = resolveDir(options);
  const manager = getManagerSync(base);
  if (manager) {
    return manager.listSessions().map(sessionStateToMeta);
  }
  let entries;
  try {
    entries = await readdir(base, { withFileTypes: true });
  } catch (err) {
    const errCode = err.code;
    if (errCode === "ENOENT") {
      logger.warn("Trace directory does not exist", { dir: base });
    } else {
      logger.error("Failed to read directory", { dir: base, error: String(err) });
    }
    return [];
  }
  const sessions = [];
  for (const entry of entries) {
    if (!entry.isDirectory())
      continue;
    const full = join3(base, entry.name);
    try {
      let title;
      let parentID;
      let folderPath;
      try {
        const metaPath = join3(full, "metadata.json");
        const metaRaw = await readFile(metaPath, "utf-8");
        const meta = JSON.parse(metaRaw);
        title = meta.title;
        parentID = meta.parentID;
        folderPath = meta.folderPath;
      } catch {
      }
      let createdAt = null;
      let updatedAt = null;
      let requestCount = 0;
      let usedNdjson = false;
      const ndjsonPath = join3(full, "timeline.ndjson");
      try {
        const raw = await readFile(ndjsonPath, "utf-8");
        const lines = raw.split("\n").filter((l) => l.trim());
        if (lines.length > 0) {
          requestCount = lines.length;
          usedNdjson = true;
          let lastResponseAt = null;
          for (const line of lines) {
            try {
              const entry2 = JSON.parse(line);
              if (entry2.requestAt && (!createdAt || entry2.requestAt < createdAt)) {
                createdAt = entry2.requestAt;
              }
              if (entry2.responseAt && (!lastResponseAt || entry2.responseAt > lastResponseAt)) {
                lastResponseAt = entry2.responseAt;
              }
            } catch {
            }
          }
          updatedAt = lastResponseAt;
        }
      } catch {
      }
      if (!usedNdjson) {
        let files;
        try {
          const dirEntries = await readdir(full);
          files = dirEntries.filter((f) => /^\d+\.json$/.test(f));
        } catch {
          files = [];
        }
        if (files.length === 0 && !title)
          continue;
        requestCount = files.length;
        for (const f of files) {
          try {
            const raw = await readFile(join3(full, f), "utf-8");
            const rec = JSON.parse(raw);
            if (!createdAt || rec.requestAt < createdAt)
              createdAt = rec.requestAt;
            if (!updatedAt || rec.responseAt > updatedAt)
              updatedAt = rec.responseAt;
          } catch (err) {
            logger.error("Failed to read record file for session listing", {
              sessionDir: full,
              file: f,
              error: String(err)
            });
          }
        }
      }
      sessions.push({
        id: entry.name,
        requestCount,
        createdAt,
        updatedAt,
        title,
        parentID,
        folderPath
      });
    } catch (err) {
      logger.error("Failed to process session entry for listing", {
        entry: entry.name,
        traceDir: base,
        error: String(err)
      });
    }
  }
  return sessions.sort((a, b) => (b.updatedAt ?? "").localeCompare(a.updatedAt ?? ""));
}
function listSessionsTree(options) {
  const sessions = listSessions(options);
  const tree = [];
  for (const session of sessions) {
    if (!session.parentID) {
      const node = {
        ...session,
        children: sessions.filter((s) => s.parentID === session.id)
      };
      tree.push(node);
    }
  }
  return tree.sort((a, b) => (b.updatedAt ?? "").localeCompare(a.updatedAt ?? ""));
}
function getSessionRecords(sessionId, options) {
  const sessionDir = join3(resolveDir(options), sessionId);
  if (!existsSync2(sessionDir))
    return [];
  const files = safeReaddir(sessionDir).filter((f) => /^\d+\.json$/.test(f)).sort((a, b) => {
    const na = parseInt(a, 10);
    const nb = parseInt(b, 10);
    return na - nb;
  });
  const records = [];
  for (const f of files) {
    try {
      const raw = readFileSync2(join3(sessionDir, f), "utf-8");
      const parsed = TraceRecordSchema.safeParse(JSON.parse(raw));
      if (parsed.success) {
        records.push(parsed.data);
      }
    } catch (err) {
      logger.error("Failed to read session record", {
        sessionId,
        file: f,
        error: String(err)
      });
    }
  }
  return records;
}
async function getSessionRecordsAsync(sessionId, options) {
  const sessionDir = join3(resolveDir(options), sessionId);
  try {
    await readdir(sessionDir);
  } catch {
    return [];
  }
  let files;
  try {
    const entries = await readdir(sessionDir);
    files = entries.filter((f) => /^\d+\.json$/.test(f)).sort((a, b) => {
      const na = parseInt(a, 10);
      const nb = parseInt(b, 10);
      return na - nb;
    });
  } catch {
    return [];
  }
  const records = [];
  for (const f of files) {
    try {
      const raw = await readFile(join3(sessionDir, f), "utf-8");
      const parsed = TraceRecordSchema.safeParse(JSON.parse(raw));
      if (parsed.success) {
        records.push(parsed.data);
      }
    } catch (err) {
      logger.error("Failed to read session record", {
        sessionId,
        file: f,
        error: String(err)
      });
    }
  }
  return records;
}
function getRecord(sessionId, recordId, options) {
  const traceDir = resolveDir(options);
  return readCache.get(recordCacheKey(traceDir, sessionId, recordId), () => readRecordUncached(sessionId, recordId, traceDir));
}
function readRecordUncached(sessionId, recordId, traceDir) {
  const filePath = join3(traceDir, sessionId, `${recordId}.json`);
  try {
    const raw = readFileSync2(filePath, "utf-8");
    const parsed = TraceRecordSchema.safeParse(JSON.parse(raw));
    return parsed.success ? parsed.data : null;
  } catch (err) {
    logger.error("Failed to read record", {
      sessionId,
      recordId,
      filePath,
      error: String(err)
    });
    return null;
  }
}
function getSSEStream(sessionId, recordId, options) {
  const traceDir = resolveDir(options);
  return readCache.get(sseCacheKey(traceDir, sessionId, recordId), () => readSSEStreamUncached(sessionId, recordId, traceDir));
}
function readSSEStreamUncached(sessionId, recordId, traceDir) {
  const filePath = join3(traceDir, sessionId, `${recordId}.sse`);
  try {
    return readFileSync2(filePath, "utf-8");
  } catch (err) {
    logger.error("Failed to read SSE stream", {
      sessionId,
      recordId,
      filePath,
      error: String(err)
    });
    return null;
  }
}
function getTraceDir2(options) {
  return resolveDir(options);
}
function readTimelineIndex(sessionId, options) {
  const traceDir = resolveDir(options);
  return readCache.get(timelineCacheKey(traceDir, sessionId), () => readTimelineIndexUncached(sessionId, traceDir));
}
function readTimelineIndexUncached(sessionId, traceDir) {
  const sessionDir = join3(traceDir, sessionId);
  const indexPath = join3(sessionDir, "timeline.ndjson");
  if (!existsSync2(indexPath))
    return [];
  const entries = [];
  try {
    const raw = readFileSync2(indexPath, "utf-8");
    const lines = raw.split("\n");
    for (const line of lines) {
      if (!line.trim())
        continue;
      try {
        const entry = JSON.parse(line);
        entries.push(entry);
      } catch {
      }
    }
  } catch (err) {
    logger.error("Failed to read timeline index", {
      sessionId,
      indexPath,
      error: String(err)
    });
  }
  return entries;
}
function getCachedParsed(sessionId, seq, options) {
  const traceDir = resolveDir(options);
  return readCache.get(parsedCacheKey(traceDir, sessionId, seq), () => getCachedParsedUncached(sessionId, seq, traceDir));
}
function getCachedParsedUncached(sessionId, seq, traceDir) {
  const sessionDir = join3(traceDir, sessionId);
  const cachePath = join3(sessionDir, `${seq}.parsed`);
  if (!existsSync2(cachePath))
    return null;
  try {
    const jsonPath = join3(sessionDir, `${seq}.json`);
    if (existsSync2(jsonPath)) {
      const cacheStat = statSync(cachePath);
      const jsonStat = statSync(jsonPath);
      if (cacheStat.mtimeMs < jsonStat.mtimeMs) {
        return null;
      }
    }
    const raw = readFileSync2(cachePath, "utf-8");
    const data = JSON.parse(raw);
    if (data._pcv !== PARSED_CACHE_VERSION)
      return null;
    const { _pcv: _, ...clean } = data;
    return clean;
  } catch (err) {
    logger.error("Failed to read parsed cache", {
      sessionId,
      seq,
      cachePath,
      error: String(err)
    });
    return null;
  }
}
function readSessionMetadata(sessionId, traceDir) {
  const sessionDir = join3(traceDir, sessionId);
  const metadataPath = join3(sessionDir, "metadata.json");
  if (!existsSync2(metadataPath)) {
    return null;
  }
  try {
    const content = readFileSync2(metadataPath, "utf-8");
    const parsed = SessionMetadataFileSchema.safeParse(JSON.parse(content));
    if (parsed.success) {
      parsed.data.sessionId = sessionId;
      return parsed.data;
    }
    return null;
  } catch (err) {
    logger.error("Failed to read session metadata", {
      sessionId,
      metadataPath,
      error: String(err)
    });
    return null;
  }
}
function listSessionsFromBothDirs(options) {
  const { globalDir, localDir } = options;
  const globalSessions = listSessions({ traceDir: globalDir }).map((s) => ({
    ...s,
    scope: "global"
  }));
  if (!localDir) {
    return globalSessions;
  }
  const localSessions = listSessions({ traceDir: localDir }).map((s) => ({
    ...s,
    scope: "local"
  }));
  const sessionMap = /* @__PURE__ */ new Map();
  for (const session of globalSessions) {
    sessionMap.set(session.id, session);
  }
  for (const session of localSessions) {
    sessionMap.set(session.id, session);
  }
  return Array.from(sessionMap.values()).sort((a, b) => (b.updatedAt ?? "").localeCompare(a.updatedAt ?? ""));
}
function listSessionsTreeFromBothDirs(options) {
  const sessions = listSessionsFromBothDirs(options);
  const tree = [];
  for (const session of sessions) {
    if (!session.parentID) {
      const children = sessions.filter((s) => s.parentID === session.id);
      const node = {
        ...session,
        children
      };
      tree.push(node);
    }
  }
  return tree.sort((a, b) => (b.updatedAt ?? "").localeCompare(a.updatedAt ?? ""));
}
async function listSessionsFromBothDirsAsync(options) {
  const { globalDir, localDir } = options;
  const globalSessions = (await listSessionsAsync({ traceDir: globalDir })).map((s) => ({
    ...s,
    scope: "global"
  }));
  if (!localDir) {
    return globalSessions;
  }
  const localSessions = (await listSessionsAsync({ traceDir: localDir })).map((s) => ({
    ...s,
    scope: "local"
  }));
  const sessionMap = /* @__PURE__ */ new Map();
  for (const session of globalSessions) {
    sessionMap.set(session.id, session);
  }
  for (const session of localSessions) {
    sessionMap.set(session.id, session);
  }
  return Array.from(sessionMap.values()).sort((a, b) => (b.updatedAt ?? "").localeCompare(a.updatedAt ?? ""));
}
async function listSessionsTreeFromBothDirsAsync(options) {
  const sessions = await listSessionsFromBothDirsAsync(options);
  const tree = [];
  for (const session of sessions) {
    if (!session.parentID) {
      const children = sessions.filter((s) => s.parentID === session.id);
      const node = {
        ...session,
        children
      };
      tree.push(node);
    }
  }
  return tree.sort((a, b) => (b.updatedAt ?? "").localeCompare(a.updatedAt ?? ""));
}

// packages/core/dist/store/write.js
import { existsSync as existsSync3, mkdirSync as mkdirSync2, rmSync, writeFileSync as writeFileSync2 } from "node:fs";
import { join as join4 } from "node:path";
async function getManager(traceDir) {
  return initConfigManager(traceDir);
}
async function writeRecord(sessionId, seq, record, options) {
  const traceDir = resolveDir(options);
  const manager = await getManager(traceDir);
  await manager.writeRecord(sessionId, seq, record);
}
async function initStore(options) {
  const traceDir = resolveDir(options);
  await getManager(traceDir);
}
function writeSessionMetadata(sessionId, metadata, traceDir) {
  const sessionDir = join4(traceDir, sessionId);
  if (!existsSync3(sessionDir)) {
    mkdirSync2(sessionDir, { recursive: true });
  }
  const metadataPath = join4(sessionDir, "metadata.json");
  const data = { ...metadata, sessionId };
  writeFileSync2(metadataPath, JSON.stringify(data, null, 2), "utf-8");
}
async function deleteSession(sessionId, options) {
  const traceDir = resolveDir(options);
  const sessionDir = join4(traceDir, sessionId);
  if (!existsSync3(sessionDir)) {
    throw new Error("Session not found");
  }
  const metadata = readSessionMetadata(sessionId, traceDir);
  const storedSubSessions = metadata?.subSessions || [];
  const allSessions = listSessions({ traceDir });
  const discoveredChildren = allSessions.filter((s) => s.parentID === sessionId).map((s) => s.id);
  const allSubSessions = [
    .../* @__PURE__ */ new Set([...storedSubSessions, ...discoveredChildren])
  ];
  for (const childId of allSubSessions) {
    const childDir = join4(traceDir, childId);
    if (existsSync3(childDir)) {
      rmSync(childDir, { recursive: true });
    }
  }
  rmSync(sessionDir, { recursive: true });
}
async function deleteSessions(sessionIds, options) {
  const deleted = [];
  const errors = [];
  for (const sessionId of sessionIds) {
    try {
      await deleteSession(sessionId, options);
      deleted.push(sessionId);
    } catch (e) {
      errors.push({ sessionId, error: e.message });
    }
  }
  return { deleted, errors };
}
function writeParsedCache(sessionId, seq, parsed, options) {
  const sessionDir = join4(resolveDir(options), sessionId);
  if (!existsSync3(sessionDir)) {
    mkdirSync2(sessionDir, { recursive: true });
  }
  const cachePath = join4(sessionDir, `${seq}.parsed`);
  const data = { ...parsed, _pcv: PARSED_CACHE_VERSION };
  writeFileSync2(cachePath, JSON.stringify(data), "utf-8");
}

// packages/core/dist/store/export.js
import { readFileSync as readFileSync3, existsSync as existsSync4, mkdirSync as mkdirSync3, rmSync as rmSync2, writeFileSync as writeFileSync3 } from "node:fs";
import { join as join5 } from "node:path";
import archiver from "archiver";
import AdmZip from "adm-zip";
async function exportSessionZip(sessionId, options) {
  const traceDir = resolveDir(options);
  const sessionDir = join5(traceDir, sessionId);
  if (!existsSync4(sessionDir)) {
    throw new Error("Session not found");
  }
  const metadata = readSessionMetadata(sessionId, traceDir);
  const storedSubSessions = metadata?.subSessions || [];
  const allSessions = listSessions({ traceDir });
  const discoveredChildren = allSessions.filter((s) => s.parentID === sessionId).map((s) => s.id);
  const allSubSessions = [
    .../* @__PURE__ */ new Set([...storedSubSessions, ...discoveredChildren])
  ];
  const allSessionIds = [sessionId, ...allSubSessions];
  const manifest = {
    exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
    mainSession: sessionId,
    sessions: allSessionIds,
    version: "1.0"
  };
  return new Promise((resolve, reject) => {
    const archive = archiver("zip", { zlib: { level: 9 } });
    const chunks = [];
    archive.on("error", (err) => {
      reject(new Error("Failed to create archive: " + err.message));
    });
    archive.on("data", (chunk) => {
      chunks.push(chunk);
    });
    archive.on("end", () => {
      resolve(Buffer.concat(chunks));
    });
    for (const id of allSessionIds) {
      const dir = join5(traceDir, id);
      if (existsSync4(dir)) {
        archive.directory(dir, join5("sessions", id));
      }
    }
    archive.append(JSON.stringify(manifest, null, 2), {
      name: "manifest.json"
    });
    archive.finalize();
  });
}
async function importSessionZip(zipBuffer, options) {
  const traceDir = resolveDir(options);
  const strategy = options?.conflictStrategy ?? "prompt";
  const tempDir = join5(traceDir, ".temp-import-" + Date.now());
  mkdirSync3(tempDir, { recursive: true });
  try {
    const zip = new AdmZip(zipBuffer);
    zip.extractAllTo(tempDir, true);
  } catch (err) {
    logger.error("Failed to extract ZIP file", {
      traceDir,
      error: String(err)
    });
    rmSync2(tempDir, { recursive: true });
    throw new Error("Failed to extract ZIP file");
  }
  const manifestPath = join5(tempDir, "manifest.json");
  if (!existsSync4(manifestPath)) {
    rmSync2(tempDir, { recursive: true });
    throw new Error("Invalid export format: missing manifest.json");
  }
  const manifest = JSON.parse(readFileSync3(manifestPath, "utf-8"));
  const conflicts = [];
  for (const sessionId of manifest.sessions) {
    const existingDir = join5(traceDir, sessionId);
    if (existsSync4(existingDir)) {
      const existingMeta = readSessionMetadata(sessionId, traceDir);
      const importingMetaPath = join5(tempDir, "sessions", sessionId, "metadata.json");
      const importingMeta = existsSync4(importingMetaPath) ? JSON.parse(readFileSync3(importingMetaPath, "utf-8")) : null;
      const existingRecords = safeReaddir(existingDir).filter((f) => /^\d+\.json$/.test(f));
      const importingRecords = existsSync4(join5(tempDir, "sessions", sessionId)) ? safeReaddir(join5(tempDir, "sessions", sessionId)).filter((f) => /^\d+\.json$/.test(f)) : [];
      conflicts.push({
        sessionId,
        existing: {
          requestCount: existingRecords.length,
          createdAt: existingMeta?.createdAt ?? ""
        },
        importing: {
          requestCount: importingRecords.length,
          createdAt: importingMeta?.createdAt ?? ""
        }
      });
    }
  }
  if (conflicts.length > 0 && strategy === "prompt") {
    rmSync2(tempDir, { recursive: true });
    return { status: "conflict", conflicts };
  }
  const importedSessions = [];
  for (const sessionId of manifest.sessions) {
    const sourceDir = join5(tempDir, "sessions", sessionId);
    if (!existsSync4(sourceDir))
      continue;
    let targetId = sessionId;
    let actualStrategy = "none";
    if (existsSync4(join5(traceDir, sessionId))) {
      if (strategy === "skip") {
        actualStrategy = "skip";
        continue;
      } else if (strategy === "rename") {
        targetId = sessionId + "-imported";
        actualStrategy = "rename";
      } else if (strategy === "overwrite") {
        actualStrategy = "overwrite";
        rmSync2(join5(traceDir, sessionId), { recursive: true });
      }
    }
    const targetDir = join5(traceDir, targetId);
    mkdirSync3(targetDir, { recursive: true });
    const files = safeReaddir(sourceDir);
    for (const file of files) {
      writeFileSync3(join5(targetDir, file), readFileSync3(join5(sourceDir, file)));
    }
    const importedRecords = safeReaddir(targetDir).filter((f) => /^\d+\.json$/.test(f));
    importedSessions.push({
      sessionId,
      requestCount: importedRecords.length,
      strategy: actualStrategy,
      newId: actualStrategy === "rename" ? targetId : void 0
    });
  }
  rmSync2(tempDir, { recursive: true });
  return { status: "success", importedSessions };
}

// packages/core/dist/query/index.js
var query_exports = {};
__export(query_exports, {
  buildSessionMetadata: () => buildSessionMetadata,
  buildSessionTimeline: () => buildSessionTimeline,
  diffConversations: () => diffConversations
});

// packages/core/dist/query/session.js
function blockKey(block) {
  switch (block.type) {
    case "text":
      return `text:${block.text.slice(0, 50)}`;
    case "thinking":
      return `thinking:${block.thinking.slice(0, 50)}`;
    case "td":
      return `td:${block.name}`;
    case "tc":
      return `tc:${block.id}:${block.name}`;
    case "tr":
      return `tr:${block.toolCallId}`;
    case "image":
      return `image:${JSON.stringify(block.source).slice(0, 50)}`;
    case "other":
      return `other:${JSON.stringify(block.raw).slice(0, 50)}`;
    default:
      return `unknown`;
  }
}
function msgKey(msg) {
  return `${msg.id}:${msg.role ?? ""}`;
}
function diffConversations(prev, curr, currRequestId, requestMsgs) {
  const delta = { msgs: [] };
  if (prev.sys && curr.sys) {
    const prevKeys = new Set(prev.sys.blocks.map(blockKey));
    const currKeys = new Set(curr.sys.blocks.map(blockKey));
    const added = curr.sys.blocks.filter((b) => !prevKeys.has(blockKey(b)));
    const removed = prev.sys.blocks.filter((b) => !currKeys.has(blockKey(b)));
    if (added.length > 0 || removed.length > 0) {
      delta.sys = { id: prev.sys.id, added, removed };
    }
  } else if (!prev.sys && curr.sys) {
    delta.sys = { id: curr.sys.id, added: curr.sys.blocks, removed: [] };
  } else if (prev.sys && !curr.sys) {
    delta.sys = { id: prev.sys.id, added: [], removed: prev.sys.blocks };
  }
  if (prev.tool && curr.tool) {
    const prevKeys = new Set(prev.tool.blocks.map(blockKey));
    const currKeys = new Set(curr.tool.blocks.map(blockKey));
    const added = curr.tool.blocks.filter((b) => !prevKeys.has(blockKey(b)));
    const removed = prev.tool.blocks.filter((b) => !currKeys.has(blockKey(b)));
    if (added.length > 0 || removed.length > 0) {
      delta.tool = { id: prev.tool.id, added, removed };
    }
  } else if (!prev.tool && curr.tool) {
    delta.tool = { id: curr.tool.id, added: curr.tool.blocks, removed: [] };
  } else if (prev.tool && !curr.tool) {
    delta.tool = { id: prev.tool.id, added: [], removed: prev.tool.blocks };
  }
  const prevMsgKeys = /* @__PURE__ */ new Map();
  for (const msg of prev.msgs) {
    prevMsgKeys.set(msgKey(msg), msg);
  }
  const currMsgKeys = /* @__PURE__ */ new Map();
  for (const msg of curr.msgs) {
    currMsgKeys.set(msgKey(msg), msg);
  }
  for (const currMsg of curr.msgs) {
    const key = msgKey(currMsg);
    const prevMsg = prevMsgKeys.get(key);
    if (!prevMsg) {
      delta.msgs.push({ id: currMsg.id, added: currMsg.blocks, removed: [] });
    } else {
      const prevBlockKeys = new Set(prevMsg.blocks.map(blockKey));
      const currBlockKeys = new Set(currMsg.blocks.map(blockKey));
      const added = currMsg.blocks.filter((b) => !prevBlockKeys.has(blockKey(b)));
      const removed = prevMsg.blocks.filter((b) => !currBlockKeys.has(blockKey(b)));
      if (added.length > 0 || removed.length > 0) {
        delta.msgs.push({ id: currMsg.id, added, removed });
      }
    }
  }
  for (const prevMsg of prev.msgs) {
    const key = msgKey(prevMsg);
    if (!currMsgKeys.has(key)) {
      delta.msgs.push({ id: prevMsg.id, added: [], removed: prevMsg.blocks });
    }
  }
  const isUserCall = checkIsUserCall(requestMsgs ?? extractRequestMsgs(curr));
  return {
    requestId: currRequestId,
    delta,
    interRequestDuration: null,
    isUserCall
  };
}
function buildInitialChange(conv, requestId, requestMsgs) {
  const delta = { msgs: [] };
  if (conv.sys) {
    delta.sys = { id: conv.sys.id, added: conv.sys.blocks, removed: [] };
  }
  if (conv.tool) {
    delta.tool = { id: conv.tool.id, added: conv.tool.blocks, removed: [] };
  }
  for (const msg of conv.msgs) {
    delta.msgs.push({ id: msg.id, added: msg.blocks, removed: [] });
  }
  const isUserCall = checkIsUserCall(requestMsgs ?? extractRequestMsgs(conv));
  return { requestId, delta, interRequestDuration: null, isUserCall };
}
function checkIsUserCall(msgs) {
  if (msgs.length === 0)
    return false;
  const lastMsg = msgs[msgs.length - 1];
  if (!lastMsg.blocks || lastMsg.blocks.length === 0)
    return false;
  if (lastMsg.role === "tool")
    return false;
  if (lastMsg.blocks.some((b) => b.type === "tr" || b.type === "tc"))
    return false;
  return lastMsg.blocks.some((b) => b.type === "text" || b.type === "image");
}
function extractRequestMsgs(conv) {
  return conv.msgs.filter((m) => m.role !== "assistant");
}
function buildSessionTimeline(sessionId, records) {
  const changes = [];
  const previous = /* @__PURE__ */ new Map();
  for (const rec of [...records].sort((a, b) => a.id - b.id)) {
    const requestKind = /^\[(primary|title|compaction|generate)\]$/.exec(rec.purpose ?? "")?.[1] ?? "unknown";
    const prior = previous.get(requestKind);
    const prev = prior?.parsed;
    const prevRequestAt = prior?.requestAt;
    const curr = rec.parsed;
    const requestMsgs = rec.requestMsgs;
    const requestAt = rec.requestAt;
    let interRequestDuration = null;
    if (prevRequestAt && requestAt) {
      const prevTime = new Date(prevRequestAt).getTime();
      const currTime = new Date(requestAt).getTime();
      interRequestDuration = currTime - prevTime;
    }
    let change;
    if (!prev) {
      change = buildInitialChange(curr, rec.id, requestMsgs);
    } else {
      change = diffConversations(prev, curr, rec.id, requestMsgs);
    }
    change.interRequestDuration = interRequestDuration;
    change.requestKind = requestKind;
    changes.push(change);
    previous.set(requestKind, { parsed: curr, requestAt });
  }
  return {
    sessionId,
    totalRequests: records.length,
    changes
  };
}
function buildSessionMetadata(sessionId, records, folderPath) {
  let inputMissTokens = 0;
  let inputHitTokens = 0;
  let outputTokens = 0;
  const ttftValues = [];
  const tpotValues = [];
  const requestAtValues = [];
  const responseAtValues = [];
  const requestDurations = [];
  const isUserCallList = [];
  let prevResponseAtTime = null;
  for (const rec of records) {
    const usage = rec.parsed.usage;
    if (usage) {
      inputMissTokens += usage.inputMissTokens ?? 0;
      inputHitTokens += usage.inputHitTokens ?? 0;
      outputTokens += usage.outputTokens ?? 0;
    }
    if (rec.record) {
      const latency = extractLatency(rec.record);
      if (latency) {
        if (latency.ttft != null)
          ttftValues.push(latency.ttft);
        if (latency.tpot != null)
          tpotValues.push(latency.tpot);
      }
    }
    const effectiveRequestAt = rec.requestAt ?? rec.record?.requestAt;
    const effectiveResponseAt = rec.responseAt ?? rec.record?.responseAt;
    if (effectiveRequestAt && effectiveResponseAt) {
      requestAtValues.push(effectiveRequestAt);
      responseAtValues.push(effectiveResponseAt);
      const duration = new Date(effectiveResponseAt).getTime() - new Date(effectiveRequestAt).getTime();
      requestDurations.push(duration);
      prevResponseAtTime = new Date(effectiveResponseAt).getTime();
    }
    const isUser = checkIsUserCall(extractRequestMsgs(rec.parsed));
    isUserCallList.push(isUser);
  }
  const totalTokens = inputMissTokens + inputHitTokens + outputTokens;
  const totalInput = inputMissTokens + inputHitTokens;
  const cacheHitRate = totalInput > 0 ? inputHitTokens / totalInput : 0;
  let latencyStats = null;
  if (ttftValues.length > 0 || tpotValues.length > 0) {
    const avgTTFT = ttftValues.length > 0 ? ttftValues.reduce((a, b) => a + b, 0) / ttftValues.length : null;
    const maxTTFT = ttftValues.length > 0 ? Math.max(...ttftValues) : null;
    const avgTPOT = tpotValues.length > 0 ? tpotValues.reduce((a, b) => a + b, 0) / tpotValues.length : null;
    const maxTPOT = tpotValues.length > 0 ? Math.max(...tpotValues) : null;
    latencyStats = {
      avgTTFT,
      maxTTFT,
      avgTPOT,
      maxTPOT,
      streamRequestCount: ttftValues.length
    };
  }
  let durationStats = null;
  if (requestAtValues.length > 0 && responseAtValues.length > 0) {
    const minRequestAt = requestAtValues.reduce((a, b) => a < b ? a : b);
    const maxResponseAt = responseAtValues.reduce((a, b) => a > b ? a : b);
    const wallTime = new Date(maxResponseAt).getTime() - new Date(minRequestAt).getTime();
    const totalRequestDuration = requestDurations.reduce((a, b) => a + b, 0);
    let agentTime = totalRequestDuration;
    for (let i = 1; i < requestAtValues.length; i++) {
      if (!isUserCallList[i]) {
        const prevRespTime = new Date(responseAtValues[i - 1]).getTime();
        const currReqTime = new Date(requestAtValues[i]).getTime();
        agentTime += Math.max(0, currReqTime - prevRespTime);
      }
    }
    durationStats = {
      wallTime,
      agentTime,
      totalRequestDuration
    };
  }
  return {
    sessionId,
    tokenUsage: {
      inputMissTokens,
      inputHitTokens,
      outputTokens,
      totalTokens,
      cacheHitRate
    },
    latencyStats,
    durationStats,
    requestCount: records.length,
    subSessions: [],
    parentSession: null,
    createdAt: null,
    updatedAt: null,
    folderPath
  };
}

// packages/core/dist/record/index.js
var record_exports = {};
__export(record_exports, {
  getGlobalTraceEnabled: () => getGlobalTraceEnabled,
  getRecordingStatus: () => getRecordingStatus,
  getSessionEnabled: () => getSessionEnabled,
  getSessionStoragePreference: () => getSessionStoragePreference,
  getStoragePreference: () => getStoragePreference,
  initStateManager: () => initStateManager,
  isRecording: () => isRecording,
  listRecordings: () => listRecordings,
  setGlobalTraceEnabled: () => setGlobalTraceEnabled,
  setSessionEnabled: () => setSessionEnabled,
  setSessionStoragePreference: () => setSessionStoragePreference,
  setStoragePreference: () => setStoragePreference,
  shouldRecord: () => shouldRecord,
  startRecording: () => startRecording,
  stopRecording: () => stopRecording
});

// packages/core/dist/record/control.js
import { join as join6 } from "node:path";
import { existsSync as existsSync5, readdirSync as readdirSync3, readFileSync as readFileSync4, rmSync as rmSync3 } from "node:fs";
var RECORDING_MARKER = ".recording";
function resolveDir2(traceDir) {
  return traceDir ?? getTraceDir();
}
async function getManager2(traceDir) {
  return initConfigManager(traceDir);
}
function getManagerSync2(traceDir) {
  return hasConfigManager(traceDir) ? getConfigManager(traceDir) : null;
}
function sessionToRecording(session) {
  if (!session)
    return { active: false };
  return {
    active: session.status === "active",
    sessionId: session.id,
    startedAt: session.startedAt ?? void 0
  };
}
async function startRecording(sessionId, traceDir) {
  const dir = resolveDir2(traceDir);
  const manager = await getManager2(dir);
  return manager.startSession(sessionId);
}
function stopRecording(sessionId, traceDir) {
  const dir = resolveDir2(traceDir);
  const manager = getManagerSync2(dir);
  if (manager) {
    manager.stopSession(sessionId);
    return true;
  }
  const markerPath = join6(dir, sessionId, RECORDING_MARKER);
  if (!existsSync5(markerPath))
    return false;
  try {
    rmSync3(markerPath);
    return true;
  } catch (err) {
    logger.error("Failed to remove recording marker", {
      sessionId,
      markerPath,
      error: String(err)
    });
    return false;
  }
}
function setGlobalTraceEnabled(enabled, traceDir) {
  const dir = resolveDir2(traceDir);
  const manager = getManagerSync2(dir);
  if (manager) {
    manager.setGlobalState("global_trace_enabled", enabled ? "true" : "false");
  }
}
function getGlobalTraceEnabled(traceDir) {
  const dir = resolveDir2(traceDir);
  const manager = getManagerSync2(dir);
  if (manager) {
    return manager.getGlobalState("global_trace_enabled") === "true";
  }
  return true;
}
function setSessionEnabled(sessionId, enabled, traceDir) {
  const dir = resolveDir2(traceDir);
  const manager = getManagerSync2(dir);
  if (manager) {
    manager.setSessionEnabled(sessionId, enabled);
  }
}
function getSessionEnabled(sessionId, traceDir) {
  const dir = resolveDir2(traceDir);
  const manager = getManagerSync2(dir);
  if (manager) {
    return manager.getSessionEnabled(sessionId);
  }
  return true;
}
function shouldRecord(sessionId, traceDir) {
  const dir = resolveDir2(traceDir);
  const manager = getManagerSync2(dir);
  if (manager) {
    return manager.isTraceEnabled(sessionId);
  }
  return true;
}
function setStoragePreference(preference, traceDir) {
  const dir = resolveDir2(traceDir);
  const manager = getManagerSync2(dir);
  if (manager) {
    manager.setStoragePreference(preference);
  }
}
function getStoragePreference(traceDir) {
  const dir = resolveDir2(traceDir);
  const manager = getManagerSync2(dir);
  if (manager) {
    return manager.getStoragePreference();
  }
  return "global";
}
function setSessionStoragePreference(sessionId, preference, traceDir) {
  const dir = resolveDir2(traceDir);
  const manager = getManagerSync2(dir);
  if (manager) {
    manager.setSessionStoragePreference(sessionId, preference);
  }
}
function getSessionStoragePreference(sessionId, traceDir) {
  const dir = resolveDir2(traceDir);
  const manager = getManagerSync2(dir);
  if (manager) {
    return manager.getSessionStoragePreference(sessionId);
  }
  return null;
}
function isRecording(sessionId, traceDir) {
  const dir = resolveDir2(traceDir);
  const manager = getManagerSync2(dir);
  if (manager) {
    const session = manager.getSession(sessionId);
    return session?.status === "active";
  }
  const markerPath = join6(dir, sessionId, RECORDING_MARKER);
  return existsSync5(markerPath);
}
function getRecordingStatus(sessionId, traceDir) {
  const dir = resolveDir2(traceDir);
  const manager = getManagerSync2(dir);
  if (manager) {
    return sessionToRecording(manager.getSession(sessionId));
  }
  const markerPath = join6(dir, sessionId, RECORDING_MARKER);
  if (!existsSync5(markerPath))
    return { active: false };
  try {
    const raw = readFileSync4(markerPath, "utf-8");
    const data = JSON.parse(raw);
    return {
      active: true,
      sessionId,
      startedAt: data.startedAt
    };
  } catch (err) {
    logger.error("Failed to read recording marker", {
      sessionId,
      markerPath,
      error: String(err)
    });
    return { active: true, sessionId };
  }
}
function listRecordings(traceDir) {
  const dir = resolveDir2(traceDir);
  const manager = getManagerSync2(dir);
  if (manager) {
    return manager.listSessions().filter((s) => s.status === "active").map(sessionToRecording);
  }
  const base = dir;
  try {
    const entries = readdirSync3(base);
    const results = [];
    for (const entry of entries) {
      const markerPath = join6(base, entry, RECORDING_MARKER);
      if (existsSync5(markerPath)) {
        results.push(getRecordingStatus(entry, traceDir));
      }
    }
    return results;
  } catch (err) {
    logger.error("Failed to list recordings from filesystem", {
      traceDir: base,
      error: String(err)
    });
    return [];
  }
}
async function initStateManager(traceDir) {
  const dir = resolveDir2(traceDir);
  await getManager2(dir);
}

// packages/core/dist/schemas/parse-types.js
import { z as z3 } from "zod";
var TextBlockSchema = z3.object({
  type: z3.literal("text"),
  text: z3.string()
});
var ThinkingBlockSchema = z3.object({
  type: z3.literal("thinking"),
  thinking: z3.string()
});
var ToolDefinitionBlockSchema = z3.object({
  type: z3.literal("td"),
  name: z3.string(),
  description: z3.string().nullable(),
  inputSchema: z3.unknown()
});
var ToolCallBlockSchema = z3.object({
  type: z3.literal("tc"),
  id: z3.string(),
  name: z3.string(),
  arguments: z3.string()
});
var ToolResultBlockSchema = z3.object({
  type: z3.literal("tr"),
  toolCallId: z3.string(),
  content: z3.string()
});
var ImageBlockSchema = z3.object({
  type: z3.literal("image"),
  source: z3.unknown()
});
var OtherBlockSchema = z3.object({
  type: z3.literal("other"),
  raw: z3.unknown()
});
var BlockSchema = z3.discriminatedUnion("type", [
  TextBlockSchema,
  ThinkingBlockSchema,
  ToolDefinitionBlockSchema,
  ToolCallBlockSchema,
  ToolResultBlockSchema,
  ImageBlockSchema,
  OtherBlockSchema
]);
var EntrySchema = z3.object({
  id: z3.string(),
  role: z3.enum(["user", "assistant", "tool"]).optional(),
  blocks: z3.array(BlockSchema)
});
var UsageSchema = z3.object({
  inputMissTokens: z3.number().nullable(),
  inputHitTokens: z3.number().nullable(),
  outputTokens: z3.number().nullable()
});
var ConversationSchema = z3.object({
  provider: z3.string(),
  model: z3.string().nullable(),
  sys: EntrySchema.optional(),
  tool: EntrySchema.optional(),
  msgs: z3.array(EntrySchema),
  usage: UsageSchema.nullable(),
  stream: z3.boolean()
});

// packages/core/dist/schemas/query-types.js
import { z as z4 } from "zod";
var EntryDeltaSchema = z4.object({
  id: z4.string(),
  added: z4.array(BlockSchema).optional(),
  removed: z4.array(BlockSchema).optional()
});
var DeltaSchema = z4.object({
  sys: EntryDeltaSchema.optional(),
  tool: EntryDeltaSchema.optional(),
  msgs: z4.array(EntryDeltaSchema)
});
var RequestChangeSchema = z4.object({
  requestId: z4.number().int().positive(),
  delta: DeltaSchema,
  interRequestDuration: z4.number().nullable(),
  isUserCall: z4.boolean(),
  requestKind: z4.string().optional()
});
var SessionTimelineSchema = z4.object({
  sessionId: z4.string(),
  totalRequests: z4.number().int().nonnegative(),
  changes: z4.array(RequestChangeSchema)
});
var TokenUsageSchema = z4.object({
  inputMissTokens: z4.number(),
  inputHitTokens: z4.number(),
  outputTokens: z4.number(),
  totalTokens: z4.number(),
  cacheHitRate: z4.number()
});
var LatencyStatsSchema = z4.object({
  avgTTFT: z4.number().nullable(),
  maxTTFT: z4.number().nullable(),
  avgTPOT: z4.number().nullable(),
  maxTPOT: z4.number().nullable(),
  streamRequestCount: z4.number().int().nonnegative()
});
var DurationStatsSchema = z4.object({
  wallTime: z4.number(),
  agentTime: z4.number(),
  totalRequestDuration: z4.number()
});
var SessionMetadataSchema = z4.object({
  sessionId: z4.string(),
  tokenUsage: TokenUsageSchema,
  requestCount: z4.number().int().nonnegative(),
  subSessions: z4.array(z4.string()),
  parentSession: z4.string().nullable(),
  createdAt: z4.string().nullable(),
  updatedAt: z4.string().nullable(),
  folderPath: z4.string().optional(),
  latencyStats: LatencyStatsSchema.nullable(),
  durationStats: DurationStatsSchema.nullable()
});
var TimelineRecordSchema = z4.object({
  purpose: z4.string().optional(),
  id: z4.number().int().positive(),
  requestAt: z4.string().optional(),
  requestMsgs: z4.array(EntrySchema).optional(),
  parsed: z4.object({
    provider: z4.string(),
    model: z4.string().nullable(),
    msgs: z4.array(EntrySchema)
  }).passthrough()
});

// packages/viewer/dist/server.js
var __dirname = dirname(fileURLToPath(import.meta.url));
function validateSessionId(sessionId) {
  return typeof sessionId === "string" && sessionId.length > 0 && sessionId.length <= 256 && /^[a-zA-Z0-9_-]+$/.test(sessionId);
}
function validateRecordId(recordId) {
  const num = parseInt(recordId, 10);
  return { valid: !isNaN(num) && num > 0 && num <= 999999, value: num };
}
function validateParams(reply, sessionId, recordId) {
  if (!validateSessionId(sessionId)) {
    reply.code(400);
    reply.send({ error: "Invalid session ID format" });
    return null;
  }
  if (recordId !== void 0) {
    const result = validateRecordId(recordId);
    if (!result.valid) {
      reply.code(400);
      reply.send({ error: "Invalid record ID format" });
      return null;
    }
    return result.value;
  }
  return 0;
}
async function createViewer(options) {
  const port = options?.port ?? 3210;
  const globalDir = options?.globalDir ?? options?.traceDir ?? getTraceDir();
  const localDir = options?.localDir ?? options?.traceDir;
  const bothDirsOpts = { globalDir, localDir };
  const sseClients = /* @__PURE__ */ new Set();
  const sseKeepAlive = setInterval(() => {
    for (const client of sseClients) {
      try {
        client.reply.raw.write(": heartbeat\n\n");
      } catch {
        sseClients.delete(client);
      }
    }
  }, 15e3);
  let clientIdCounter = 0;
  function broadcastSSE(event, data) {
    const payload = `event: ${event}
data: ${JSON.stringify(data)}

`;
    for (const client of sseClients) {
      try {
        client.reply.raw.write(payload);
      } catch {
        sseClients.delete(client);
      }
    }
  }
  async function findSessionTraceDir(sessionId) {
    if (localDir) {
      const localMeta = store_exports.readSessionMetadata(sessionId, localDir);
      if (localMeta)
        return localDir;
      const localRecords = await store_exports.getSessionRecordsAsync(sessionId, {
        traceDir: localDir
      });
      if (localRecords.length > 0)
        return localDir;
    }
    const globalMeta = store_exports.readSessionMetadata(sessionId, globalDir);
    if (globalMeta)
      return globalDir;
    const globalRecords = await store_exports.getSessionRecordsAsync(sessionId, {
      traceDir: globalDir
    });
    if (globalRecords.length > 0)
      return globalDir;
    return null;
  }
  async function validateSessionAndFindDir(reply, sessionId) {
    if (!validateSessionId(sessionId)) {
      reply.code(400);
      reply.send({ error: "Invalid session ID format" });
      return null;
    }
    const sessionTraceDir = await findSessionTraceDir(sessionId);
    if (!sessionTraceDir) {
      reply.code(404);
      reply.send({ error: "Session not found" });
      return null;
    }
    return sessionTraceDir;
  }
  const app = Fastify({ logger: false });
  await app.register(cors, {
    origin: options?.corsOrigin ?? [/^https?:\/\/localhost(:\d+)?$/]
  });
  await app.register(rateLimit, {
    max: 1e3,
    timeWindow: "1 minute",
    allowList: ["127.0.0.1", "::1"]
  });
  await app.register(multipart);
  const apiKey = options?.apiKey;
  if (apiKey) {
    app.addHook("onRequest", async (req, reply) => {
      if (!req.url.startsWith("/api/"))
        return;
      const provided = req.headers["x-api-key"] || req.query?.key || "";
      if (provided !== apiKey) {
        reply.code(401).send({ error: "Unauthorized" });
      }
    });
  }
  const publicDir = join7(__dirname, "public");
  if (existsSync6(publicDir)) {
    await app.register(fastifyStatic, {
      root: publicDir,
      prefix: "/"
    });
  }
  app.setNotFoundHandler(async (_req, reply) => {
    const indexPath = join7(publicDir, "index.html");
    if (existsSync6(indexPath)) {
      let html = readFileSync5(indexPath, "utf-8");
      if (apiKey) {
        html = html.replace("</head>", `<script>window.__TRACE_API_KEY__ = ${JSON.stringify(apiKey)};</script></head>`);
      }
      reply.type("text/html; charset=utf-8").send(html);
    } else {
      reply.code(404).send({ error: "Not found" });
    }
  });
  app.get("/api/sessions", async (_req, reply) => {
    const sessions = await store_exports.listSessionsFromBothDirsAsync(bothDirsOpts);
    return sessions;
  });
  app.get("/api/sessions/tree", async (_req, reply) => {
    const tree = await store_exports.listSessionsTreeFromBothDirsAsync(bothDirsOpts);
    return tree;
  });
  app.get("/api/sessions/:sessionId/timeline", async (req, reply) => {
    const { sessionId } = req.params;
    if (!validateSessionId(sessionId)) {
      reply.code(400);
      return { error: "Invalid session ID format" };
    }
    const sessionTraceDir = await findSessionTraceDir(sessionId);
    if (!sessionTraceDir) {
      reply.code(404);
      return { error: "Session not found" };
    }
    const timelineEntries = store_exports.readTimelineIndex(sessionId, {
      traceDir: sessionTraceDir
    });
    if (timelineEntries.length > 0) {
      const timelineRecords = [];
      for (const entry of timelineEntries) {
        const cached = store_exports.getCachedParsed(sessionId, entry.seq, {
          traceDir: sessionTraceDir
        });
        if (cached) {
          timelineRecords.push({
            id: entry.seq,
            purpose: entry.purpose,
            requestAt: entry.requestAt,
            parsed: cached
          });
        } else {
          const rec = store_exports.getRecord(sessionId, entry.seq, {
            traceDir: sessionTraceDir
          });
          if (rec) {
            const parsed = parse_exports.detectAndParse(rec);
            timelineRecords.push({
              id: rec.id,
              purpose: rec.purpose,
              requestAt: rec.requestAt,
              parsed
            });
            setImmediate(() => {
              try {
                store_exports.writeParsedCache(sessionId, entry.seq, parsed, { traceDir: sessionTraceDir });
              } catch {
              }
            });
          }
        }
      }
      const timeline2 = query_exports.buildSessionTimeline(sessionId, timelineRecords);
      const recordMeta2 = timelineRecords.map((r) => ({
        id: r.id,
        model: r.parsed.model,
        provider: r.parsed.provider
      }));
      return { ...timeline2, recordMeta: recordMeta2 };
    }
    const records = await store_exports.getSessionRecordsAsync(sessionId, {
      traceDir: sessionTraceDir
    });
    const parsedRecords = records.map((rec) => {
      const parsed = parse_exports.detectAndParse(rec);
      const provider = parse_exports.detectProvider(rec.request.url, rec.request.body);
      let requestMsgs = parsed.msgs;
      if (provider === "openai-chat") {
        const reqParsed = parse_exports.openaiChatParser.parseRequest(rec.request.body);
        requestMsgs = reqParsed.msgs;
      } else if (provider === "openai-responses") {
        const reqParsed = parse_exports.openaiResponsesParser.parseRequest(rec.request.body);
        requestMsgs = reqParsed.msgs;
      } else if (provider === "anthropic") {
        const reqParsed = parse_exports.anthropicParser.parseRequest(rec.request.body);
        requestMsgs = reqParsed.msgs;
      }
      return {
        id: rec.id,
        purpose: rec.purpose,
        requestAt: rec.requestAt,
        requestMsgs,
        parsed
      };
    }).filter((c) => c.parsed.provider !== "unknown" || c.parsed.msgs.length > 0);
    const ndjsonSessionDir = join7(sessionTraceDir, sessionId);
    const ndjsonLines = [];
    for (const rec of records) {
      try {
        ndjsonLines.push(JSON.stringify({
          seq: rec.id,
          url: rec.request.url,
          method: rec.request.method,
          purpose: rec.purpose,
          requestAt: rec.requestAt,
          responseAt: rec.responseAt,
          status: rec.response?.status ?? 0,
          provider: parse_exports.detectProvider(rec.request.url, rec.request.body),
          model: null,
          inputTokens: null,
          outputTokens: null,
          totalDurationMs: null
        }));
      } catch {
      }
    }
    setImmediate(async () => {
      try {
        if (ndjsonLines.length > 0) {
          await fs3.writeFile(join7(ndjsonSessionDir, "timeline.ndjson"), ndjsonLines.join("\n") + "\n");
        }
      } catch {
      }
    });
    const timeline = query_exports.buildSessionTimeline(sessionId, parsedRecords);
    const recordMeta = parsedRecords.map((r) => ({
      id: r.id,
      model: r.parsed.model,
      provider: r.parsed.provider
    }));
    return { ...timeline, recordMeta };
  });
  app.get("/api/sessions/:sessionId/metadata", async (req, reply) => {
    const { sessionId } = req.params;
    if (!validateSessionId(sessionId)) {
      reply.code(400);
      return { error: "Invalid session ID format" };
    }
    const sessionTraceDir = await findSessionTraceDir(sessionId);
    if (!sessionTraceDir) {
      reply.code(404);
      return { error: "Session not found" };
    }
    const timelineEntries = store_exports.readTimelineIndex(sessionId, {
      traceDir: sessionTraceDir
    });
    const metaRecords = [];
    if (timelineEntries.length > 0) {
      for (const entry of timelineEntries) {
        const cached = store_exports.getCachedParsed(sessionId, entry.seq, {
          traceDir: sessionTraceDir
        });
        if (cached) {
          metaRecords.push({
            id: entry.seq,
            record: void 0,
            parsed: cached,
            requestAt: entry.requestAt,
            responseAt: entry.responseAt ?? void 0
          });
        } else {
          const rec = store_exports.getRecord(sessionId, entry.seq, {
            traceDir: sessionTraceDir
          });
          if (rec) {
            const parsed = parse_exports.detectAndParse(rec);
            metaRecords.push({ id: entry.seq, record: rec, parsed });
            setImmediate(() => {
              try {
                store_exports.writeParsedCache(sessionId, entry.seq, parsed, { traceDir: sessionTraceDir });
              } catch {
              }
            });
          }
        }
      }
    } else {
      const records = await store_exports.getSessionRecordsAsync(sessionId, {
        traceDir: sessionTraceDir
      });
      for (const rec of records) {
        const parsed = parse_exports.detectAndParse(rec);
        metaRecords.push({ id: rec.id, record: rec, parsed });
        setImmediate(() => {
          try {
            store_exports.writeParsedCache(sessionId, rec.id, parsed, { traceDir: sessionTraceDir });
          } catch {
          }
        });
      }
    }
    const filtered = metaRecords.filter((r) => r.parsed.provider !== "unknown" || r.parsed.msgs.length > 0);
    const sessions = await store_exports.listSessionsFromBothDirsAsync(bothDirsOpts);
    const sessionMeta = sessions.find((s) => s.id === sessionId);
    const tree = await store_exports.listSessionsTreeFromBothDirsAsync(bothDirsOpts);
    const node = tree.find((n) => n.id === sessionId);
    const metadata = query_exports.buildSessionMetadata(sessionId, filtered, sessionMeta?.folderPath);
    if (sessionMeta) {
      metadata.createdAt = sessionMeta.createdAt;
      metadata.updatedAt = sessionMeta.updatedAt;
      metadata.subSessions = node?.children?.map((c) => c.id) ?? [];
      metadata.parentSession = sessionMeta.parentID ?? null;
    }
    return metadata;
  });
  app.get("/api/sessions/:sessionId/records/:recordId/parsed", async (req, reply) => {
    const { sessionId, recordId } = req.params;
    const rid = validateParams(reply, sessionId, recordId);
    if (rid === null)
      return;
    const sessionTraceDir = await validateSessionAndFindDir(reply, sessionId);
    if (sessionTraceDir === null)
      return;
    const cached = store_exports.getCachedParsed(sessionId, rid, {
      traceDir: sessionTraceDir
    });
    if (cached)
      return cached;
    const rec = store_exports.getRecord(sessionId, rid, {
      traceDir: sessionTraceDir
    });
    if (!rec) {
      reply.code(404);
      return { error: "Record not found" };
    }
    const parsed = parse_exports.detectAndParse(rec);
    setImmediate(() => {
      try {
        store_exports.writeParsedCache(sessionId, rid, parsed, { traceDir: sessionTraceDir });
      } catch {
      }
    });
    return parsed;
  });
  app.get("/api/sessions/:sessionId/records/:recordId/usage", async (req, reply) => {
    const { sessionId, recordId } = req.params;
    const rid = validateParams(reply, sessionId, recordId);
    if (rid === null)
      return;
    const sessionTraceDir = await validateSessionAndFindDir(reply, sessionId);
    if (sessionTraceDir === null)
      return;
    const rec = store_exports.getRecord(sessionId, rid, {
      traceDir: sessionTraceDir
    });
    if (!rec) {
      reply.code(404);
      return { error: "Record not found" };
    }
    const usage = parse_exports.extractUsage(rec);
    return usage;
  });
  app.get("/api/sessions/:sessionId/records/:recordId/latency", async (req, reply) => {
    const { sessionId, recordId } = req.params;
    const rid = validateParams(reply, sessionId, recordId);
    if (rid === null)
      return;
    const sessionTraceDir = await validateSessionAndFindDir(reply, sessionId);
    if (sessionTraceDir === null)
      return;
    const rec = store_exports.getRecord(sessionId, rid, {
      traceDir: sessionTraceDir
    });
    if (!rec) {
      reply.code(404);
      return { error: "Record not found" };
    }
    const latency = parse_exports.extractLatency(rec);
    return latency ?? { error: "No latency data available" };
  });
  app.get("/api/sessions/:sessionId/records/:recordId/sse", async (req, reply) => {
    const { sessionId, recordId } = req.params;
    const rid = validateParams(reply, sessionId, recordId);
    if (rid === null)
      return;
    const sessionTraceDir = await validateSessionAndFindDir(reply, sessionId);
    if (sessionTraceDir === null)
      return;
    const sseData = store_exports.getSSEStream(sessionId, rid, {
      traceDir: sessionTraceDir
    });
    if (!sseData) {
      reply.code(404);
      return { error: "No SSE data found" };
    }
    const rec = store_exports.getRecord(sessionId, rid, {
      traceDir: sessionTraceDir
    });
    const provider = rec?.request ? parse_exports.detectProvider(rec.request.url, rec.request.body) : null;
    let messages;
    if (provider === "anthropic") {
      messages = transform_exports.sseAnthropicToMessages(sseData);
    } else if (provider === "openai-responses") {
      messages = transform_exports.sseOpenaiResponsesToMessages(sseData);
    } else {
      messages = transform_exports.sseOpenaiChatToMessages(sseData);
    }
    return { raw: sseData, messages };
  });
  app.get("/api/sessions/:sessionId/records/:recordId", async (req, reply) => {
    const { sessionId, recordId } = req.params;
    const rid = validateParams(reply, sessionId, recordId);
    if (rid === null)
      return;
    const sessionTraceDir = await validateSessionAndFindDir(reply, sessionId);
    if (sessionTraceDir === null)
      return;
    const rec = store_exports.getRecord(sessionId, rid, {
      traceDir: sessionTraceDir
    });
    if (!rec) {
      reply.code(404);
      return { error: "Record not found" };
    }
    return rec;
  });
  app.get("/api/sessions/:sessionId", async (req, reply) => {
    const { sessionId } = req.params;
    if (!validateSessionId(sessionId)) {
      reply.code(400);
      return { error: "Invalid session ID format" };
    }
    const sessionTraceDir = await findSessionTraceDir(sessionId);
    const sessions = await store_exports.listSessionsFromBothDirsAsync(bothDirsOpts);
    const sessionMeta = sessions.find((s) => s.id === sessionId);
    const records = sessionTraceDir ? await store_exports.getSessionRecordsAsync(sessionId, { traceDir: sessionTraceDir }) : [];
    const enriched = records.map((rec) => ({
      ...rec,
      provider: rec?.request ? parse_exports.detectProvider(rec.request.url, rec.request.body) : null
    }));
    return {
      session: sessionMeta ?? {
        id: sessionId,
        requestCount: records.length,
        createdAt: null,
        updatedAt: null
      },
      records: enriched
    };
  });
  app.get("/api/trace/status", async (_req, reply) => {
    const enabled = record_exports.getGlobalTraceEnabled(globalDir);
    return { globalEnabled: enabled };
  });
  app.get("/api/trace/enable", async (_req, reply) => {
    record_exports.setGlobalTraceEnabled(true, globalDir);
    return { success: true, globalEnabled: true };
  });
  app.get("/api/trace/disable", async (_req, reply) => {
    record_exports.setGlobalTraceEnabled(false, globalDir);
    return { success: true, globalEnabled: false };
  });
  app.get("/api/trace-dir", async (_req, reply) => {
    return { traceDir: globalDir, localDir };
  });
  app.get("/api/events", async (req, reply) => {
    const clientId = String(++clientIdCounter);
    const client = { id: clientId, reply };
    reply.raw.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no"
    });
    reply.raw.write(`event: connected
data: {"clientId":"${clientId}"}

`);
    sseClients.add(client);
    req.raw.on("close", () => {
      sseClients.delete(client);
    });
  });
  app.post("/api/sessions/:sessionId/export", async (req, reply) => {
    try {
      const { sessionId } = req.params;
      if (!validateSessionId(sessionId)) {
        reply.code(400);
        return { error: "Invalid session ID format" };
      }
      const sessionTraceDir = await findSessionTraceDir(sessionId);
      if (!sessionTraceDir) {
        reply.code(404);
        return { error: "Session not found" };
      }
      const buffer = await store_exports.exportSessionZip(sessionId, {
        traceDir: sessionTraceDir
      });
      reply.type("application/zip").header("Content-Disposition", `attachment; filename="session-${sessionId}.zip"`).send(buffer);
    } catch (e) {
      const err = e;
      if (err.message === "Session not found") {
        reply.code(404);
        return { error: "Session not found" };
      }
      reply.code(500);
      return { error: "Export failed: " + err.message };
    }
  });
  app.post("/api/sessions/import", async (req, reply) => {
    try {
      const data = await req.file();
      if (!data) {
        reply.code(400);
        return { error: "No file in multipart data" };
      }
      const fileBuffer = await data.toBuffer();
      const conflictStrategy = data.fields.conflictStrategy?.value ?? "prompt";
      const validStrategies = ["prompt", "rename", "skip", "overwrite"];
      if (!validStrategies.includes(conflictStrategy)) {
        reply.code(400);
        return {
          error: `Invalid conflict strategy: ${conflictStrategy}. Valid: ${validStrategies.join(", ")}`
        };
      }
      const result = await store_exports.importSessionZip(fileBuffer, {
        traceDir: globalDir,
        conflictStrategy
      });
      return result;
    } catch (e) {
      const err = e;
      if (err.message.includes("Invalid") || err.message.includes("No file")) {
        reply.code(400);
        return { error: err.message };
      }
      reply.code(500);
      return { error: "Import failed: " + err.message };
    }
  });
  app.post("/api/sessions/:sessionId/delete", async (req, reply) => {
    try {
      const { sessionId } = req.params;
      if (!validateSessionId(sessionId)) {
        reply.code(400);
        return { error: "Invalid session ID format" };
      }
      const sessionTraceDir = await findSessionTraceDir(sessionId);
      if (!sessionTraceDir) {
        reply.code(404);
        return { error: "Session not found" };
      }
      await store_exports.deleteSession(sessionId, { traceDir: sessionTraceDir });
      return { success: true, sessionId };
    } catch (e) {
      const err = e;
      reply.code(500);
      return { error: "Delete failed: " + err.message };
    }
  });
  app.post("/api/sessions/batch-delete", async (req, reply) => {
    try {
      const body = req.body;
      if (!body || !Array.isArray(body.sessionIds) || body.sessionIds.length === 0) {
        reply.code(400);
        return { error: "sessionIds must be a non-empty array" };
      }
      const deleted = [];
      const errors = [];
      for (const sessionId of body.sessionIds) {
        try {
          const sessionTraceDir = await findSessionTraceDir(sessionId);
          if (sessionTraceDir) {
            await store_exports.deleteSession(sessionId, { traceDir: sessionTraceDir });
            deleted.push(sessionId);
          } else {
            errors.push({ sessionId, error: "Session not found" });
          }
        } catch (e) {
          errors.push({ sessionId, error: e.message });
        }
      }
      return { success: true, deleted, errors };
    } catch (e) {
      reply.code(500);
      return { error: "Batch delete failed: " + e.message };
    }
  });
  const watchDirs = [globalDir];
  if (localDir && localDir !== globalDir) {
    watchDirs.push(localDir);
  }
  const watcher = chokidar.watch(watchDirs, {
    ignored: /(\.tmp$|\.parsed$)/,
    persistent: true,
    ignoreInitial: true,
    depth: 2
  });
  watcher.on("add", (filePath) => {
    const match = filePath.match(/\/([^/]+)\/(\d+)\.json$/);
    if (match) {
      const sessionId = match[1];
      const seq = parseInt(match[2], 10);
      for (const dir of watchDirs) {
        if (filePath.startsWith(dir)) {
          store_exports.invalidateReadCacheForSeq(dir, sessionId, seq);
          break;
        }
      }
      broadcastSSE("record:added", { sessionId, seq });
    }
  });
  watcher.on("change", (filePath) => {
    const match = filePath.match(/\/([^/]+)\/(\d+)\.json$/);
    if (match) {
      const sessionId = match[1];
      const seq = parseInt(match[2], 10);
      for (const dir of watchDirs) {
        if (filePath.startsWith(dir)) {
          store_exports.invalidateReadCacheForSeq(dir, sessionId, seq);
          break;
        }
      }
      broadcastSSE("record:updated", { sessionId, seq });
    }
  });
  watcher.on("unlink", (filePath) => {
    const match = filePath.match(/\/([^/]+)\/(\d+)\.json$/);
    if (match) {
      const sessionId = match[1];
      const seq = parseInt(match[2], 10);
      const sessionDir = dirname(filePath);
      const ndjinxPath = join7(sessionDir, "timeline.ndjinx");
      try {
        if (existsSync6(ndjinxPath)) {
          const raw = readFileSync5(ndjinxPath, "utf-8");
          const lines = raw.split("\n").filter((l) => {
            if (!l.trim())
              return false;
            try {
              return JSON.parse(l).seq !== seq;
            } catch {
              return false;
            }
          });
          writeFileSync4(ndjinxPath, lines.join("\n") + "\n");
        }
      } catch {
      }
      for (const dir of watchDirs) {
        if (filePath.startsWith(dir)) {
          store_exports.invalidateReadCacheForSeq(dir, sessionId, seq);
          break;
        }
      }
      broadcastSSE("record:deleted", { sessionId, seq });
    }
  });
  watcher.on("addDir", (dirPath) => {
    const match = dirPath.match(/\/([^/]+)$/);
    if (match) {
      const sessionId = match[1];
      if (/^\d+\.json$/.test(sessionId))
        return;
      try {
        const files = readdirSync4(dirPath);
        const hasRecord = files.some((f) => /^\d+\.json$/.test(f));
        const hasMeta = files.some((f) => f === "metadata.json");
        if (hasRecord || hasMeta) {
          for (const dir of watchDirs) {
            if (dirPath.startsWith(dir)) {
              store_exports.invalidateReadCacheForSession(dir, sessionId);
              break;
            }
          }
          broadcastSSE("session:created", { sessionId });
        }
      } catch {
      }
    }
  });
  watcher.on("unlinkDir", (dirPath) => {
    const match = dirPath.match(/\/([^/]+)$/);
    if (match) {
      const sessionId = match[1];
      for (const dir of watchDirs) {
        if (dirPath.startsWith(dir)) {
          store_exports.invalidateReadCacheForSession(dir, sessionId);
          break;
        }
      }
      broadcastSSE("session:deleted", { sessionId });
    }
  });
  let addr;
  if (options?.noListen) {
    addr = "http://localhost:0";
  } else {
    await app.listen({ port, host: "0.0.0.0" });
    addr = `http://localhost:${port}`;
  }
  if (options?.open) {
    import("node:child_process").then(({ exec }) => {
      const cmd = process.platform === "darwin" ? "open" : process.platform === "win32" ? "start" : "xdg-open";
      exec(`${cmd} ${addr}`);
    });
  }
  return {
    url: addr,
    app,
    close: async () => {
      clearInterval(sseKeepAlive);
      await watcher.close();
      await app.close();
    }
  };
}
export {
  createViewer
};
