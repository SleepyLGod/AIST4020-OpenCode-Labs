var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// packages/core/dist/paths.js
import path from "node:path";
import { homedir } from "node:os";
function getTraceDir() {
  const pathApi = process.platform === "win32" ? path.win32 : path.posix;
  return pathApi.join(homedir(), ".opencode-trace");
}
function sanitizePath(fpath, userHome) {
  const escapedHome = userHome.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return fpath.replace(new RegExp(escapedHome, "g"), "[HOME]");
}
var init_paths = __esm({
  "packages/core/dist/paths.js"() {
    "use strict";
  }
});

// packages/core/dist/logger.js
import winston from "winston";
import { join } from "node:path";
function resolveMode() {
  const raw = (process.env.OPENTRACE_LOG ?? "file").toLowerCase();
  if (raw === "off" || raw === "silent" || raw === "none")
    return "off";
  if (raw === "console" || raw === "stderr")
    return "console";
  return "file";
}
function resolveTransports(mode2) {
  if (mode2 === "off")
    return [];
  if (mode2 === "console") {
    return [
      new winston.transports.Console({
        stderrLevels: ["error", "warn", "info", "debug"]
      })
    ];
  }
  const file = process.env.OPENTRACE_LOG_FILE ?? join(getTraceDir(), "plugin.log");
  return [
    new winston.transports.File({
      filename: file,
      maxsize: 5 * 1024 * 1024,
      maxFiles: 2
    })
  ];
}
var logFormat, mode, logger;
var init_logger = __esm({
  "packages/core/dist/logger.js"() {
    "use strict";
    init_paths();
    logFormat = winston.format.combine(winston.format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }), winston.format.printf(({ timestamp, level, message, ...meta }) => {
      const metaStr = Object.keys(meta).length ? ` ${JSON.stringify(meta)}` : "";
      return `${timestamp} [${level.toUpperCase()}] ${message}${metaStr}`;
    }));
    mode = resolveMode();
    logger = winston.createLogger({
      level: process.env.OPENTRACE_LOG_LEVEL || "info",
      format: logFormat,
      transports: resolveTransports(mode)
    });
  }
});

// packages/core/dist/platform.js
import { renameSync, promises as fs } from "node:fs";
function safeRenameSync(src, dest, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      renameSync(src, dest);
      return;
    } catch (err) {
      const code = err?.code;
      if ((code === "EACCES" || code === "EPERM") && i < retries - 1) {
        continue;
      }
      throw err;
    }
  }
}
async function safeRename(src, dest, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      await fs.rename(src, dest);
      return;
    } catch (err) {
      const code = err?.code;
      if ((code === "EACCES" || code === "EPERM") && i < retries - 1) {
        logger.warn("safeRename retry", { attempt: i + 1, code, src, dest });
        const delayMs = 50 * (i + 1);
        await new Promise((r) => setTimeout(r, delayMs));
        continue;
      }
      throw err;
    }
  }
}
var init_platform = __esm({
  "packages/core/dist/platform.js"() {
    "use strict";
    init_logger();
    init_paths();
  }
});

// packages/core/dist/state/index.js
import { randomUUID } from "node:crypto";
import { join as join2 } from "node:path";
import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import { promises as fs2 } from "node:fs";
function normalizeBoolean(value, defaultValue) {
  if (typeof value === "boolean")
    return value;
  if (value === "true")
    return true;
  if (value === "false")
    return false;
  return defaultValue;
}
function normalizeStoragePreference(value) {
  if (value === "local")
    return "local";
  return "global";
}
function getConfigManager(traceDir) {
  if (!registry.has(traceDir)) {
    const manager = new ConfigManager(traceDir);
    registry.set(traceDir, manager);
    registryInitPromises.set(traceDir, manager.init());
  }
  return registry.get(traceDir);
}
async function initConfigManager(traceDir) {
  const manager = getConfigManager(traceDir);
  await registryInitPromises.get(traceDir);
  return manager;
}
var CONFIG_FILENAME, CURRENT_SCHEMA_VERSION, DEFAULT_CONFIG, ConfigManager, registry, registryInitPromises;
var init_state = __esm({
  "packages/core/dist/state/index.js"() {
    "use strict";
    init_logger();
    init_platform();
    CONFIG_FILENAME = "config.json";
    CURRENT_SCHEMA_VERSION = 2;
    DEFAULT_CONFIG = {
      global_trace_enabled: true,
      storage_preference: "global",
      plugin_enabled: true,
      current_session: null,
      schema_version: CURRENT_SCHEMA_VERSION
    };
    ConfigManager = class {
      traceDir;
      configPath;
      configCache = null;
      constructor(traceDir) {
        this.traceDir = traceDir;
        this.configPath = join2(traceDir, CONFIG_FILENAME);
        if (!existsSync(traceDir)) {
          mkdirSync(traceDir, { recursive: true });
        }
      }
      async init() {
        mkdirSync(this.traceDir, { recursive: true });
        if (!existsSync(this.configPath)) {
          this.writeConfig({ ...DEFAULT_CONFIG });
        }
        this.configCache = this.readConfig();
      }
      readConfig() {
        try {
          if (!existsSync(this.configPath)) {
            return { ...DEFAULT_CONFIG };
          }
          const raw = readFileSync(this.configPath, "utf-8");
          const parsed = JSON.parse(raw);
          return {
            global_trace_enabled: normalizeBoolean(parsed.global_trace_enabled, DEFAULT_CONFIG.global_trace_enabled),
            storage_preference: normalizeStoragePreference(parsed.storage_preference),
            plugin_enabled: normalizeBoolean(parsed.plugin_enabled, DEFAULT_CONFIG.plugin_enabled),
            current_session: typeof parsed.current_session === "string" ? parsed.current_session : null,
            schema_version: typeof parsed.schema_version === "number" ? parsed.schema_version : CURRENT_SCHEMA_VERSION
          };
        } catch (err) {
          logger.error("Failed to read config.json, using defaults", {
            configPath: this.configPath,
            error: String(err)
          });
          return { ...DEFAULT_CONFIG };
        }
      }
      writeConfig(config) {
        try {
          const tmpPath = this.configPath + ".tmp";
          writeFileSync(tmpPath, JSON.stringify(config, null, 2), "utf-8");
          safeRenameSync(tmpPath, this.configPath);
          this.configCache = config;
        } catch (err) {
          logger.error("Failed to write config.json", {
            configPath: this.configPath,
            error: String(err)
          });
        }
      }
      reloadConfig() {
        this.configCache = this.readConfig();
      }
      getGlobalState(key) {
        if (!this.configCache) {
          this.configCache = this.readConfig();
        }
        const v = this.configCache[key];
        if (v === void 0 || v === null)
          return null;
        if (typeof v === "boolean")
          return v ? "true" : "false";
        return String(v);
      }
      setGlobalState(key, value) {
        const config = this.readConfig();
        if (key === "global_trace_enabled") {
          config.global_trace_enabled = value === "true";
        } else if (key === "storage_preference") {
          config.storage_preference = normalizeStoragePreference(value);
        } else if (key === "plugin_enabled") {
          config.plugin_enabled = value !== "false";
        } else if (key === "current_session") {
          config.current_session = value;
        } else {
          config[key] = value;
        }
        this.writeConfig(config);
      }
      startSession(sessionId) {
        const id = sessionId ?? this.generateSessionId();
        mkdirSync(join2(this.traceDir, id), { recursive: true });
        this.setGlobalState("current_session", id);
        this.updateSessionMetadata(id, { startedAt: (/* @__PURE__ */ new Date()).toISOString() });
        return id;
      }
      stopSession(sessionId) {
        const current = this.getGlobalState("current_session");
        if (current === sessionId) {
          this.setGlobalState("current_session", null);
        }
      }
      getSession(sessionId) {
        return this.getSessionFromFs(sessionId);
      }
      getActiveSession() {
        const sessionId = this.getGlobalState("current_session");
        if (!sessionId)
          return null;
        const sessionDir = join2(this.traceDir, sessionId);
        if (!existsSync(sessionDir)) {
          this.setGlobalState("current_session", null);
          return null;
        }
        return sessionId;
      }
      async writeRecord(sessionId, seq, record) {
        const sessionDir = join2(this.traceDir, sessionId);
        await fs2.mkdir(sessionDir, { recursive: true });
        const filePath = join2(sessionDir, `${seq}.json`);
        const tmpPath = filePath + ".tmp";
        await fs2.writeFile(tmpPath, JSON.stringify(record, null, 2));
        await fs2.rename(tmpPath, filePath);
      }
      listSessions() {
        return this.listSessionsFromFs();
      }
      generateSessionId() {
        return randomUUID();
      }
      scanFsSessions() {
        try {
          const entries = readdirSync(this.traceDir, { withFileTypes: true });
          return entries.filter((e) => e.isDirectory()).map((e) => e.name);
        } catch (err) {
          logger.error("Failed to scan filesystem sessions", {
            traceDir: this.traceDir,
            error: String(err)
          });
          return [];
        }
      }
      getSessionFromFs(sessionId) {
        const sessionDir = join2(this.traceDir, sessionId);
        if (!existsSync(sessionDir))
          return null;
        const metadata = this.readMetadataFile(sessionId);
        const isCurrentSession = this.configCache?.current_session === sessionId;
        const ndjsonData = this.readNdjsonTiming(sessionDir);
        if (ndjsonData) {
          return {
            id: sessionId,
            status: isCurrentSession ? "active" : "stopped",
            startedAt: metadata.startedAt ?? ndjsonData.startedAt,
            endedAt: ndjsonData.endedAt,
            requestCount: ndjsonData.count,
            ...metadata
          };
        }
        const files = readdirSync(sessionDir).filter((f) => /^\d+\.json$/.test(f));
        if (files.length === 0) {
          return {
            id: sessionId,
            status: isCurrentSession ? "active" : "stopped",
            startedAt: metadata.startedAt ?? null,
            endedAt: null,
            requestCount: 0,
            ...metadata
          };
        }
        let startedAt = null;
        let endedAt = null;
        let count = 0;
        for (const f of files) {
          try {
            const raw = readFileSync(join2(sessionDir, f), "utf-8");
            const rec = JSON.parse(raw);
            count++;
            if (!startedAt || rec.requestAt < startedAt)
              startedAt = rec.requestAt;
            if (!endedAt || rec.responseAt > endedAt)
              endedAt = rec.responseAt;
          } catch (err) {
            logger.error("Failed to read session record file", {
              sessionId,
              file: f,
              traceDir: this.traceDir,
              error: String(err)
            });
          }
        }
        return {
          id: sessionId,
          status: isCurrentSession ? "active" : "stopped",
          startedAt: metadata.startedAt ?? startedAt,
          endedAt,
          requestCount: count,
          ...metadata
        };
      }
      listSessionsFromFs() {
        const ids = this.scanFsSessions();
        const sessions = [];
        for (const id of ids) {
          const session = this.getSessionFromFs(id);
          if (session)
            sessions.push(session);
        }
        return sessions.sort((a, b) => (b.startedAt ?? "").localeCompare(a.startedAt ?? ""));
      }
      /** Try to read timing data from timeline.ndjson for O(S+logR) session listing. */
      readNdjsonTiming(sessionDir) {
        const indexPath = join2(sessionDir, "timeline.ndjson");
        if (!existsSync(indexPath))
          return null;
        try {
          const raw = readFileSync(indexPath, "utf-8");
          const lines = raw.split("\n").filter((l) => l.trim());
          if (lines.length === 0)
            return { startedAt: null, endedAt: null, count: 0 };
          let startedAt = null;
          let endedAt = null;
          let count = 0;
          for (const line of lines) {
            try {
              const entry = JSON.parse(line);
              count++;
              if (entry.requestAt && (!startedAt || entry.requestAt < startedAt)) {
                startedAt = entry.requestAt;
              }
              if (entry.responseAt && (!endedAt || entry.responseAt > endedAt)) {
                endedAt = entry.responseAt;
              }
            } catch {
            }
          }
          return { startedAt, endedAt, count };
        } catch {
          return null;
        }
      }
      getMetadataPath(sessionId) {
        return join2(this.traceDir, sessionId, "metadata.json");
      }
      readMetadataFile(sessionId) {
        const metaPath = this.getMetadataPath(sessionId);
        if (!existsSync(metaPath)) {
          return {};
        }
        try {
          const raw = readFileSync(metaPath, "utf-8");
          return JSON.parse(raw);
        } catch (err) {
          logger.error("Failed to read session metadata file", {
            sessionId,
            metaPath,
            traceDir: this.traceDir,
            error: String(err)
          });
          return {};
        }
      }
      writeMetadataFile(sessionId, metadata) {
        const sessionDir = join2(this.traceDir, sessionId);
        if (!existsSync(sessionDir)) {
          mkdirSync(sessionDir, { recursive: true });
        }
        const metaPath = this.getMetadataPath(sessionId);
        const tmpPath = metaPath + ".tmp";
        writeFileSync(tmpPath, JSON.stringify(metadata, null, 2), "utf-8");
        safeRenameSync(tmpPath, metaPath);
      }
      updateSessionMetadata(sessionId, metadata) {
        const existing = this.readMetadataFile(sessionId);
        const updated = { ...existing };
        if (metadata.title !== void 0) {
          updated.title = metadata.title;
        }
        if (metadata.parentID !== void 0) {
          updated.parentID = metadata.parentID;
        }
        if (metadata.folderPath !== void 0) {
          updated.folderPath = metadata.folderPath;
        }
        if (metadata.startedAt !== void 0) {
          updated.startedAt = metadata.startedAt;
        }
        if (metadata.trace_enabled !== void 0) {
          updated.trace_enabled = metadata.trace_enabled;
        }
        if (metadata.storage_preference !== void 0) {
          updated.storage_preference = metadata.storage_preference;
        }
        this.writeMetadataFile(sessionId, updated);
      }
      setSessionEnabled(sessionId, enabled) {
        const existing = this.readMetadataFile(sessionId);
        const updated = { ...existing };
        if (enabled === null) {
          delete updated.trace_enabled;
        } else {
          updated.trace_enabled = enabled;
        }
        this.writeMetadataFile(sessionId, updated);
      }
      getSessionEnabled(sessionId) {
        const metadata = this.readMetadataFile(sessionId);
        return metadata.trace_enabled ?? null;
      }
      setSessionStoragePreference(sessionId, preference) {
        const existing = this.readMetadataFile(sessionId);
        this.writeMetadataFile(sessionId, { ...existing, storage_preference: preference });
      }
      getSessionStoragePreference(sessionId) {
        const metadata = this.readMetadataFile(sessionId);
        return metadata.storage_preference ?? null;
      }
      getStoragePreference() {
        if (!this.configCache) {
          this.configCache = this.readConfig();
        }
        return this.configCache.storage_preference;
      }
      setStoragePreference(preference) {
        this.setGlobalState("storage_preference", preference);
      }
      isTraceEnabled(sessionId) {
        const globalEnabled = this.getGlobalState("global_trace_enabled") === "true";
        if (globalEnabled)
          return true;
        if (!sessionId)
          return false;
        return this.getSessionEnabled(sessionId) ?? false;
      }
      addSubSession(parentSessionId, subSessionId) {
        const existing = this.readMetadataFile(parentSessionId);
        const subSessions = existing.subSessions ?? [];
        if (!subSessions.includes(subSessionId)) {
          subSessions.push(subSessionId);
          this.writeMetadataFile(parentSessionId, { ...existing, subSessions });
        }
      }
    };
    registry = /* @__PURE__ */ new Map();
    registryInitPromises = /* @__PURE__ */ new Map();
  }
});

// packages/core/dist/schemas/types.js
import { z } from "zod";
var TraceRequestSchema, TraceResponseSchema, TraceErrorSchema, TraceRecordSchema;
var init_types = __esm({
  "packages/core/dist/schemas/types.js"() {
    "use strict";
    TraceRequestSchema = z.object({
      method: z.string(),
      url: z.string(),
      headers: z.record(z.string(), z.string()),
      body: z.unknown()
    });
    TraceResponseSchema = z.object({
      status: z.number().int(),
      statusText: z.string(),
      headers: z.record(z.string(), z.string()),
      body: z.unknown()
    });
    TraceErrorSchema = z.object({
      message: z.string(),
      stack: z.string().optional()
    });
    TraceRecordSchema = z.object({
      id: z.number().int().positive(),
      purpose: z.string(),
      requestAt: z.string(),
      responseAt: z.string(),
      request: TraceRequestSchema,
      response: TraceResponseSchema.nullable(),
      error: TraceErrorSchema.nullable(),
      requestSentAt: z.number().optional(),
      firstTokenAt: z.number().optional(),
      lastTokenAt: z.number().optional()
    });
  }
});

// packages/core/dist/schemas/store-types.js
import { z as z2 } from "zod";
var SessionMetaSchema, SessionTreeNodeSchema, SessionMetadataFileSchema, ExportManifestSchema, ConflictInfoSchema, ImportedSessionInfoSchema, ImportResultSchema;
var init_store_types = __esm({
  "packages/core/dist/schemas/store-types.js"() {
    "use strict";
    SessionMetaSchema = z2.object({
      id: z2.string(),
      requestCount: z2.number().int().nonnegative(),
      createdAt: z2.string().nullable(),
      updatedAt: z2.string().nullable(),
      title: z2.string().optional(),
      parentID: z2.string().optional(),
      subSessions: z2.array(z2.string()).optional(),
      folderPath: z2.string().optional()
    });
    SessionTreeNodeSchema = SessionMetaSchema.extend({
      children: z2.array(SessionMetaSchema)
    });
    SessionMetadataFileSchema = z2.object({
      sessionId: z2.string(),
      title: z2.string().optional(),
      enabled: z2.boolean().optional(),
      parentID: z2.string().optional(),
      subSessions: z2.array(z2.string()).optional(),
      createdAt: z2.string().optional(),
      updatedAt: z2.string().optional()
    });
    ExportManifestSchema = z2.object({
      exportedAt: z2.string(),
      mainSession: z2.string(),
      sessions: z2.array(z2.string()),
      version: z2.string()
    });
    ConflictInfoSchema = z2.object({
      sessionId: z2.string(),
      existing: z2.object({
        requestCount: z2.number().int().nonnegative(),
        createdAt: z2.string()
      }),
      importing: z2.object({
        requestCount: z2.number().int().nonnegative(),
        createdAt: z2.string()
      })
    });
    ImportedSessionInfoSchema = z2.object({
      sessionId: z2.string(),
      requestCount: z2.number().int().nonnegative(),
      strategy: z2.enum(["none", "rename", "skip", "overwrite"]),
      newId: z2.string().optional()
    });
    ImportResultSchema = z2.object({
      status: z2.enum(["success", "conflict"]),
      conflicts: z2.array(ConflictInfoSchema).optional(),
      importedSessions: z2.array(ImportedSessionInfoSchema).optional()
    });
  }
});

// packages/core/dist/model/utils.js
function hashString(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36).slice(0, 9);
}
function generateId() {
  return Math.random().toString(36).slice(2, 11);
}
function generateStableId(role, blocks) {
  const contentKey = blocks.map((b) => {
    switch (b.type) {
      case "text":
        return `t:${b.text.slice(0, 100)}`;
      case "thinking":
        return `k:${b.thinking.slice(0, 100)}`;
      case "tc":
        return `c:${b.id}:${b.name}`;
      case "tr":
        return `r:${b.toolCallId}`;
      default:
        return b.type;
    }
  }).join("|");
  return hashString(`${role}:${contentKey}`);
}
function createSysEntry(blocks) {
  return { id: "sys", blocks };
}
function createToolEntry(blocks) {
  return { id: "tool", blocks };
}
function createMsgEntry(role, blocks) {
  return { id: generateStableId(role, blocks), role, blocks };
}
function createTextBlock(text) {
  return { type: "text", text };
}
function createThinkingBlock(thinking) {
  return { type: "thinking", thinking };
}
function createToolDefinitionBlock(name, description, inputSchema) {
  return { type: "td", name, description, inputSchema };
}
function createToolCallBlock(id, name, args) {
  return { type: "tc", id, name, arguments: args };
}
function createToolResultBlock(toolCallId, content) {
  return { type: "tr", toolCallId, content };
}
function createImageBlock(source) {
  return { type: "image", source };
}
function createOtherBlock(raw) {
  return { type: "other", raw };
}
var init_utils = __esm({
  "packages/core/dist/model/utils.js"() {
    "use strict";
  }
});

// packages/core/dist/parse/utils.js
var init_utils2 = __esm({
  "packages/core/dist/parse/utils.js"() {
    "use strict";
    init_utils();
  }
});

// packages/core/dist/parse/registry.js
function registerParser(parser, pathPattern, hostPattern) {
  if (registrations.some((r) => r.parser.provider === parser.provider)) {
    throw new Error(`Parser already registered for provider: ${parser.provider}`);
  }
  registrations.push({ parser, pathPattern, hostPattern });
}
function findParser(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return null;
  }
  const pathname = parsed.pathname;
  const hostname = parsed.hostname;
  const candidates = registrations.filter((r) => pathname.endsWith(r.pathPattern));
  if (candidates.length === 0)
    return null;
  const exact = candidates.find((r) => r.hostPattern && hostname === r.hostPattern);
  if (exact)
    return exact.parser;
  const fallback = candidates.find((r) => !r.hostPattern);
  if (fallback)
    return fallback.parser;
  return candidates[0].parser;
}
function getRegistrations() {
  return [...registrations];
}
function clearRegistrations() {
  registrations.length = 0;
}
var registrations;
var init_registry = __esm({
  "packages/core/dist/parse/registry.js"() {
    "use strict";
    registrations = [];
  }
});

// packages/core/dist/parse/openai-chat.js
function isRecord(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}
function extractMessages(body) {
  const raw = body.messages;
  if (!Array.isArray(raw))
    return [];
  return raw.filter((msg) => !(isRecord(msg) && (msg.role === "system" || msg.role === "developer"))).map((msg) => {
    if (!isRecord(msg))
      return createMsgEntry("user", [createTextBlock(String(msg))]);
    const role = String(msg.role ?? "user");
    const blocks = [];
    if (typeof msg.content === "string" && msg.content) {
      blocks.push(createTextBlock(msg.content));
    } else if (Array.isArray(msg.content)) {
      for (const part of msg.content) {
        if (typeof part === "string") {
          blocks.push(createTextBlock(part));
        } else if (isRecord(part)) {
          if (typeof part.text === "string" && part.text) {
            blocks.push(createTextBlock(part.text));
          } else if (part.type === "image_url" && isRecord(part.image_url) && typeof part.image_url.url === "string") {
            blocks.push(createImageBlock(part.image_url.url));
          } else if (part.type === "input_audio") {
            blocks.push(createOtherBlock({ type: "audio", data: part }));
          } else {
            blocks.push(createOtherBlock(part));
          }
        }
      }
    }
    if (Array.isArray(msg.tool_calls)) {
      for (const tc of msg.tool_calls) {
        if (!isRecord(tc))
          continue;
        const fn = isRecord(tc.function) ? tc.function : {};
        blocks.push(createToolCallBlock(String(tc.id ?? ""), String(fn.name ?? ""), typeof fn.arguments === "string" ? fn.arguments : JSON.stringify(fn.arguments ?? {})));
      }
    }
    if (msg.tool_call_id != null) {
      const content = blocks.length > 0 ? blocks.filter((b) => b.type === "text").map((b) => b.text).join("") : "";
      return createMsgEntry(role, [
        createToolResultBlock(String(msg.tool_call_id), content || JSON.stringify(msg.content ?? ""))
      ]);
    }
    if (typeof msg.reasoning_content === "string") {
      blocks.unshift(createThinkingBlock(msg.reasoning_content));
    }
    if (blocks.length === 0) {
      blocks.push(createTextBlock(""));
    }
    return createMsgEntry(role, blocks);
  });
}
function extractTools(body) {
  const raw = body.tools;
  if (!Array.isArray(raw))
    return void 0;
  const blocks = raw.map((tool) => {
    if (!isRecord(tool))
      return createToolDefinitionBlock(String(tool), null, null);
    const fn = isRecord(tool.function) ? tool.function : {};
    return createToolDefinitionBlock(String(fn.name ?? tool.name ?? ""), typeof fn.description === "string" ? fn.description : null, fn.parameters ?? null);
  });
  if (blocks.length === 0)
    return void 0;
  return createToolEntry(blocks);
}
function extractSystem(body) {
  const systemParts = [];
  if (typeof body.system === "string")
    systemParts.push(body.system);
  if (typeof body.developer === "string")
    systemParts.push(body.developer);
  if (typeof body.instructions === "string")
    systemParts.push(body.instructions);
  const systemFromMessages = (Array.isArray(body.messages) ? body.messages : []).filter((m) => isRecord(m) && (m.role === "system" || m.role === "developer")).map((m) => typeof m.content === "string" ? m.content : "");
  systemParts.push(...systemFromMessages);
  const text = systemParts.join("\n");
  if (!text)
    return void 0;
  return createSysEntry([createTextBlock(text)]);
}
function extractUsage(body) {
  const usage = body.usage;
  if (!isRecord(usage))
    return null;
  const inputTokens = typeof usage.prompt_tokens === "number" ? usage.prompt_tokens : 0;
  const outputTokens = typeof usage.completion_tokens === "number" ? usage.completion_tokens : 0;
  const promptDetails = isRecord(usage.prompt_tokens_details) ? usage.prompt_tokens_details : {};
  const cachedTokens = typeof promptDetails.cached_tokens === "number" ? promptDetails.cached_tokens : 0;
  const inputMiss = inputTokens - cachedTokens;
  return {
    inputMissTokens: inputMiss > 0 ? inputMiss : null,
    inputHitTokens: cachedTokens > 0 ? cachedTokens : null,
    outputTokens: outputTokens > 0 ? outputTokens : null
  };
}
var openaiChatParser;
var init_openai_chat = __esm({
  "packages/core/dist/parse/openai-chat.js"() {
    "use strict";
    init_utils2();
    init_registry();
    openaiChatParser = {
      provider: "openai-chat",
      parseRequest(body) {
        if (!isRecord(body)) {
          return {
            provider: this.provider,
            model: null,
            msgs: [],
            usage: null,
            stream: false
          };
        }
        return {
          provider: this.provider,
          model: typeof body.model === "string" ? body.model : null,
          sys: extractSystem(body),
          tool: extractTools(body),
          msgs: extractMessages(body),
          usage: null,
          stream: body.stream === true
        };
      },
      parseResponse(body) {
        if (!isRecord(body))
          return {};
        const choices = body.choices;
        const msgs = [];
        if (Array.isArray(choices) && choices.length > 0) {
          const choice = choices[0];
          if (isRecord(choice)) {
            const msg = choice.message;
            if (isRecord(msg)) {
              const blocks = [];
              if (typeof msg.reasoning_content === "string") {
                blocks.push(createThinkingBlock(msg.reasoning_content));
              }
              if (typeof msg.content === "string" && msg.content) {
                blocks.push(createTextBlock(msg.content));
              }
              if (Array.isArray(msg.tool_calls)) {
                for (const tc of msg.tool_calls) {
                  if (!isRecord(tc))
                    continue;
                  const fn = isRecord(tc.function) ? tc.function : {};
                  blocks.push(createToolCallBlock(String(tc.id ?? ""), String(fn.name ?? ""), typeof fn.arguments === "string" ? fn.arguments : JSON.stringify(fn.arguments ?? {})));
                }
              }
              if (blocks.length === 0) {
                blocks.push(createTextBlock(""));
              }
              msgs.push(createMsgEntry("assistant", blocks));
            }
          }
        }
        return {
          model: typeof body.model === "string" ? body.model : void 0,
          msgs,
          usage: extractUsage(body)
        };
      }
    };
    registerParser(openaiChatParser, "/chat/completions");
  }
});

// packages/core/dist/parse/openai-responses.js
function isRecord2(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}
function extractInputMessages(input) {
  const msgs = [];
  if (typeof input === "string") {
    msgs.push(createMsgEntry("user", [createTextBlock(input)]));
  } else if (Array.isArray(input)) {
    for (const item of input) {
      if (typeof item === "string") {
        msgs.push(createMsgEntry("user", [createTextBlock(item)]));
        continue;
      }
      if (!isRecord2(item))
        continue;
      const type = item.type;
      if (type === "message" || item.role) {
        const role = String(item.role ?? "user");
        const contentParts = item.content;
        const blocks = [];
        if (typeof contentParts === "string") {
          blocks.push(createTextBlock(contentParts));
        } else if (Array.isArray(contentParts)) {
          for (const part of contentParts) {
            if (typeof part === "string") {
              blocks.push(createTextBlock(part));
            } else if (isRecord2(part)) {
              if (part.type === "input_text" && typeof part.text === "string") {
                blocks.push(createTextBlock(part.text));
              } else if (part.type === "text" && typeof part.text === "string") {
                blocks.push(createTextBlock(part.text));
              } else if (part.type === "output_text" && typeof part.text === "string") {
                blocks.push(createTextBlock(part.text));
              } else if (part.type === "input_image") {
                blocks.push(createOtherBlock({ type: "image", source: part }));
              } else if (part.type === "input_file") {
                blocks.push(createOtherBlock({ type: "file", source: part }));
              } else if (typeof part.text === "string") {
                blocks.push(createTextBlock(part.text));
              } else {
                blocks.push(createOtherBlock(part));
              }
            }
          }
        }
        if (role === "tool" && item.tool_call_id != null) {
          const content = blocks.length > 0 ? blocks.filter((b) => b.type === "text").map((b) => b.text).join("") : "";
          msgs.push(createMsgEntry("tool", [
            createToolResultBlock(String(item.tool_call_id), content || JSON.stringify(item.content ?? ""))
          ]));
        } else {
          if (blocks.length === 0) {
            blocks.push(createTextBlock(""));
          }
          msgs.push(createMsgEntry(role, blocks));
        }
      } else if (type === "function_call") {
        msgs.push(createMsgEntry("assistant", [
          createToolCallBlock(String(item.id ?? item.call_id ?? ""), String(item.name ?? ""), typeof item.arguments === "string" ? item.arguments : JSON.stringify(item.arguments ?? {}))
        ]));
      } else if (type === "function_call_output") {
        msgs.push(createMsgEntry("tool", [
          createToolResultBlock(String(item.call_id ?? ""), typeof item.output === "string" ? item.output : JSON.stringify(item.output ?? ""))
        ]));
      }
    }
  }
  return msgs;
}
var openaiResponsesParser;
var init_openai_responses = __esm({
  "packages/core/dist/parse/openai-responses.js"() {
    "use strict";
    init_utils2();
    init_registry();
    openaiResponsesParser = {
      provider: "openai-responses",
      parseRequest(body) {
        if (!isRecord2(body)) {
          return {
            provider: this.provider,
            model: null,
            msgs: [],
            usage: null,
            stream: false
          };
        }
        const msgs = extractInputMessages(body.input);
        const toolBlocks = [];
        if (Array.isArray(body.tools)) {
          for (const tool of body.tools) {
            if (!isRecord2(tool))
              continue;
            if (tool.type === "function" && isRecord2(tool.function)) {
              toolBlocks.push(createToolDefinitionBlock(String(tool.function.name ?? ""), typeof tool.function.description === "string" ? tool.function.description : null, tool.function.parameters ?? null));
            } else if (tool.type === "web_search_preview" || tool.type === "web_search_preview_2025_03_11") {
              toolBlocks.push(createToolDefinitionBlock("web_search_preview", "Web search tool", null));
            } else if (tool.type === "file_search") {
              toolBlocks.push(createToolDefinitionBlock("file_search", typeof tool.vector_store_ids === "string" ? "File search: " + tool.vector_store_ids : "File search tool", null));
            } else if (tool.type === "computer_use_preview") {
              toolBlocks.push(createToolDefinitionBlock("computer_use_preview", "Computer use tool", null));
            } else if (tool.type === "code_interpreter") {
              toolBlocks.push(createToolDefinitionBlock("code_interpreter", "Code interpreter tool", null));
            } else {
              toolBlocks.push(createToolDefinitionBlock(String(tool.name ?? tool.type ?? ""), typeof tool.description === "string" ? tool.description : null, null));
            }
          }
        }
        const sysBlocks = [];
        if (typeof body.instructions === "string") {
          sysBlocks.push(createTextBlock(body.instructions));
        }
        return {
          provider: this.provider,
          model: typeof body.model === "string" ? body.model : null,
          sys: sysBlocks.length > 0 ? createSysEntry(sysBlocks) : void 0,
          tool: toolBlocks.length > 0 ? createToolEntry(toolBlocks) : void 0,
          msgs,
          usage: null,
          stream: body.stream === true
        };
      },
      parseResponse(body) {
        if (!isRecord2(body))
          return {};
        const msgs = [];
        if (Array.isArray(body.output)) {
          for (const item of body.output) {
            if (!isRecord2(item))
              continue;
            if (item.type === "message") {
              const contentParts = item.content;
              const blocks = [];
              if (Array.isArray(contentParts)) {
                for (const p of contentParts) {
                  if (!isRecord2(p))
                    continue;
                  if (p.type === "output_text" && typeof p.text === "string") {
                    blocks.push(createTextBlock(p.text));
                  } else if (p.type === "refusal" && typeof p.refusal === "string") {
                    blocks.push(createTextBlock("[refused: " + p.refusal + "]"));
                  } else {
                    blocks.push(createOtherBlock(p));
                  }
                }
              }
              if (blocks.length === 0) {
                blocks.push(createTextBlock(""));
              }
              msgs.push(createMsgEntry("assistant", blocks));
            } else if (item.type === "function_call") {
              msgs.push(createMsgEntry("assistant", [
                createToolCallBlock(String(item.id ?? item.call_id ?? ""), String(item.name ?? ""), typeof item.arguments === "string" ? item.arguments : JSON.stringify(item.arguments ?? {}))
              ]));
            } else if (item.type === "function_call_output") {
              msgs.push(createMsgEntry("tool", [
                createToolResultBlock(String(item.call_id ?? ""), typeof item.output === "string" ? item.output : JSON.stringify(item.output ?? ""))
              ]));
            } else if (item.type === "reasoning") {
              let thinkingText = "";
              if (Array.isArray(item.summary)) {
                thinkingText = item.summary.map((s) => {
                  if (isRecord2(s) && s.type === "summary_text" && typeof s.text === "string")
                    return s.text;
                  return "";
                }).join("");
              }
              msgs.push(createMsgEntry("assistant", thinkingText ? [createThinkingBlock(thinkingText)] : [createTextBlock("")]));
            } else if (item.type === "web_search_call") {
              msgs.push(createMsgEntry("assistant", [
                createOtherBlock({ type: "web_search", status: item.status })
              ]));
            } else if (item.type === "file_search_call") {
              msgs.push(createMsgEntry("assistant", [
                createOtherBlock({ type: "file_search", status: item.status })
              ]));
            } else if (item.type === "computer_call") {
              msgs.push(createMsgEntry("assistant", [
                createOtherBlock({ type: "computer_use" })
              ]));
            } else {
              msgs.push(createMsgEntry("assistant", [createOtherBlock(item)]));
            }
          }
        }
        const usage = body.usage;
        let parsedUsage = null;
        if (isRecord2(usage)) {
          const inputTokens = typeof usage.input_tokens === "number" ? usage.input_tokens : 0;
          const outputTokens = typeof usage.output_tokens === "number" ? usage.output_tokens : 0;
          const cachedTokens = isRecord2(usage.input_tokens_details) && typeof usage.input_tokens_details.cached_tokens === "number" ? usage.input_tokens_details.cached_tokens : 0;
          const inputMiss = inputTokens - cachedTokens;
          parsedUsage = {
            inputMissTokens: inputMiss > 0 ? inputMiss : null,
            inputHitTokens: cachedTokens > 0 ? cachedTokens : null,
            outputTokens: outputTokens > 0 ? outputTokens : null
          };
        }
        return {
          model: typeof body.model === "string" ? body.model : void 0,
          msgs,
          usage: parsedUsage
        };
      }
    };
    registerParser(openaiResponsesParser, "/responses");
  }
});

// packages/core/dist/parse/anthropic.js
function isRecord3(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}
var anthropicParser;
var init_anthropic = __esm({
  "packages/core/dist/parse/anthropic.js"() {
    "use strict";
    init_utils2();
    init_registry();
    anthropicParser = {
      provider: "anthropic",
      parseRequest(body) {
        if (!isRecord3(body)) {
          return {
            provider: this.provider,
            model: null,
            msgs: [],
            usage: null,
            stream: false
          };
        }
        const sysBlocks = [];
        if (typeof body.system === "string") {
          sysBlocks.push(createTextBlock(body.system));
        } else if (Array.isArray(body.system)) {
          for (const b of body.system) {
            if (typeof b === "string") {
              sysBlocks.push(createTextBlock(b));
            } else if (isRecord3(b) && b.type === "text" && typeof b.text === "string") {
              sysBlocks.push(createTextBlock(b.text));
            }
          }
        }
        const toolBlocks = [];
        if (Array.isArray(body.tools)) {
          for (const tool of body.tools) {
            if (!isRecord3(tool))
              continue;
            toolBlocks.push(createToolDefinitionBlock(String(tool.name ?? ""), typeof tool.description === "string" ? tool.description : null, tool.input_schema ?? null));
          }
        }
        const msgs = [];
        if (Array.isArray(body.messages)) {
          for (const msg of body.messages) {
            if (!isRecord3(msg))
              continue;
            const role = String(msg.role ?? "user");
            const blocks = [];
            if (typeof msg.content === "string") {
              blocks.push(createTextBlock(msg.content));
            } else if (Array.isArray(msg.content)) {
              for (const block of msg.content) {
                if (typeof block === "string") {
                  blocks.push(createTextBlock(block));
                } else if (isRecord3(block)) {
                  if (block.type === "text" && typeof block.text === "string") {
                    blocks.push(createTextBlock(block.text));
                  } else if (block.type === "thinking" && typeof block.thinking === "string") {
                    blocks.push(createThinkingBlock(block.thinking));
                  } else if (block.type === "image" && isRecord3(block.source)) {
                    blocks.push(createImageBlock(block.source));
                  } else if (block.type === "tool_use") {
                    const input = typeof block.input === "string" ? block.input : JSON.stringify(block.input ?? {});
                    blocks.push(createToolCallBlock(String(block.id ?? ""), String(block.name ?? ""), input));
                  } else if (block.type === "tool_result") {
                    let contentStr = "";
                    if (typeof block.content === "string") {
                      contentStr = block.content;
                    } else if (Array.isArray(block.content)) {
                      contentStr = block.content.map((c) => {
                        if (typeof c === "string")
                          return c;
                        if (isRecord3(c) && c.type === "text" && typeof c.text === "string")
                          return c.text;
                        return "";
                      }).join("");
                    }
                    blocks.push(createToolResultBlock(String(block.tool_use_id ?? ""), contentStr));
                  } else {
                    blocks.push(createOtherBlock(block));
                  }
                }
              }
            }
            if (blocks.length === 0) {
              blocks.push(createTextBlock(""));
            }
            msgs.push(createMsgEntry(role, blocks));
          }
        }
        return {
          provider: this.provider,
          model: typeof body.model === "string" ? body.model : null,
          sys: sysBlocks.length > 0 ? createSysEntry(sysBlocks) : void 0,
          tool: toolBlocks.length > 0 ? createToolEntry(toolBlocks) : void 0,
          msgs,
          usage: null,
          stream: body.stream === true
        };
      },
      parseResponse(body) {
        if (!isRecord3(body))
          return {};
        const msgs = [];
        if (Array.isArray(body.content)) {
          const blocks = [];
          for (const block of body.content) {
            if (!isRecord3(block))
              continue;
            if (block.type === "text" && typeof block.text === "string") {
              blocks.push(createTextBlock(block.text));
            } else if (block.type === "thinking" && typeof block.thinking === "string") {
              blocks.push(createThinkingBlock(block.thinking));
            } else if (block.type === "tool_use") {
              const input = typeof block.input === "string" ? block.input : JSON.stringify(block.input ?? {});
              blocks.push(createToolCallBlock(String(block.id ?? ""), String(block.name ?? ""), input));
            } else {
              blocks.push(createOtherBlock(block));
            }
          }
          if (blocks.length > 0) {
            msgs.push(createMsgEntry("assistant", blocks));
          }
        }
        const usage = body.usage;
        let parsedUsage = null;
        if (isRecord3(usage)) {
          const inputTokens = typeof usage.input_tokens === "number" ? usage.input_tokens : 0;
          const outputTokens = typeof usage.output_tokens === "number" ? usage.output_tokens : 0;
          const cachedTokens = typeof usage.cache_read_input_tokens === "number" ? usage.cache_read_input_tokens : 0;
          const inputMiss = inputTokens - cachedTokens;
          parsedUsage = {
            inputMissTokens: inputMiss > 0 ? inputMiss : null,
            inputHitTokens: cachedTokens > 0 ? cachedTokens : null,
            outputTokens: outputTokens > 0 ? outputTokens : null
          };
        }
        return {
          model: typeof body.model === "string" ? body.model : void 0,
          msgs,
          usage: parsedUsage
        };
      }
    };
    registerParser(anthropicParser, "/v1/messages");
  }
});

// packages/core/dist/transform/sse.js
function parseSSE(raw) {
  const events = [];
  const lines = raw.split("\n");
  let current = {};
  for (const line of lines) {
    if (line === "") {
      if (current.data !== void 0) {
        events.push({
          id: current.id,
          event: current.event,
          data: current.data
        });
      }
      current = {};
      continue;
    }
    if (line.startsWith(":"))
      continue;
    const colonIdx = line.indexOf(":");
    if (colonIdx === -1) {
      const field2 = line.trim();
      if (field2 === "data" && current.data === void 0) {
        current.data = "";
      }
      continue;
    }
    const field = line.slice(0, colonIdx).trim();
    const value = line.slice(colonIdx + 1).trimStart();
    switch (field) {
      case "event":
        current.event = value;
        break;
      case "id":
        current.id = value;
        break;
      case "data":
        current.data = (current.data ?? "") + (current.data !== void 0 ? "\n" : "") + value;
        break;
    }
  }
  if (current.data !== void 0) {
    events.push({
      id: current.id,
      event: current.event,
      data: current.data
    });
  }
  return events;
}
var init_sse = __esm({
  "packages/core/dist/transform/sse.js"() {
    "use strict";
  }
});

// packages/core/dist/transform/index.js
function isRecord4(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}
function sseOpenaiChatParse(raw) {
  const events = parseSSE(raw);
  let content = "";
  let reasoningContent = "";
  const toolCalls = [];
  let usage = null;
  for (const event of events) {
    if (!event.data || event.data === "[DONE]")
      continue;
    try {
      const parsed = JSON.parse(event.data);
      if (!isRecord4(parsed))
        continue;
      if (isRecord4(parsed.usage)) {
        const promptDetails = isRecord4(parsed.usage.prompt_tokens_details) ? parsed.usage.prompt_tokens_details : {};
        const completionDetails = isRecord4(parsed.usage.completion_tokens_details) ? parsed.usage.completion_tokens_details : {};
        const inputTokens = typeof parsed.usage.prompt_tokens === "number" ? parsed.usage.prompt_tokens : 0;
        const outputTokens = typeof parsed.usage.completion_tokens === "number" ? parsed.usage.completion_tokens : 0;
        const cachedTokens = typeof promptDetails.cached_tokens === "number" ? promptDetails.cached_tokens : 0;
        const inputMiss = inputTokens - cachedTokens;
        usage = {
          inputMissTokens: inputMiss > 0 ? inputMiss : null,
          inputHitTokens: cachedTokens > 0 ? cachedTokens : null,
          outputTokens: outputTokens > 0 ? outputTokens : null
        };
      }
      const choices = parsed.choices;
      if (!Array.isArray(choices) || choices.length === 0)
        continue;
      const delta = choices[0]?.delta;
      if (!isRecord4(delta))
        continue;
      if (typeof delta.content === "string") {
        content += delta.content;
      }
      if (typeof delta.reasoning_content === "string") {
        reasoningContent += delta.reasoning_content;
      }
      if (Array.isArray(delta.tool_calls)) {
        for (const tc of delta.tool_calls) {
          if (!isRecord4(tc))
            continue;
          const idx = typeof tc.index === "number" ? tc.index : toolCalls.length;
          const fn = isRecord4(tc.function) ? tc.function : {};
          if (!toolCalls[idx]) {
            toolCalls[idx] = {
              id: String(tc.id ?? ""),
              name: String(fn.name ?? ""),
              arguments: ""
            };
          }
          if (typeof fn.arguments === "string") {
            toolCalls[idx].arguments += fn.arguments;
          }
        }
      }
    } catch (err) {
      logger.debug("Failed to parse SSE event in OpenAI Chat stream", {
        error: String(err)
      });
    }
  }
  if (content === "" && toolCalls.length === 0 && reasoningContent === "") {
    return { messages: [], usage };
  }
  const blocks = [];
  if (reasoningContent) {
    blocks.push(createThinkingBlock(reasoningContent));
  }
  if (content) {
    blocks.push(createTextBlock(content));
  }
  for (const tc of toolCalls) {
    blocks.push(createToolCallBlock(tc.id, tc.name, tc.arguments));
  }
  if (blocks.length === 0) {
    blocks.push(createTextBlock(""));
  }
  return { messages: [createMsgEntry("assistant", blocks)], usage };
}
function sseOpenaiResponsesParse(raw) {
  const events = parseSSE(raw);
  const msgs = [];
  let currentText = "";
  let currentThinking = "";
  const toolCalls = [];
  const toolCallArgs = /* @__PURE__ */ new Map();
  let usage = null;
  for (const event of events) {
    if (!event.data)
      continue;
    try {
      const parsed = JSON.parse(event.data);
      if (!isRecord4(parsed))
        continue;
      const type = parsed.type;
      if (isRecord4(parsed.usage)) {
        const inputDetails = isRecord4(parsed.usage.input_tokens_details) ? parsed.usage.input_tokens_details : {};
        const inputTokens = typeof parsed.usage.input_tokens === "number" ? parsed.usage.input_tokens : 0;
        const outputTokens = typeof parsed.usage.output_tokens === "number" ? parsed.usage.output_tokens : 0;
        const cachedTokens = typeof inputDetails.cached_tokens === "number" ? inputDetails.cached_tokens : 0;
        const inputMiss = inputTokens - cachedTokens;
        usage = {
          inputMissTokens: inputMiss > 0 ? inputMiss : null,
          inputHitTokens: cachedTokens > 0 ? cachedTokens : null,
          outputTokens: outputTokens > 0 ? outputTokens : null
        };
      } else if (isRecord4(parsed.response) && isRecord4(parsed.response.usage)) {
        const respUsage = parsed.response.usage;
        const inputDetails = isRecord4(respUsage.input_tokens_details) ? respUsage.input_tokens_details : {};
        const inputTokens = typeof respUsage.input_tokens === "number" ? respUsage.input_tokens : 0;
        const outputTokens = typeof respUsage.output_tokens === "number" ? respUsage.output_tokens : 0;
        const cachedTokens = typeof inputDetails.cached_tokens === "number" ? inputDetails.cached_tokens : 0;
        const inputMiss = inputTokens - cachedTokens;
        usage = {
          inputMissTokens: inputMiss > 0 ? inputMiss : null,
          inputHitTokens: cachedTokens > 0 ? cachedTokens : null,
          outputTokens: outputTokens > 0 ? outputTokens : null
        };
      }
      if (type === "response.output_text.delta") {
        if (typeof parsed.delta === "string") {
          currentText += parsed.delta;
        }
      } else if (type === "response.reasoning_summary_text.delta") {
        if (typeof parsed.delta === "string") {
          currentThinking += parsed.delta;
        }
      } else if (type === "response.function_call_arguments.delta") {
        const outputIdx = typeof parsed.output_index === "number" ? parsed.output_index : -1;
        if (typeof parsed.delta === "string") {
          const existing = toolCallArgs.get(outputIdx);
          if (existing) {
            existing.args += parsed.delta;
          }
        }
      } else if (type === "response.output_item.added") {
        const item = parsed.item;
        if (isRecord4(item)) {
          if (item.type === "function_call") {
            const outputIdx = typeof parsed.output_index === "number" ? parsed.output_index : toolCallArgs.size;
            toolCallArgs.set(outputIdx, {
              id: String(item.id ?? item.call_id ?? ""),
              name: String(item.name ?? ""),
              args: ""
            });
          }
        }
      } else if (type === "response.output_item.done") {
        const item = parsed.item;
        if (isRecord4(item) && item.type === "function_call") {
          const outputIdx = typeof parsed.output_index === "number" ? parsed.output_index : -1;
          const entry = toolCallArgs.get(outputIdx);
          const finalArgs = typeof item.arguments === "string" ? item.arguments : entry?.args ?? "";
          toolCalls.push({
            id: String(item.id ?? item.call_id ?? entry?.id ?? ""),
            name: String(item.name ?? entry?.name ?? ""),
            arguments: finalArgs
          });
        }
      } else if (type === "response.completed") {
        if (currentText || currentThinking || toolCalls.length > 0) {
          const blocks = [];
          if (currentThinking) {
            blocks.push(createThinkingBlock(currentThinking));
          }
          if (currentText) {
            blocks.push(createTextBlock(currentText));
          }
          for (const tc of toolCalls) {
            blocks.push(createToolCallBlock(tc.id, tc.name, tc.arguments));
          }
          if (blocks.length === 0) {
            blocks.push(createTextBlock(""));
          }
          msgs.push(createMsgEntry("assistant", blocks));
        }
      }
    } catch (err) {
      logger.debug("Failed to parse SSE event in OpenAI Responses stream", {
        error: String(err)
      });
    }
  }
  if (msgs.length === 0 && (currentText || currentThinking || toolCalls.length > 0)) {
    const blocks = [];
    if (currentThinking) {
      blocks.push(createThinkingBlock(currentThinking));
    }
    if (currentText) {
      blocks.push(createTextBlock(currentText));
    }
    for (const tc of toolCalls) {
      blocks.push(createToolCallBlock(tc.id, tc.name, tc.arguments));
    }
    if (blocks.length === 0) {
      blocks.push(createTextBlock(""));
    }
    msgs.push(createMsgEntry("assistant", blocks));
  }
  return { messages: msgs, usage };
}
function sseAnthropicParse(raw) {
  const events = parseSSE(raw);
  let content = "";
  let thinking = "";
  const toolCalls = [];
  let usage = null;
  for (const event of events) {
    if (!event.data)
      continue;
    try {
      const parsed = JSON.parse(event.data);
      if (!isRecord4(parsed))
        continue;
      const type = parsed.type;
      const usageData = isRecord4(parsed.usage) ? parsed.usage : isRecord4(parsed.message) && isRecord4(parsed.message.usage) ? parsed.message.usage : null;
      if (usageData) {
        const inputTokens = typeof usageData.input_tokens === "number" ? usageData.input_tokens : 0;
        const outputTokens = typeof usageData.output_tokens === "number" ? usageData.output_tokens : 0;
        const cachedTokens = typeof usageData.cache_read_input_tokens === "number" ? usageData.cache_read_input_tokens : 0;
        const inputMiss = inputTokens - cachedTokens;
        usage = {
          inputMissTokens: inputMiss > 0 ? inputMiss : null,
          inputHitTokens: cachedTokens > 0 ? cachedTokens : null,
          outputTokens: outputTokens > 0 ? outputTokens : null
        };
      }
      if (type === "content_block_delta") {
        const delta = parsed.delta;
        if (isRecord4(delta)) {
          if (delta.type === "text_delta" && typeof delta.text === "string") {
            content += delta.text;
          } else if (delta.type === "thinking_delta" && typeof delta.thinking === "string") {
            thinking += delta.thinking;
          } else if (delta.type === "input_json_delta" && typeof delta.partial_json === "string") {
            if (toolCalls.length > 0) {
              toolCalls[toolCalls.length - 1].arguments += delta.partial_json;
            }
          }
        }
      } else if (type === "content_block_start") {
        const contentBlock = parsed.content_block;
        if (isRecord4(contentBlock)) {
          if (contentBlock.type === "tool_use") {
            toolCalls.push({
              id: String(contentBlock.id ?? ""),
              name: String(contentBlock.name ?? ""),
              arguments: ""
            });
          } else if (contentBlock.type === "thinking" && typeof contentBlock.thinking === "string") {
            thinking += contentBlock.thinking;
          }
        }
      }
    } catch (err) {
      logger.debug("Failed to parse SSE event in Anthropic stream", {
        error: String(err)
      });
    }
  }
  if (content === "" && toolCalls.length === 0 && thinking === "") {
    return { messages: [], usage };
  }
  const blocks = [];
  if (thinking) {
    blocks.push(createThinkingBlock(thinking));
  }
  if (content) {
    blocks.push(createTextBlock(content));
  }
  for (const tc of toolCalls) {
    blocks.push(createToolCallBlock(tc.id, tc.name, tc.arguments));
  }
  if (blocks.length === 0) {
    blocks.push(createTextBlock(""));
  }
  return { messages: [createMsgEntry("assistant", blocks)], usage };
}
var init_transform = __esm({
  "packages/core/dist/transform/index.js"() {
    "use strict";
    init_sse();
    init_utils();
    init_logger();
    init_sse();
  }
});

// packages/core/dist/parse/detect.js
function isRecord5(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}
function fallbackParse(reqBody, resBody) {
  const msgs = [];
  if (isRecord5(reqBody) && Array.isArray(reqBody.messages)) {
    for (const msg of reqBody.messages) {
      if (isRecord5(msg)) {
        const blocks = [];
        if (typeof msg.content === "string") {
          blocks.push({ type: "text", text: msg.content });
        } else if (msg.content != null) {
          blocks.push({ type: "text", text: JSON.stringify(msg.content) });
        }
        if (blocks.length === 0) {
          blocks.push({ type: "text", text: "" });
        }
        const role = typeof msg.role === "string" ? msg.role : "user";
        msgs.push(createMsgEntry(role, blocks));
      }
    }
  }
  return {
    provider: "unknown",
    model: isRecord5(reqBody) && typeof reqBody.model === "string" ? reqBody.model : null,
    msgs,
    usage: null,
    stream: false
  };
}
function parseSSEMessagesWithUsage(provider, raw) {
  if (provider === "anthropic")
    return sseAnthropicParse(raw);
  if (provider === "openai-responses")
    return sseOpenaiResponsesParse(raw);
  return sseOpenaiChatParse(raw);
}
function isSSEBody(body) {
  return typeof body === "string" && body.includes("data:");
}
function detectAndParse(record) {
  const url = record.request.url;
  const reqBody = record.request.body;
  const resBody = record.response?.body;
  const parser = findParser(url);
  if (!parser)
    return fallbackParse(reqBody, resBody);
  const reqParsed = parser.parseRequest(reqBody);
  let responseMsgs = [];
  let responseModel;
  let responseUsage = reqParsed.usage;
  if (reqParsed.stream && isSSEBody(resBody)) {
    const sseResult = parseSSEMessagesWithUsage(parser.provider, resBody);
    responseMsgs = sseResult.messages;
    if (sseResult.usage)
      responseUsage = sseResult.usage;
  } else {
    const resParsed = parser.parseResponse(resBody);
    responseMsgs = resParsed.msgs ?? [];
    responseModel = resParsed.model;
    if (resParsed.usage)
      responseUsage = resParsed.usage;
  }
  const msgs = [...reqParsed.msgs, ...responseMsgs];
  return {
    provider: parser.provider,
    model: responseModel ?? reqParsed.model,
    sys: reqParsed.sys,
    tool: reqParsed.tool,
    msgs,
    usage: responseUsage,
    stream: reqParsed.stream
  };
}
function detectProvider(url, _body) {
  const parser = findParser(url);
  return parser?.provider ?? null;
}
function extractUsage2(record) {
  const url = record.request.url;
  const reqBody = record.request.body;
  const resBody = record.response?.body;
  const parser = findParser(url);
  if (!parser)
    return null;
  const reqParsed = parser.parseRequest(reqBody);
  let responseUsage = reqParsed.usage;
  if (reqParsed.stream && isSSEBody(resBody)) {
    const sseResult = parseSSEMessagesWithUsage(parser.provider, resBody);
    if (sseResult.usage)
      responseUsage = sseResult.usage;
  } else {
    const resParsed = parser.parseResponse(resBody);
    if (resParsed.usage)
      responseUsage = resParsed.usage;
  }
  return responseUsage;
}
function extractLatency(record) {
  if (record.requestSentAt === void 0 || record.firstTokenAt === void 0 || record.lastTokenAt === void 0) {
    return null;
  }
  const ttft = record.firstTokenAt - record.requestSentAt;
  const totalDuration = record.lastTokenAt - record.requestSentAt;
  const parsed = detectAndParse(record);
  const outputTokens = parsed?.usage?.outputTokens ?? null;
  let tpot = null;
  if (typeof outputTokens === "number" && outputTokens > 0) {
    tpot = (record.lastTokenAt - record.firstTokenAt) / outputTokens;
  }
  return {
    requestSentAt: record.requestSentAt,
    firstTokenAt: record.firstTokenAt,
    lastTokenAt: record.lastTokenAt,
    ttft,
    tpot,
    totalDuration
  };
}
var init_detect = __esm({
  "packages/core/dist/parse/detect.js"() {
    "use strict";
    init_registry();
    init_utils2();
    init_transform();
  }
});

// packages/core/dist/parse/index.js
var parse_exports = {};
__export(parse_exports, {
  PARSED_CACHE_VERSION: () => PARSED_CACHE_VERSION,
  anthropicParser: () => anthropicParser,
  clearRegistrations: () => clearRegistrations,
  createImageBlock: () => createImageBlock,
  createMsgEntry: () => createMsgEntry,
  createOtherBlock: () => createOtherBlock,
  createSysEntry: () => createSysEntry,
  createTextBlock: () => createTextBlock,
  createThinkingBlock: () => createThinkingBlock,
  createToolCallBlock: () => createToolCallBlock,
  createToolDefinitionBlock: () => createToolDefinitionBlock,
  createToolEntry: () => createToolEntry,
  createToolResultBlock: () => createToolResultBlock,
  detectAndParse: () => detectAndParse,
  detectProvider: () => detectProvider,
  extractLatency: () => extractLatency,
  extractUsage: () => extractUsage2,
  findParser: () => findParser,
  generateId: () => generateId,
  getRegistrations: () => getRegistrations,
  openaiChatParser: () => openaiChatParser,
  openaiResponsesParser: () => openaiResponsesParser,
  registerParser: () => registerParser
});
var PARSED_CACHE_VERSION;
var init_parse = __esm({
  "packages/core/dist/parse/index.js"() {
    "use strict";
    init_openai_chat();
    init_openai_responses();
    init_anthropic();
    init_openai_chat();
    init_openai_responses();
    init_anthropic();
    init_detect();
    init_registry();
    init_utils2();
    PARSED_CACHE_VERSION = "1";
  }
});

// packages/core/dist/cache/read-cache.js
var ReadCache;
var init_read_cache = __esm({
  "packages/core/dist/cache/read-cache.js"() {
    "use strict";
    ReadCache = class {
      maxSize;
      ttlMs;
      store = /* @__PURE__ */ new Map();
      constructor(options = {}) {
        this.maxSize = options.maxSize ?? 500;
        this.ttlMs = options.ttlMs ?? 5e3;
      }
      get(key, loader) {
        const now = Date.now();
        const hit = this.store.get(key);
        if (hit && hit.expiresAt > now) {
          this.store.delete(key);
          this.store.set(key, hit);
          return hit.value;
        }
        if (hit) {
          this.store.delete(key);
        }
        const value = loader();
        this.store.set(key, { value, expiresAt: now + this.ttlMs });
        this.enforceLimit();
        return value;
      }
      invalidate(key) {
        this.store.delete(key);
      }
      invalidateMatching(predicate) {
        let removed = 0;
        for (const key of this.store.keys()) {
          if (predicate(key)) {
            this.store.delete(key);
            removed++;
          }
        }
        return removed;
      }
      invalidateAll() {
        this.store.clear();
      }
      size() {
        return this.store.size;
      }
      enforceLimit() {
        while (this.store.size > this.maxSize) {
          const oldest = this.store.keys().next().value;
          if (oldest === void 0)
            break;
          this.store.delete(oldest);
        }
      }
    };
  }
});

// packages/core/dist/store/read.js
var readCache;
var init_read = __esm({
  "packages/core/dist/store/read.js"() {
    "use strict";
    init_paths();
    init_state();
    init_types();
    init_store_types();
    init_parse();
    init_logger();
    init_read_cache();
    readCache = new ReadCache({ maxSize: 2e3, ttlMs: 5e3 });
  }
});

// packages/core/dist/store/write.js
var init_write = __esm({
  "packages/core/dist/store/write.js"() {
    "use strict";
    init_state();
    init_read();
    init_parse();
  }
});

// packages/core/dist/store/export.js
import archiver from "archiver";
import AdmZip from "adm-zip";
var init_export = __esm({
  "packages/core/dist/store/export.js"() {
    "use strict";
    init_logger();
    init_read();
  }
});

// packages/core/dist/store/index.js
var init_store = __esm({
  "packages/core/dist/store/index.js"() {
    "use strict";
    init_read();
    init_write();
    init_export();
  }
});

// packages/core/dist/query/session.js
var init_session = __esm({
  "packages/core/dist/query/session.js"() {
    "use strict";
    init_detect();
  }
});

// packages/core/dist/query/index.js
var init_query = __esm({
  "packages/core/dist/query/index.js"() {
    "use strict";
    init_session();
  }
});

// packages/core/dist/record/control.js
var init_control = __esm({
  "packages/core/dist/record/control.js"() {
    "use strict";
    init_paths();
    init_state();
    init_logger();
  }
});

// packages/core/dist/record/index.js
var init_record = __esm({
  "packages/core/dist/record/index.js"() {
    "use strict";
    init_control();
  }
});

// packages/core/dist/format/xml.js
var init_xml = __esm({
  "packages/core/dist/format/xml.js"() {
    "use strict";
  }
});

// packages/core/dist/format/collapse.js
var init_collapse = __esm({
  "packages/core/dist/format/collapse.js"() {
    "use strict";
    init_xml();
  }
});

// packages/core/dist/format/index.js
var init_format = __esm({
  "packages/core/dist/format/index.js"() {
    "use strict";
    init_xml();
    init_collapse();
  }
});

// packages/core/dist/schemas/parse-types.js
import { z as z3 } from "zod";
var TextBlockSchema, ThinkingBlockSchema, ToolDefinitionBlockSchema, ToolCallBlockSchema, ToolResultBlockSchema, ImageBlockSchema, OtherBlockSchema, BlockSchema, EntrySchema, UsageSchema, ConversationSchema;
var init_parse_types = __esm({
  "packages/core/dist/schemas/parse-types.js"() {
    "use strict";
    TextBlockSchema = z3.object({
      type: z3.literal("text"),
      text: z3.string()
    });
    ThinkingBlockSchema = z3.object({
      type: z3.literal("thinking"),
      thinking: z3.string()
    });
    ToolDefinitionBlockSchema = z3.object({
      type: z3.literal("td"),
      name: z3.string(),
      description: z3.string().nullable(),
      inputSchema: z3.unknown()
    });
    ToolCallBlockSchema = z3.object({
      type: z3.literal("tc"),
      id: z3.string(),
      name: z3.string(),
      arguments: z3.string()
    });
    ToolResultBlockSchema = z3.object({
      type: z3.literal("tr"),
      toolCallId: z3.string(),
      content: z3.string()
    });
    ImageBlockSchema = z3.object({
      type: z3.literal("image"),
      source: z3.unknown()
    });
    OtherBlockSchema = z3.object({
      type: z3.literal("other"),
      raw: z3.unknown()
    });
    BlockSchema = z3.discriminatedUnion("type", [
      TextBlockSchema,
      ThinkingBlockSchema,
      ToolDefinitionBlockSchema,
      ToolCallBlockSchema,
      ToolResultBlockSchema,
      ImageBlockSchema,
      OtherBlockSchema
    ]);
    EntrySchema = z3.object({
      id: z3.string(),
      role: z3.enum(["user", "assistant", "tool"]).optional(),
      blocks: z3.array(BlockSchema)
    });
    UsageSchema = z3.object({
      inputMissTokens: z3.number().nullable(),
      inputHitTokens: z3.number().nullable(),
      outputTokens: z3.number().nullable()
    });
    ConversationSchema = z3.object({
      provider: z3.string(),
      model: z3.string().nullable(),
      sys: EntrySchema.optional(),
      tool: EntrySchema.optional(),
      msgs: z3.array(EntrySchema),
      usage: UsageSchema.nullable(),
      stream: z3.boolean()
    });
  }
});

// packages/core/dist/schemas/query-types.js
import { z as z4 } from "zod";
var EntryDeltaSchema, DeltaSchema, RequestChangeSchema, SessionTimelineSchema, TokenUsageSchema, LatencyStatsSchema, DurationStatsSchema, SessionMetadataSchema, TimelineRecordSchema;
var init_query_types = __esm({
  "packages/core/dist/schemas/query-types.js"() {
    "use strict";
    init_parse_types();
    EntryDeltaSchema = z4.object({
      id: z4.string(),
      added: z4.array(BlockSchema).optional(),
      removed: z4.array(BlockSchema).optional()
    });
    DeltaSchema = z4.object({
      sys: EntryDeltaSchema.optional(),
      tool: EntryDeltaSchema.optional(),
      msgs: z4.array(EntryDeltaSchema)
    });
    RequestChangeSchema = z4.object({
      requestId: z4.number().int().positive(),
      delta: DeltaSchema,
      interRequestDuration: z4.number().nullable(),
      isUserCall: z4.boolean(),
      requestKind: z4.string().optional()
    });
    SessionTimelineSchema = z4.object({
      sessionId: z4.string(),
      totalRequests: z4.number().int().nonnegative(),
      changes: z4.array(RequestChangeSchema)
    });
    TokenUsageSchema = z4.object({
      inputMissTokens: z4.number(),
      inputHitTokens: z4.number(),
      outputTokens: z4.number(),
      totalTokens: z4.number(),
      cacheHitRate: z4.number()
    });
    LatencyStatsSchema = z4.object({
      avgTTFT: z4.number().nullable(),
      maxTTFT: z4.number().nullable(),
      avgTPOT: z4.number().nullable(),
      maxTPOT: z4.number().nullable(),
      streamRequestCount: z4.number().int().nonnegative()
    });
    DurationStatsSchema = z4.object({
      wallTime: z4.number(),
      agentTime: z4.number(),
      totalRequestDuration: z4.number()
    });
    SessionMetadataSchema = z4.object({
      sessionId: z4.string(),
      tokenUsage: TokenUsageSchema,
      requestCount: z4.number().int().nonnegative(),
      subSessions: z4.array(z4.string()),
      parentSession: z4.string().nullable(),
      createdAt: z4.string().nullable(),
      updatedAt: z4.string().nullable(),
      folderPath: z4.string().optional(),
      latencyStats: LatencyStatsSchema.nullable(),
      durationStats: DurationStatsSchema.nullable()
    });
    TimelineRecordSchema = z4.object({
      purpose: z4.string().optional(),
      id: z4.number().int().positive(),
      requestAt: z4.string().optional(),
      requestMsgs: z4.array(EntrySchema).optional(),
      parsed: z4.object({
        provider: z4.string(),
        model: z4.string().nullable(),
        msgs: z4.array(EntrySchema)
      }).passthrough()
    });
  }
});

// packages/core/dist/schemas/index.js
var init_schemas = __esm({
  "packages/core/dist/schemas/index.js"() {
    "use strict";
    init_types();
    init_parse_types();
    init_query_types();
    init_store_types();
  }
});

// packages/core/dist/cache/index.js
var init_cache = __esm({
  "packages/core/dist/cache/index.js"() {
    "use strict";
    init_read_cache();
  }
});

// packages/core/dist/index.js
var init_dist = __esm({
  "packages/core/dist/index.js"() {
    "use strict";
    init_store();
    init_parse();
    init_transform();
    init_query();
    init_record();
    init_state();
    init_format();
    init_schemas();
    init_cache();
    init_logger();
    init_paths();
    init_platform();
    init_parse();
  }
});

// packages/plugin/dist/write-queue.js
import { promises as fs3 } from "node:fs";
import { join as join3 } from "node:path";
var AsyncWriteQueue;
var init_write_queue = __esm({
  "packages/plugin/dist/write-queue.js"() {
    "use strict";
    init_dist();
    AsyncWriteQueue = class {
      queue = [];
      writing = false;
      closed = false;
      defaultTraceDir;
      batchSize;
      constructor(traceDir, batchSize = 50) {
        this.defaultTraceDir = traceDir;
        this.batchSize = batchSize;
      }
      enqueue(session, seq, record, timelineEntry, traceDir) {
        const targetDir = traceDir ?? this.defaultTraceDir;
        if (this.closed) {
          logger.warn("enqueue after close", { session, seq });
          this.queue.push({
            session,
            seq,
            record,
            timelineEntry,
            traceDir: targetDir,
            forceFallback: true
          });
          if (!this.writing) {
            this.processQueue();
          }
          return;
        }
        this.queue.push({ session, seq, record, timelineEntry, traceDir: targetDir });
        if (!this.writing) {
          this.processQueue();
        }
      }
      async close() {
        await this.flush();
        this.closed = true;
      }
      async processQueue() {
        this.writing = true;
        while (this.queue.length > 0) {
          const batch = this.queue.splice(0, this.batchSize);
          await this.writeBatch(batch);
        }
        this.writing = false;
        if (this.queue.length > 0 && !this.writing) {
          this.processQueue();
        }
      }
      async flush() {
        while (this.writing || this.queue.length > 0) {
          const { promise, resolve } = Promise.withResolvers();
          setTimeout(resolve, 10);
          await promise;
        }
      }
      async writeBatch(items) {
        await Promise.all(items.map(({ session, seq, record, timelineEntry, traceDir, forceFallback }) => this.writeOne(session, seq, record, timelineEntry, traceDir, forceFallback)));
      }
      async writeOne(session, seq, record, timelineEntry, traceDir, forceFallback) {
        try {
          if (forceFallback) {
            await this.writeFallback(session, seq, record, new Error("Queue is closed"), traceDir);
            return;
          }
          const sessionDir = join3(traceDir, session);
          await fs3.mkdir(sessionDir, { recursive: true });
          const tmpPath = join3(sessionDir, `${seq}.json.tmp`);
          const finalPath = join3(sessionDir, `${seq}.json`);
          await fs3.writeFile(tmpPath, JSON.stringify(record, null, 2));
          await safeRename(tmpPath, finalPath);
          if (timelineEntry) {
            await this.appendTimeline(sessionDir, timelineEntry);
          }
        } catch (err) {
          await this.writeFallback(session, seq, record, err, traceDir);
        }
      }
      /**
       * Retry rename on Windows transient errors (EACCES, EPERM).
       * On POSIX rename is atomic and never fails for this reason.
       * On Windows, antivirus or delayed flush can cause transient lock errors.
       */
      /** Fire-and-forget parsed cache write. Never blocks the write queue. */
      writeParsedCache(session, seq, parsed, traceDir) {
        const dir = traceDir ?? this.defaultTraceDir;
        setImmediate(async () => {
          try {
            const sessionDir = join3(dir, session);
            await fs3.mkdir(sessionDir, { recursive: true });
            const cachePath = join3(sessionDir, `${seq}.parsed`);
            await fs3.writeFile(cachePath, JSON.stringify(parsed));
          } catch {
          }
        });
      }
      async appendTimeline(sessionDir, entry) {
        const timelinePath = join3(sessionDir, "timeline.ndjson");
        const line = JSON.stringify(entry) + "\n";
        await fs3.appendFile(timelinePath, line);
      }
      async writeFallback(session, seq, record, err, traceDir) {
        const fallbackDir = join3(traceDir, "fallback");
        await fs3.mkdir(fallbackDir, { recursive: true });
        const filename = `${session}-${seq}-${Date.now()}.json`;
        await fs3.writeFile(join3(fallbackDir, filename), JSON.stringify({
          record,
          error: {
            name: err.name,
            message: err.message,
            stack: err.stack
          }
        }, null, 2));
        logger.error("Write failed, saved to fallback", {
          filename,
          error: err.message
        });
      }
    };
  }
});

// packages/plugin/dist/fallback-reconciler.js
import { promises as fs4 } from "node:fs";
import { join as join4 } from "node:path";
var FILENAME_RE, FallbackReconciler;
var init_fallback_reconciler = __esm({
  "packages/plugin/dist/fallback-reconciler.js"() {
    "use strict";
    init_dist();
    FILENAME_RE = /^(.+)-(\d+)-(\d+)\.json$/;
    FallbackReconciler = class {
      traceDir;
      intervalMs;
      timer = null;
      inFlight = null;
      closed = false;
      counts = { runs: 0, recovered: 0, failed: 0 };
      constructor(traceDir, options = {}) {
        this.traceDir = traceDir;
        this.intervalMs = options.intervalMs ?? 5 * 60 * 1e3;
      }
      stats() {
        return { ...this.counts };
      }
      async start() {
        if (this.timer || this.closed)
          return;
        await this.reconcile();
        this.timer = setInterval(() => {
          void this.reconcile();
        }, this.intervalMs);
      }
      async stop() {
        if (this.timer) {
          clearInterval(this.timer);
          this.timer = null;
        }
        if (this.inFlight) {
          await this.inFlight;
        }
        this.closed = true;
      }
      async reconcile() {
        if (this.inFlight) {
          await this.inFlight;
        }
        const work = this.runOnce();
        this.inFlight = work;
        try {
          return await work;
        } finally {
          if (this.inFlight === work) {
            this.inFlight = null;
          }
        }
      }
      async runOnce() {
        this.counts.runs++;
        const fallbackDir = join4(this.traceDir, "fallback");
        const result = { scanned: 0, recovered: 0, failed: 0 };
        let entries;
        try {
          entries = await fs4.readdir(fallbackDir);
        } catch (err) {
          const code = err?.code;
          if (code === "ENOENT") {
            return result;
          }
          logger.warn("FallbackReconciler: readdir failed", {
            fallbackDir,
            error: String(err)
          });
          return result;
        }
        for (const name of entries) {
          if (!name.endsWith(".json"))
            continue;
          const match = FILENAME_RE.exec(name);
          if (!match)
            continue;
          result.scanned++;
          const [, session, seqStr, tsStr] = match;
          const seq = Number.parseInt(seqStr, 10);
          const firstSeenAt = Number.parseInt(tsStr, 10);
          const sourcePath = join4(fallbackDir, name);
          const targetPath = join4(this.traceDir, session, `${seq}.json`);
          try {
            const sessionDir = join4(this.traceDir, session);
            await fs4.mkdir(sessionDir, { recursive: true });
            let payload;
            try {
              const raw = await fs4.readFile(sourcePath, "utf-8");
              payload = JSON.parse(raw);
            } catch (readErr) {
              throw readErr;
            }
            const record = payload?.record ?? payload;
            await fs4.writeFile(targetPath, JSON.stringify(record, null, 2));
            await fs4.unlink(sourcePath);
            result.recovered++;
            this.counts.recovered++;
            logger.info("FallbackReconciler: recovered record", {
              session,
              seq,
              firstSeenAt,
              targetPath
            });
          } catch (err) {
            result.failed++;
            this.counts.failed++;
            logger.warn("FallbackReconciler: recovery failed", {
              session,
              seq,
              firstSeenAt,
              error: String(err)
            });
          }
        }
        return result;
      }
    };
  }
});

// packages/plugin/dist/redact.js
function isSensitiveHeader(key) {
  return SENSITIVE_HEADERS.includes(key.toLowerCase());
}
function redactHeaders(headers) {
  const disabled = process.env.OPENCODE_TRACE_REDACT === "false";
  if (disabled) {
    return headers;
  }
  const result = {};
  for (const [key, value] of Object.entries(headers)) {
    if (isSensitiveHeader(key)) {
      const lowerValue = value.toLowerCase();
      if (lowerValue.startsWith("bearer ")) {
        result[key] = "Bearer [REDACTED]";
      } else {
        result[key] = "[REDACTED]";
      }
    } else {
      result[key] = value;
    }
  }
  return result;
}
var SENSITIVE_HEADERS;
var init_redact = __esm({
  "packages/plugin/dist/redact.js"() {
    "use strict";
    SENSITIVE_HEADERS = [
      "authorization",
      "api-key",
      "x-api-key",
      "apikey",
      "x-apikey",
      "token",
      "x-token",
      "access-token",
      "x-access-token",
      "secret",
      "x-secret",
      "cookie"
    ];
  }
});

// packages/plugin/dist/plugin-instance.js
import { homedir as homedir2 } from "node:os";
import { join as join5 } from "node:path";
import { promises as fs5 } from "node:fs";
var TracePlugin;
var init_plugin_instance = __esm({
  "packages/plugin/dist/plugin-instance.js"() {
    "use strict";
    init_write_queue();
    init_fallback_reconciler();
    init_redact();
    init_dist();
    init_state();
    TracePlugin = class {
      origFetch;
      ids = /* @__PURE__ */ new Map();
      initializingIDs = /* @__PURE__ */ new Map();
      writeQueue;
      reconciler;
      reconcilerStarted = false;
      interceptorInstalled = false;
      globalDir;
      localDir;
      globalConfigManager = null;
      localConfigManager = null;
      pendingRecords = /* @__PURE__ */ new Set();
      constructor(config) {
        if (!config.localDir) {
          throw new TypeError("TracerConfig.localDir is required");
        }
        this.globalDir = config.globalDir ?? join5(homedir2(), ".opencode-trace");
        this.localDir = config.localDir;
        this.origFetch = globalThis.fetch;
        this.writeQueue = new AsyncWriteQueue(this.globalDir);
        this.reconciler = new FallbackReconciler(this.globalDir);
      }
      async initStateManager() {
        this.globalConfigManager = await initConfigManager(this.globalDir);
        this.localConfigManager = await initConfigManager(this.localDir);
        if (!this.reconcilerStarted) {
          await this.reconciler.start();
          this.reconcilerStarted = true;
        }
      }
      getStateManager() {
        return this.globalConfigManager;
      }
      getGlobalConfigManager() {
        return this.globalConfigManager;
      }
      getLocalConfigManager() {
        return this.localConfigManager;
      }
      resolveTraceDir(sessionId) {
        if (sessionId && this.globalConfigManager) {
          const sessionPref = this.globalConfigManager.getSessionStoragePreference(sessionId);
          if (sessionPref === "local")
            return this.localDir;
          if (sessionPref === "global")
            return this.globalDir;
        }
        if (this.globalConfigManager) {
          const globalPref = this.globalConfigManager.getStoragePreference();
          if (globalPref === "local")
            return this.localDir;
        }
        return this.globalDir;
      }
      shouldRecord(sessionId) {
        if (!this.globalConfigManager)
          return true;
        const globalEnabled = this.globalConfigManager.getGlobalState("global_trace_enabled") === "true";
        if (globalEnabled)
          return true;
        if (this.localConfigManager) {
          const localEnabled = this.localConfigManager.getGlobalState("global_trace_enabled") === "true";
          if (localEnabled)
            return true;
        }
        if (!sessionId)
          return false;
        return this.globalConfigManager.getSessionEnabled(sessionId) ?? false;
      }
      getScopeStatus(sessionId) {
        const globalEnabled = this.globalConfigManager ? this.globalConfigManager.getGlobalState("global_trace_enabled") === "true" : false;
        const localEnabled = this.localConfigManager ? this.localConfigManager.getGlobalState("global_trace_enabled") === "true" : false;
        const sessionEnabled = sessionId && this.globalConfigManager ? this.globalConfigManager.getSessionEnabled(sessionId) : null;
        const effectiveEnabled = this.shouldRecord(sessionId);
        const traceDir = this.resolveTraceDir(sessionId);
        const storageLocation = traceDir === this.localDir ? "local" : "global";
        return {
          globalEnabled,
          localEnabled,
          sessionEnabled,
          effectiveEnabled,
          storageLocation,
          globalDir: this.globalDir,
          localDir: this.localDir
        };
      }
      async tracedFetch(input, init, origFetch) {
        const delegate = origFetch ?? this.origFetch;
        const req = this.parseRequest(input, init);
        if (!req)
          return delegate(input, init);
        const meta = await this.captureRequestMeta(req);
        if (!meta)
          return delegate(req);
        let res;
        try {
          res = await delegate(req);
        } catch (err) {
          const error = err instanceof Error ? { message: err.message, stack: this.sanitizeStackTrace(err.stack) } : { message: String(err) };
          const record = this.createTraceRecord(meta.seq, meta.purpose, meta.requestAt, meta.traceReq, null, error, { requestSentAt: meta.requestSentAt });
          const timelineEntry = this.buildTimelineEntry(meta.session, meta.seq, meta.purpose, meta.requestAt, meta.traceReq, null, error);
          await this.writeQueue.enqueue(meta.session, meta.seq, record, timelineEntry, meta.traceDir);
          this.writeParsedCacheAsync(meta.session, meta.seq, record, meta.traceDir);
          throw err;
        }
        let latencyMeta;
        if (meta.isStream && res.body) {
          res = await this.wrapStreamResponse(res, meta.requestSentAt, meta.session, meta.seq, meta.traceDir);
          latencyMeta = res.__latencyMeta;
        }
        const recording = this.recordResponse(meta.session, meta.seq, meta.purpose, meta.requestAt, meta.traceReq, res, latencyMeta, meta.traceDir);
        this.pendingRecords.add(recording);
        void recording.finally(() => this.pendingRecords.delete(recording));
        return res;
      }
      getSessionId(req) {
        return req.headers.get("x-opencode-session") ?? req.headers.get("x-session-affinity") ?? req.headers.get("session_id") ?? void 0;
      }
      parseBody(text) {
        try {
          return JSON.parse(text);
        } catch {
          return text || null;
        }
      }
      headersToObject(headers) {
        const obj = {};
        headers.forEach((value, key) => {
          obj[key] = value;
        });
        return obj;
      }
      classifyPurpose(raw) {
        if (typeof raw === "object" && raw !== null && !Array.isArray(raw) && Array.isArray(raw.tools) && raw.tools.length > 0)
          return "";
        return "[meta]";
      }
      parseRequest(input, init) {
        try {
          return new Request(input, init);
        } catch {
          return null;
        }
      }
      async captureRequestMeta(req) {
        const session = this.getSessionId(req);
        if (session === void 0)
          return null;
        if (!this.shouldRecord(session))
          return null;
        const traceDir = this.resolveTraceDir(session);
        if (!this.ids.has(session)) {
          let initializing = this.initializingIDs.get(session);
          if (!initializing) {
            initializing = fs5.readdir(join5(traceDir, session)).catch((error) => {
              if (error.code === "ENOENT")
                return [];
              throw error;
            }).then((files) => {
              this.ids.set(session, Math.max(0, ...files.filter((f) => /^\d+\.(json|sse|sse\.tmp)$/.test(f)).map((f) => Number(f.split(".")[0]))));
            });
            this.initializingIDs.set(session, initializing);
          }
          await initializing;
        }
        const seq = (this.ids.get(session) ?? 0) + 1;
        this.ids.set(session, seq);
        const requestSentAt = performance.now();
        const requestAt = (/* @__PURE__ */ new Date()).toISOString();
        const reqBodyText = await req.clone().text().catch((err) => {
          logger.error("Failed to clone request body", {
            url: req.url,
            error: String(err)
          });
          return "";
        });
        const reqBody = this.parseBody(reqBodyText);
        let isStream = false;
        try {
          isStream = JSON.parse(reqBodyText ?? "{}")?.stream === true;
        } catch {
          isStream = false;
        }
        const nativeKind = req.headers.get("x-course-request-kind");
        const purpose = nativeKind && ["primary", "title", "compaction", "generate"].includes(nativeKind) ? `[${nativeKind}]` : this.classifyPurpose(reqBody);
        const traceReq = {
          method: req.method,
          url: req.url,
          headers: redactHeaders(this.headersToObject(req.headers)),
          body: reqBody
        };
        return {
          session,
          seq,
          requestSentAt,
          requestAt,
          reqBody,
          isStream,
          purpose,
          traceReq,
          traceDir
        };
      }
      async wrapStreamResponse(res, requestSentAt, session, seq, traceDir) {
        const latencyMeta = { requestSentAt, firstTokenAt: null, lastTokenAt: null };
        const sessionDir = join5(traceDir, session);
        const sseTmpPath = join5(sessionDir, `${seq}.sse.tmp`);
        const sseFinalPath = join5(sessionDir, `${seq}.sse`);
        await fs5.mkdir(sessionDir, { recursive: true });
        const fileHandle = await fs5.open(sseTmpPath, "w");
        let bytesWritten = 0;
        const transform = new TransformStream({
          async transform(chunk, controller) {
            if (latencyMeta.firstTokenAt === null) {
              latencyMeta.firstTokenAt = performance.now();
            }
            try {
              await fileHandle.write(chunk);
              bytesWritten += chunk.byteLength;
            } catch (err) {
              logger.error("Failed to write SSE chunk", {
                seq,
                error: String(err)
              });
            }
            controller.enqueue(chunk);
          },
          async flush() {
            latencyMeta.lastTokenAt = performance.now();
            try {
              await fileHandle.close();
              await fs5.rename(sseTmpPath, sseFinalPath);
            } catch (err) {
              logger.error("Failed to finalize SSE file", {
                seq,
                error: String(err)
              });
            }
          }
        });
        const wrappedBody = res.body.pipeThrough(transform);
        const wrappedRes = new Response(wrappedBody, {
          status: res.status,
          statusText: res.statusText,
          headers: res.headers
        });
        wrappedRes.__latencyMeta = latencyMeta;
        return wrappedRes;
      }
      async recordResponse(session, seq, purpose, requestAt, traceReq, res, latencyMeta, traceDir) {
        const dir = traceDir ?? this.globalDir;
        try {
          const resBodyText = await res.clone().text();
          const resBody = this.parseBody(resBodyText);
          const traceRes = {
            status: res.status,
            statusText: res.statusText,
            headers: redactHeaders(this.headersToObject(res.headers)),
            body: resBody
          };
          const normalizedLatency = latencyMeta ? {
            requestSentAt: latencyMeta.requestSentAt,
            firstTokenAt: latencyMeta.firstTokenAt ?? void 0,
            lastTokenAt: latencyMeta.lastTokenAt ?? void 0
          } : void 0;
          const record = this.createTraceRecord(seq, purpose, requestAt, traceReq, traceRes, null, normalizedLatency);
          const timelineEntry = this.buildTimelineEntry(session, seq, purpose, requestAt, traceReq, traceRes, null);
          await this.writeQueue.enqueue(session, seq, record, timelineEntry, dir);
          this.writeParsedCacheAsync(session, seq, record, dir);
        } catch (err) {
          const error = err instanceof Error ? { message: err.message, stack: this.sanitizeStackTrace(err.stack) } : { message: String(err) };
          const normalizedLatency = latencyMeta ? {
            requestSentAt: latencyMeta.requestSentAt,
            firstTokenAt: latencyMeta.firstTokenAt ?? void 0,
            lastTokenAt: latencyMeta.lastTokenAt ?? void 0
          } : void 0;
          const record = this.createTraceRecord(seq, purpose, requestAt, traceReq, null, error, normalizedLatency);
          const timelineEntry = this.buildTimelineEntry(session, seq, purpose, requestAt, traceReq, null, error);
          await this.writeQueue.enqueue(session, seq, record, timelineEntry, dir);
          this.writeParsedCacheAsync(session, seq, record, dir);
        }
      }
      buildTimelineEntry(_session, seq, purpose, requestAt, traceReq, traceRes, error) {
        const responseAt = (/* @__PURE__ */ new Date()).toISOString();
        const requestTime = new Date(requestAt).getTime();
        const responseTime = new Date(responseAt).getTime();
        const totalDurationMs = responseTime - requestTime;
        let provider = null;
        let model = null;
        let inputTokens = null;
        let outputTokens = null;
        if (traceRes?.body && typeof traceRes.body === "object" && traceRes.body !== null) {
          const body = traceRes.body;
          if (typeof body.model === "string")
            model = body.model;
          if (body.usage && typeof body.usage === "object") {
            const usage = body.usage;
            if (typeof usage.input_tokens === "number")
              inputTokens = usage.input_tokens;
            if (typeof usage.output_tokens === "number")
              outputTokens = usage.output_tokens;
            if (typeof usage.prompt_tokens === "number")
              inputTokens = usage.prompt_tokens;
            if (typeof usage.completion_tokens === "number")
              outputTokens = usage.completion_tokens;
          }
        }
        if (traceReq.url.includes("openai.com") || traceReq.url.includes("api.openai")) {
          provider = "openai";
        } else if (traceReq.url.includes("anthropic.com") || traceReq.url.includes("api.anthropic")) {
          provider = "anthropic";
        }
        return {
          seq,
          url: traceReq.url,
          method: traceReq.method,
          purpose,
          requestAt,
          responseAt: error ? null : responseAt,
          status: error ? 0 : traceRes?.status ?? 0,
          provider,
          model,
          inputTokens,
          outputTokens,
          totalDurationMs
        };
      }
      sanitizeStackTrace(stack) {
        if (!stack)
          return void 0;
        const userHome = homedir2();
        return sanitizePath(stack, userHome).replace(/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/g, "[IP]").replace(/:\d{4,5}(?=[\/\\\s]|$)/g, ":[PORT]");
      }
      createTraceRecord(seq, purpose, requestAt, traceReq, traceRes, error, latency) {
        return {
          id: seq,
          purpose,
          requestAt,
          responseAt: (/* @__PURE__ */ new Date()).toISOString(),
          request: traceReq,
          response: traceRes,
          error,
          requestSentAt: latency?.requestSentAt,
          firstTokenAt: latency?.firstTokenAt ?? void 0,
          lastTokenAt: latency?.lastTokenAt ?? void 0
        };
      }
      writeParsedCacheAsync(session, seq, record, traceDir) {
        setImmediate(() => {
          try {
            const parsed = parse_exports.detectAndParse(record);
            this.writeQueue.writeParsedCache(session, seq, {
              ...parsed,
              _pcv: parse_exports.PARSED_CACHE_VERSION
            }, traceDir);
          } catch {
          }
        });
      }
      async flush() {
        await Promise.all([...this.pendingRecords]);
        await this.writeQueue.flush();
        await this.reconciler.reconcile();
      }
      async stop() {
        await this.flush();
        await this.writeQueue.close();
        if (this.reconcilerStarted) {
          await this.reconciler.stop();
          this.reconcilerStarted = false;
        }
        this.uninstallInterceptor();
      }
      wrap(fetch) {
        const capturedOrig = fetch;
        return async (input, init) => this.tracedFetch(input, init, capturedOrig);
      }
      getInterceptor() {
        const capturedOrig = this.origFetch;
        return async (input, init) => this.tracedFetch(input, init, capturedOrig);
      }
      installInterceptor() {
        if (this.interceptorInstalled)
          return;
        this.origFetch = globalThis.fetch;
        globalThis.fetch = async (input, init) => this.tracedFetch(input, init, this.origFetch);
        this.interceptorInstalled = true;
      }
      uninstallInterceptor() {
        if (!this.interceptorInstalled)
          return;
        globalThis.fetch = this.origFetch;
        this.interceptorInstalled = false;
      }
    };
  }
});

// packages/plugin/dist/tracer.js
var tracer_exports = {};
__export(tracer_exports, {
  TracePlugin: () => TracePlugin,
  createTracer: () => createTracer
});
function createTracer(config) {
  const plugin = new TracePlugin(config);
  return {
    wrap: (fetch) => plugin.wrap(fetch),
    getInterceptor: () => plugin.getInterceptor(),
    installInterceptor: () => plugin.installInterceptor()
  };
}
var init_tracer = __esm({
  "packages/plugin/dist/tracer.js"() {
    "use strict";
    init_plugin_instance();
    init_plugin_instance();
  }
});

// course/plugin/index.js
import { mkdir, appendFile, writeFile } from "node:fs/promises";
import path2 from "node:path";
import { randomUUID as randomUUID2 } from "node:crypto";
var index_default = {
  id: "course.opencode-trace",
  async setup(ctx) {
    if (ctx.app.version !== "2.2.0") throw new Error("Course tracer requires OpenCode 2.2.0.");
    const directory = ctx.location.directory;
    const traceDir = path2.join(directory, ".opencode-trace");
    const evidenceDir = path2.join(traceDir, "evidence");
    await mkdir(evidenceDir, { recursive: true });
    process.env.OPENTRACE_LOG ??= "console";
    const { TracePlugin: TracePlugin2 } = await Promise.resolve().then(() => (init_tracer(), tracer_exports));
    const recorder = new TracePlugin2({ globalDir: traceDir, localDir: traceDir });
    await recorder.initStateManager();
    recorder.getStateManager().setGlobalState("global_trace_enabled", "true");
    const pending = /* @__PURE__ */ new WeakMap();
    const unfinished = /* @__PURE__ */ new Set();
    let writes = Promise.resolve();
    const log = (event, data) => {
      const line = JSON.stringify({ time: (/* @__PURE__ */ new Date()).toISOString(), event, data }) + "\n";
      writes = writes.then(() => appendFile(path2.join(evidenceDir, "events.jsonl"), line));
      return writes;
    };
    const belongs = async (sessionID) => {
      const session = await ctx.session.get({ sessionID });
      if (session.location.directory !== directory) return false;
      recorder.getStateManager().updateSessionMetadata(sessionID, { title: session.title, folderPath: directory });
      return true;
    };
    const observe = (domain, name) => domain.hook(name, async (input) => {
      if (await belongs(input.sessionID)) await log(name, input);
    });
    await observe(ctx.session, "prompt");
    await observe(ctx.session, "context");
    await observe(ctx.tool, "execute.before");
    await observe(ctx.tool, "execute.after");
    await observe(ctx.permission, "evaluate");
    await ctx.session.hook("retry", async (input) => {
      if (!await belongs(input.sessionID)) return;
      await log("retry", input);
      for (const entry of unfinished) {
        if (entry.sessionID === input.sessionID) entry.response.reject(new Error("Transport attempt failed before an HTTP response was observed; see retry event."));
      }
    });
    await ctx.session.hook("http.request", async (input) => {
      if (!await belongs(input.sessionID)) return;
      const body = new Uint8Array(await input.request.clone().arrayBuffer());
      const id = `${input.sessionID}-${randomUUID2()}`;
      await writeFile(path2.join(evidenceDir, `${id}.request-body`), body, { flag: "wx" });
      await log("http.request", { id, sessionID: input.sessionID, kind: input.kind, agent: input.agent, model: input.model });
      const copy = new Request(input.request.url, {
        method: input.request.method,
        headers: { "content-type": input.request.headers.get("content-type") ?? "application/json", "x-opencode-session": input.sessionID, "x-course-request-kind": input.kind },
        body
      });
      const response = Promise.withResolvers();
      const ready = Promise.withResolvers();
      const recorded = recorder.tracedFetch(copy, void 0, async () => {
        ready.resolve();
        return response.promise;
      });
      const entry = { sessionID: input.sessionID, response, recorded };
      pending.set(input.request, entry);
      unfinished.add(entry);
      recorded.catch((error) => {
        unfinished.delete(entry);
        ready.reject(error);
      });
      await ready.promise;
    });
    await ctx.session.hook("http.response", async (input) => {
      const entry = pending.get(input.request);
      if (!entry) return;
      pending.delete(input.request);
      entry.response.resolve(input.response);
      input.response = await entry.recorded;
      unfinished.delete(entry);
    });
    const eventsAbort = new AbortController();
    const eventTask = (async () => {
      for await (const event of ctx.event.subscribe({ types: ["permission.asked", "permission.replied"], signal: eventsAbort.signal })) {
        if (event.data?.sessionID && await belongs(event.data.sessionID)) await log(event.type, event.data);
      }
    })();
    eventTask.catch((error) => console.error("Course trace event recording failed:", error));
    await log("recorder.started", { version: ctx.app.version, directory, requestHeaders: "Content type and synthetic trace markers only; authentication headers excluded." });
    return async () => {
      eventsAbort.abort();
      await eventTask;
      const tasks = [...unfinished];
      for (const entry of tasks) entry.response.reject(new Error("Recording ended before an HTTP response was observed"));
      await Promise.allSettled(tasks.map((entry) => entry.recorded));
      await recorder.stop();
      await log("recorder.stopped", { directory });
      await writes;
    };
  }
};
export {
  index_default as default
};
