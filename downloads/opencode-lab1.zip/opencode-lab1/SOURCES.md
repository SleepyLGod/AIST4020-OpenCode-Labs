# Paper sources

These five PDFs are unchanged copies of the versions linked below.
Each arXiv version identifies CC BY 4.0 as its license. Attribution is retained here and in the PDFs.
No author or institution endorses this lab. See LICENSE-PAPERS.txt.

## Efficient Memory Management for Large Language Model Serving with PagedAttention

Kwon, Woosuk; Li, Zhuohan; Zhuang, Siyuan; Sheng, Ying; Zheng, Lianmin; Yu, Cody Hao; Gonzalez, Joseph E.; Zhang, Hao; Stoica, Ion

- File: `input/pagedattention-2309.06180v1.pdf`
- Source: https://arxiv.org/abs/2309.06180v1
- License: http://creativecommons.org/licenses/by/4.0/
- SHA-256: `55b3b324d779a67c59dac2519445e3b07c14e6ff5c656fadb47a3d7b5997469e`

## Gorilla: Large Language Model Connected with Massive APIs

Patil, Shishir G.; Zhang, Tianjun; Wang, Xin; Gonzalez, Joseph E.

- File: `input/gorilla-2305.15334v1.pdf`
- Source: https://arxiv.org/abs/2305.15334v1
- License: http://creativecommons.org/licenses/by/4.0/
- SHA-256: `1aeae54095cdae3a3ebaa29f7af0919d666e0c87d961848ae85b991b3c022718`

## Self-RAG: Learning to Retrieve, Generate, and Critique through Self-Reflection

Asai, Akari; Wu, Zeqiu; Wang, Yizhong; Sil, Avirup; Hajishirzi, Hannaneh

- File: `input/self-rag-2310.11511v1.pdf`
- Source: https://arxiv.org/abs/2310.11511v1
- License: http://creativecommons.org/licenses/by/4.0/
- SHA-256: `d9eaa1398abac0df67a9d0933a5bf8b6d9d83d2e72da2a486073cd842dd52978`

## From Local to Global: A Graph RAG Approach to Query-Focused Summarization

Edge, Darren; Trinh, Ha; Cheng, Newman; Bradley, Joshua; Chao, Alex; Mody, Apurva; Truitt, Steven; Metropolitansky, Dasha; Ness, Robert Osazuwa; Larson, Jonathan

- File: `input/graphrag-2404.16130v2.pdf`
- Source: https://arxiv.org/abs/2404.16130v2
- License: http://creativecommons.org/licenses/by/4.0/
- SHA-256: `730f1a9f38d16689900969a3eeeb1b31e45eda1dcc1f37a043afa90aff76c867`

## MemGPT: Towards LLMs as Operating Systems

Packer, Charles; Wooders, Sarah; Lin, Kevin; Fang, Vivian; Patil, Shishir G.; Stoica, Ion; Gonzalez, Joseph E.

- File: `input/memgpt-2310.08560v2.pdf`
- Source: https://arxiv.org/abs/2310.08560v2
- License: http://creativecommons.org/licenses/by/4.0/
- SHA-256: `9f674bcff69c86f11c813dcfad613d8841f5f8ed17979e3c4df06a91df7762e0`
